type Company = {
  name: string;
  description: string;
  logoDark: string;
  logoLight: string;
  url: string;
  href: string;
  logoClassName?: string;
};

export const Gold = () => {
  const companies: Company[] = [
    {
      name: "CodeRabbit",
      description: "Cut code review time & bugs in half",
      logoDark: "https://github.com/user-attachments/assets/eea24edb-ff20-4532-b57c-e8719f455d6d",
      logoLight: "https://github.com/user-attachments/assets/d791bc7d-dc60-4d55-9c31-97779839cb74",
      url: "coderabbit.ai",
      href: "https://www.coderabbit.ai/",
    },
  ];

  return (
    <div className="max-w-4xl mt-4">
      <div className="border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 rounded-md">
        <div className={`grid grid-cols-1 ${companies.length > 1 ? "sm:grid-cols-2" : ""}`}>
          {companies.map((company) => (
            <div
              key={company.name}
              className="p-4 flex flex-col items-center border-b border-r border-gray-200 dark:border-gray-700 last:border-b-0 last:border-r-0"
            >
              <a href={company.href} target="_blank" rel="noopener noreferrer" className="my-0! border-none">
                <img
                  src={company.logoLight}
                  alt={`${company.name} logo (light theme)`}
                  className={`my-0! object-contain dark:hidden ${company.logoClassName ?? "h-16"}`}
                />
                <img
                  src={company.logoDark}
                  alt={`${company.name} logo (dark theme)`}
                  className={`my-0! object-contain hidden dark:block ${company.logoClassName ?? "h-16"}`}
                />
              </a>

              <p className="mt-3 mb-0 text-center text-sm text-gray-600 dark:text-gray-400">{company.description}</p>
              <a
                href={company.href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
              >
                {company.url}
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
