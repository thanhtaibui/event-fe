import { ViewApi } from '../../api/ViewApi'
import type { DatePointApi } from '../../structs/date-span'
import type { Hit } from '../../interactions/hit'
import { interactionSettingsStore } from '../../interactions/interaction'
import type { PointerDragEvent } from '../../interactions/pointer'
import { parseEventDef } from '../../structs/event-parse'
import {
  addDurationToEdge, buildEventInstanceRange, createEventInstance, EventRangeEdge,
} from '../../structs/event-instance'
import type { EventTuple } from '../../structs/event-parse'
import { createEmptyEventStore, eventTupleToStore } from '../../structs/event-store'
import { config } from '../../global-config'
import type { DateSpan } from '../../structs/date-span'
import type { EventInteractionState } from '../../interactions/event-interaction-state'
import type { DragMetaInput, DragMeta } from '../../structs/drag-meta'
import { parseDragMeta } from '../../structs/drag-meta'
import { enableCursor, disableCursor } from '../../util/misc'
import { isInteractionValid } from '../../validation'
import type { ElementDragging } from '../../interactions/ElementDragging'
import type { CalendarContext } from '../../CalendarContext'
import { getDefaultEventEndEdge } from '../../calendar-utils'
import { refineEventDef } from '../../structs/event-parse'
import { EventImpl } from '../../api/EventImpl'
import classNames from '../../styles.module.css'
import { HitDragging } from '../interactions/HitDragging'
import { buildDatePointApiWithContext } from '../utils'

export type DragMetaGenerator = DragMetaInput | ((el: HTMLElement) => DragMetaInput)

export interface ExternalDropApi extends DatePointApi {
  draggedEl: HTMLElement
  jsEvent: UIEvent
  view: ViewApi
}

/*
Given an already instantiated draggable object for one-or-more elements,
Interprets any dragging as an attempt to drag an events that lives outside
of a calendar onto a calendar.
*/
export class ExternalElementDragging {
  hitDragging: HitDragging
  receivingContext: CalendarContext | null = null
  droppableEvent: EventTuple | null = null // will exist for all drags, even if create:false
  suppliedDragMeta: DragMetaGenerator | null = null
  dragMeta: DragMeta | null = null

  constructor(dragging: ElementDragging, suppliedDragMeta?: DragMetaGenerator) {
    let hitDragging = this.hitDragging = new HitDragging(dragging, interactionSettingsStore)
    hitDragging.requireInitial = false // will start outside of a component
    hitDragging.emitter.on('dragstart', this.handleDragStart)
    hitDragging.emitter.on('hitupdate', this.handleHitUpdate)
    hitDragging.emitter.on('dragend', this.handleDragEnd)

    this.suppliedDragMeta = suppliedDragMeta
  }

  handleDragStart = (ev: PointerDragEvent) => {
    this.dragMeta = this.buildDragMeta(ev.subjectEl as HTMLElement)
  }

  buildDragMeta(subjectEl: HTMLElement) {
    if (typeof this.suppliedDragMeta === 'object') {
      return parseDragMeta(this.suppliedDragMeta)
    }
    if (typeof this.suppliedDragMeta === 'function') {
      return parseDragMeta(this.suppliedDragMeta(subjectEl))
    }
    return getDragMetaFromEl(subjectEl)
  }

  handleHitUpdate = (hit: Hit | null, isFinal: boolean, ev: PointerDragEvent) => {
    let { dragging } = this.hitDragging
    let receivingContext: CalendarContext | null = null
    let droppableEvent: EventTuple | null = null
    let isInvalid = false
    let interaction: EventInteractionState = {
      affectedEvents: createEmptyEventStore(),
      mutatedEvents: createEmptyEventStore(),
      isEvent: this.dragMeta!.create,
    }

    if (hit) {
      receivingContext = hit.context

      if (this.canDropElOnCalendar(ev.subjectEl as HTMLElement, receivingContext)) {
        droppableEvent = computeEventForDateSpan(
          hit.dateSpan,
          this.dragMeta!,
          receivingContext,
        )

        interaction.mutatedEvents = eventTupleToStore(droppableEvent)
        isInvalid = !isInteractionValid(interaction, hit.dateProfile, receivingContext)

        if (isInvalid) {
          interaction.mutatedEvents = createEmptyEventStore()
          droppableEvent = null
        }
      }
    }

    this.displayDrag(receivingContext, interaction)

    // show mirror if no already-rendered mirror element OR if we are shutting down the mirror (?)
    // TODO: wish we could somehow wait for dispatch to guarantee render
    dragging.setMirrorIsVisible(
      isFinal ||
      !droppableEvent ||
      !document.querySelector(`.${classNames.internalEventMirror}`),
      // TODO: somehow query FullCalendars WITHIN shadow-roots for existing event-mirror els
    )

    if (!isInvalid) {
      enableCursor()
    } else {
      disableCursor()
    }

    if (!isFinal) {
      dragging.setMirrorNeedsRevert(!droppableEvent)

      this.receivingContext = receivingContext
      this.droppableEvent = droppableEvent
    }
  }

  handleDragEnd = (pev: PointerDragEvent) => {
    let { receivingContext, droppableEvent } = this

    this.clearDrag()

    if (receivingContext && droppableEvent) {
      let finalHit = this.hitDragging.finalHit!
      let finalView = finalHit.context.viewApi
      let dragMeta = this.dragMeta!

      receivingContext.emitter.trigger('drop', {
        ...buildDatePointApiWithContext(finalHit.dateSpan, receivingContext),
        draggedEl: pev.subjectEl as HTMLElement,
        jsEvent: pev.origEvent as MouseEvent, // Is this always a mouse event? See #4655
        view: finalView,
      })

      if (dragMeta.create) {
        let addingEvents = eventTupleToStore(droppableEvent)

        receivingContext.dispatch({
          type: 'MERGE_EVENTS',
          eventStore: addingEvents,
        })

        if (pev.isTouch) {
          receivingContext.dispatch({
            type: 'SELECT_EVENT',
            eventInstanceId: droppableEvent.instance.instanceId,
          })
        }

        // signal that an external event landed
        receivingContext.emitter.trigger('eventReceive', {
          event: new EventImpl(
            receivingContext,
            droppableEvent.def,
            droppableEvent.instance,
          ),
          relatedEvents: [],
          revert() {
            receivingContext.dispatch({
              type: 'REMOVE_EVENTS',
              eventStore: addingEvents,
            })
          },
          draggedEl: pev.subjectEl as HTMLElement,
          view: finalView,
        })
      }
    }

    this.receivingContext = null
    this.droppableEvent = null
  }

  displayDrag(nextContext: CalendarContext | null, state: EventInteractionState) {
    let prevContext = this.receivingContext

    if (prevContext && prevContext !== nextContext) {
      prevContext.dispatch({ type: 'UNSET_EVENT_DRAG' })
    }

    if (nextContext) {
      nextContext.dispatch({ type: 'SET_EVENT_DRAG', state })
    }
  }

  clearDrag() {
    if (this.receivingContext) {
      this.receivingContext.dispatch({ type: 'UNSET_EVENT_DRAG' })
    }
  }

  canDropElOnCalendar(el: HTMLElement, receivingContext: CalendarContext): boolean {
    let dropAccept = receivingContext.options.dropAccept

    if (typeof dropAccept === 'function') {
      return dropAccept.call(receivingContext.calendarApi, el)
    }

    if (typeof dropAccept === 'string' && dropAccept) {
      return el.matches(dropAccept)
    }

    return true
  }
}

// Utils for computing event store from the DragMeta
// ----------------------------------------------------------------------------------------------------

function computeEventForDateSpan(dateSpan: DateSpan, dragMeta: DragMeta, context: CalendarContext): EventTuple {
  let defProps = { ...dragMeta.leftoverProps }

  for (let transform of context.pluginHooks.externalDefTransforms) {
    Object.assign(defProps, transform(dateSpan, dragMeta))
  }

  let { refined, extra } = refineEventDef(defProps, context)
  let def = parseEventDef(
    refined,
    extra,
    dragMeta.sourceId,
    dateSpan.allDay,
    context.options.forceEventDuration || Boolean(dragMeta.duration), // hasEnd
    context,
  )

  let start = dateSpan.range.start

  // only rely on time info if drop zone is all-day,
  // otherwise, we already know the time
  if (dateSpan.allDay && dragMeta.startTime) {
    start = context.dateEnv.add(start, dragMeta.startTime)
  }

  // carry the drop span's exact instant when the start marker was used as-is
  // (keeps identity during DST fall-back doubled slots)
  let startEdge: EventRangeEdge = {
    marker: start,
    instantMs: !dateSpan.allDay ? dateSpan.instantStartMs : undefined,
  }

  // an exact start yields an exact derived end (real elapsed duration)
  let endEdge = dragMeta.duration ?
    addDurationToEdge(startEdge, dragMeta.duration, context.dateEnv) :
    getDefaultEventEndEdge(dateSpan.allDay, startEdge, context)

  let instance = createEventInstance(def.defId, buildEventInstanceRange(
    startEdge.marker, endEdge.marker, startEdge.instantMs, endEdge.instantMs,
  ))

  return { def, instance }
}

// Utils for extracting data from element
// ----------------------------------------------------------------------------------------------------

function getDragMetaFromEl(el: HTMLElement): DragMeta {
  let str = getEmbeddedElData(el, 'event')
  let obj = str ?
    JSON.parse(str) :
    { create: false } // if no embedded data, assume no event creation

  return parseDragMeta(obj)
}

config.dataAttrPrefix = ''

function getEmbeddedElData(el: HTMLElement, name: string): string {
  let prefix = config.dataAttrPrefix
  let prefixedName = (prefix ? prefix + '-' : '') + name

  return el.getAttribute('data-' + prefixedName) || ''
}
