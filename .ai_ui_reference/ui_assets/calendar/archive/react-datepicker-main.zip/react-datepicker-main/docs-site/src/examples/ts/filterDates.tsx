type TFilterDate = (date: Date) => boolean;

const FilterDates = () => {
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  const isWeekday: TFilterDate = (date) => {
    const day = DateFNS.getDay(date);
    return day !== 0 && day !== 6;
  };

  return (
    <DatePicker
      selected={selectedDate}
      onChange={setSelectedDate}
      filterDate={isWeekday}
      placeholderText="Select a weekday"
    />
  );
};

render(FilterDates);
