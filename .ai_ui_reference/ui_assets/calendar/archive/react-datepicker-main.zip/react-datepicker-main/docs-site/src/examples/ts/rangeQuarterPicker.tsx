const RangeQuarterPicker = () => {
  const [startDate, setStartDate] = useState<Date | null>(
    new Date("2014/02/08"),
  );
  const [endDate, setEndDate] = useState<Date | null>(new Date("2014/07/08"));

  return (
    <>
      <DatePicker
        selected={startDate}
        onChange={setStartDate}
        selectsStart
        startDate={startDate}
        endDate={endDate}
        dateFormat="yyyy, QQQ"
        showQuarterYearPicker
      />
      <DatePicker
        selected={endDate}
        onChange={setEndDate}
        selectsEnd
        startDate={startDate}
        endDate={endDate}
        dateFormat="yyyy, QQQ"
        showQuarterYearPicker
      />
    </>
  );
};

render(RangeQuarterPicker);
