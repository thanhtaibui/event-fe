export type IconType = 'cloud' | 'moon-cloud' | 'rain' | 'partly-cloudy';

type Forecast = {
  time: Date;
  temperature: number;
  precipitation: number;
  maxPrecipitation: number;
  wind: number;
  gust: number;
  icon: IconType;
  windDirection: number;
};

export const forecast: Forecast[] = [
  {
    time: new Date(2026, 5, 8, 20, 0),
    temperature: 20,
    precipitation: 0,
    maxPrecipitation: 0,
    wind: 2.6,
    gust: 6,
    icon: 'cloud',
    windDirection: 35,
  },
  {
    time: new Date(2026, 5, 8, 22, 0),
    temperature: 17,
    precipitation: 0,
    maxPrecipitation: 0,
    wind: 2,
    gust: 4,
    icon: 'moon-cloud',
    windDirection: 50,
  },
  {
    time: new Date(2026, 5, 9, 0, 0),
    temperature: 15,
    precipitation: 0,
    maxPrecipitation: 0,
    wind: 2.4,
    gust: 5,
    icon: 'moon-cloud',
    windDirection: 30,
  },
  {
    time: new Date(2026, 5, 9, 2, 0),
    temperature: 14,
    precipitation: 0,
    maxPrecipitation: 0,
    wind: 2.8,
    gust: 5,
    icon: 'cloud',
    windDirection: 10,
  },
  {
    time: new Date(2026, 5, 9, 4, 0),
    temperature: 15,
    precipitation: 0.4,
    maxPrecipitation: 1.2,
    wind: 3.2,
    gust: 6,
    icon: 'rain',
    windDirection: -15,
  },
  {
    time: new Date(2026, 5, 9, 6, 0),
    temperature: 15,
    precipitation: 1.8,
    maxPrecipitation: 3.2,
    wind: 4.1,
    gust: 7,
    icon: 'rain',
    windDirection: -45,
  },
  {
    time: new Date(2026, 5, 9, 8, 0),
    temperature: 16,
    precipitation: 3.9,
    maxPrecipitation: 5.4,
    wind: 5.5,
    gust: 9,
    icon: 'rain',
    windDirection: -70,
  },
  {
    time: new Date(2026, 5, 9, 10, 0),
    temperature: 19,
    precipitation: 2.8,
    maxPrecipitation: 4.7,
    wind: 3.8,
    gust: 8,
    icon: 'rain',
    windDirection: -95,
  },
  {
    time: new Date(2026, 5, 9, 12, 0),
    temperature: 21,
    precipitation: 1.2,
    maxPrecipitation: 3.1,
    wind: 4.4,
    gust: 7,
    icon: 'partly-cloudy',
    windDirection: -35,
  },
  {
    time: new Date(2026, 5, 9, 14, 0),
    temperature: 19,
    precipitation: 0.3,
    maxPrecipitation: 1.4,
    wind: 4.6,
    gust: 7,
    icon: 'partly-cloudy',
    windDirection: 15,
  },
  {
    time: new Date(2026, 5, 9, 16, 0),
    temperature: 16,
    precipitation: 0,
    maxPrecipitation: 0.5,
    wind: 4.7,
    gust: 6,
    icon: 'cloud',
    windDirection: 35,
  },
  {
    time: new Date(2026, 5, 9, 18, 0),
    temperature: 15,
    precipitation: 0,
    maxPrecipitation: 0,
    wind: 4.4,
    gust: 6,
    icon: 'cloud',
    windDirection: 20,
  },
];
