import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import MenuItem from '@mui/material/MenuItem';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import { ScatterChart } from '@mui/x-charts/ScatterChart';
import { BarChart } from '@mui/x-charts/BarChart';
import { LineChart } from '@mui/x-charts/LineChart';
import { PieChart } from '@mui/x-charts/PieChart';
import { data } from './randomData';

const highlightScope = { highlight: 'item', fade: 'global' };

const scatterSeries = [
  {
    label: 'Series A',
    data: data.map((v) => ({ x: v.x1, y: v.y1, id: v.id })),
    highlightScope,
  },
  {
    label: 'Series B',
    data: data.map((v) => ({ x: v.x1, y: v.y2, id: v.id })),
    highlightScope,
  },
];

const series = [
  { label: 'Series A', data: data.map((p) => p.y1), highlightScope },
  { label: 'Series B', data: data.map((p) => p.y2), highlightScope },
];

export default function KeyboardNavigation() {
  const [chartType, setChartType] = React.useState('line');
  const [focusItemOnClick, setFocusItemOnClick] = React.useState(false);
  const chartRef = React.useRef(null);

  const handleChange = (event) => setChartType(event.target.value);

  return (
    <Stack sx={{ width: '100%', display: 'block' }}>
      <Stack
        direction="row"
        sx={{ width: '100%', gap: 2, justifyContent: 'center', mb: 1 }}
      >
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel id="chart-type-label">Chart Type</InputLabel>
          <Select
            labelId="chart-type-label"
            id="chart-type-select"
            value={chartType}
            label="Chart Type"
            onChange={handleChange}
          >
            <MenuItem value="scatter">Scatter</MenuItem>
            <MenuItem value="line">Line</MenuItem>
            <MenuItem value="bar">Bar</MenuItem>
            <MenuItem value="pie">Pie</MenuItem>
          </Select>
        </FormControl>
        <Button
          onClick={() => {
            const element = chartRef.current?.querySelector('[tabindex="0"]');
            element?.focus();
          }}
          variant="contained"
        >
          Focus chart
        </Button>
        <FormControlLabel
          control={
            <Switch
              checked={focusItemOnClick}
              onChange={(event) => setFocusItemOnClick(event.target.checked)}
            />
          }
          label="focusItemOnClick"
        />
      </Stack>
      <Chart
        key={chartType}
        chartRef={chartRef}
        type={chartType}
        focusItemOnClick={focusItemOnClick}
      />
    </Stack>
  );
}

function Chart({ chartRef, type, focusItemOnClick }) {
  switch (type) {
    case 'scatter':
      return (
        <ScatterChart
          ref={chartRef}
          height={300}
          series={scatterSeries}
          focusItemOnClick={focusItemOnClick}
        />
      );

    case 'line':
      return (
        <LineChart
          ref={chartRef}
          height={300}
          xAxis={[{ data: data.map((p) => p.x1).toSorted((a, b) => a - b) }]}
          series={series}
          slotProps={{ tooltip: { trigger: 'item' } }}
          focusItemOnClick={focusItemOnClick}
        />
      );

    case 'bar':
      return (
        <BarChart
          ref={chartRef}
          height={300}
          xAxis={[
            { data: data.map((p) => Math.round(p.x1)).toSorted((a, b) => a - b) },
          ]}
          slotProps={{ tooltip: { trigger: 'item' } }}
          series={series}
          focusItemOnClick={focusItemOnClick}
        />
      );

    case 'pie':
      return (
        <PieChart
          ref={chartRef}
          series={[
            {
              arcLabel: 'value',
              data: [
                { id: 0, value: 10, label: 'series A' },
                { id: 1, value: 15, label: 'series B' },
                { id: 2, value: 20, label: 'series C' },
              ],
              highlightScope,
            },
          ]}
          height={300}
          hideLegend={false}
          focusItemOnClick={focusItemOnClick}
        />
      );

    default:
      throw new Error(`Unknown chart type: ${type}`);
  }
}
