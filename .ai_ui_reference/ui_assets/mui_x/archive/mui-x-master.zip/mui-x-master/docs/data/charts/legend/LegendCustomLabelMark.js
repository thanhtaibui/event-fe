import { BarChart } from '@mui/x-charts/BarChart';

function HTMLCircle({ className, color }) {
  return (
    <div className={className} style={{ borderRadius: '100%', background: color }} />
  );
}

function SVGDiamond({ className, color }) {
  return (
    <svg viewBox="-7.423 -7.423 14.846 14.846">
      <path
        className={className}
        d="M0,-7.423L4.285,0L0,7.423L-4.285,0Z"
        fill={color}
      />
    </svg>
  );
}

export default function LegendCustomLabelMark() {
  return (
    <BarChart
      series={[
        { id: 'id-0', data: [10, 15], label: 'Series A', labelMarkType: HTMLCircle },
        { id: 'id-1', data: [15, 20], label: 'Series B', labelMarkType: 'line' },
        { id: 'id-2', data: [20, 25], label: 'Series C' },
        { id: 'id-3', data: [10, 15], label: 'Series D', labelMarkType: SVGDiamond },
      ]}
      xAxis={[{ data: ['Category 1', 'Category 2'] }]}
      height={200}
    />
  );
}
