# Changelog

## 9.14.0

_Sep 17, 2026_

We'd like to extend a big thank you to the 16 contributors who made this release possible. Here are some highlights ✨:

- 🌍 Add Hebrew (he-IL) locale to the Scheduler
- 📅 Scheduler time grid now opens at 7 AM by default, configurable with the new `initialScrollTime` prop
- 🗓️ Auto-scheduling engine for finish-to-start dependencies in the Premium Event Timeline
- 🧩 New content slots for the Event Timeline event block and resource title cell
- ♿️ Charts announce the visible zoom range to screen readers
- 🐞 Bugfixes
- 📚 Documentation improvements

Special thanks go out to these community members for their valuable contributions:
@eterry1388, @jamesDin, @kareem-ib, @mateuseap, @mustafajw07

The following team members contributed to this release:
@arminmeh, @bernardobelchior, @brijeshb42, @flaviendelangle, @hasdfa, @Janpot, @JCQuintas, @MBilalShafi, @michelengelen, @noraleonte, @rita-codes

### Data Grid

#### `@mui/x-data-grid@9.14.0`

- [DataGrid] Do not crash on unmount when the document has no body (#23431) @eterry1388
- [DataGrid] Fix `MissingRowIdError` on cell `mousedown`/`mouseup` after row removal (#23261) @kareem-ib
- [DataGrid] Fix quick filter dropping a pending search on parser identity change (#23575) @michelengelen
- [DataGrid] Keep overlays sticky in RTL mode (#23492) @arminmeh
- [DataGrid] Prevent scroll area state update before mount (#23478) @michelengelen
- [DataGrid] Remove `'menu'` role from the actions cell (#23437) @michelengelen

#### `@mui/x-data-grid-pro@9.14.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.14.0`, plus:

- [DataGridPro] Fix data integrity issue in nested server data (#23518) @MBilalShafi
- [DataGridPro] Keep parent selection when lazily loaded children arrive (#23421) @michelengelen

#### `@mui/x-data-grid-premium@9.14.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.14.0`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.14.0`

Internal changes.

#### `@mui/x-date-pickers-pro@9.14.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.14.0`.

### Charts

#### `@mui/x-charts@9.14.0`

- [charts] Announce the visible zoom range to screen readers (#23371) @JCQuintas
- [charts] Fix Premium chart zoom props and `apiRef` forwarding (#23590) @bernardobelchior

#### `@mui/x-charts-pro@9.14.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.14.0`.

#### `@mui/x-charts-premium@9.14.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.14.0`, plus:

- [charts-premium] Add the Excel data extraction layer (#23569) @JCQuintas
- [charts-premium] Forward `apiRef` on `RadialBarChart` and `RadialLineChart` (#23625) @JCQuintas

### Tree View

#### `@mui/x-tree-view@9.14.0`

- [tree view] Optimize lazy loading store writes for nested children (#23489) @noraleonte
- [tree view] Prune stale children when replacing an item's children (#23598) @JCQuintas

#### `@mui/x-tree-view-pro@9.14.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.14.0`.

### Scheduler

#### Breaking changes

- The `dataSource` prop has been removed from the Community Event Calendar components:
  `EventCalendar`, `StandaloneDayView`, `StandaloneWeekView`, `StandaloneMonthView`,
  `StandaloneAgendaView`, `StandaloneCompactDayView`, `StandaloneCompactThreeDayView` and
  `StandaloneCompactWeekView`.

  Lazy loading has always been Premium-only, and the prop never had any effect on these
  components: it left the calendar in a permanent loading state. To load events through a data
  source, use `EventCalendarPremium` (or the Premium standalone views) and `EventTimelinePremium`,
  where `dataSource` is unchanged.

  ```diff
  -import { EventCalendar } from '@mui/x-scheduler/event-calendar';
  +import { EventCalendarPremium } from '@mui/x-scheduler-premium/event-calendar-premium';

  -<EventCalendar dataSource={dataSource} />
  +<EventCalendarPremium dataSource={dataSource} />
  ```

#### `@mui/x-scheduler@9.0.0-beta.12`

- [l10n] Add Hebrew (he-IL) locale (#23577) @jamesDin
- [scheduler] Add content slots for the Event Timeline event block and resource title cell (#23557) @rita-codes
- [scheduler] Fix `onPreferencesChange` never being called on `EventCalendar` (#23568) @rita-codes
- [scheduler] Fix flaky timeline observer absorb (#23523) @JCQuintas
- [scheduler] Open the time grid at 7 AM by default and add `initialScrollTime` (#23594) @rita-codes
- [scheduler] Pin sibling scheduler packages to exact versions (#23574) @rita-codes
- [scheduler] Read form initialization settings without subscriptions (#23614) @flaviendelangle
- [scheduler] Remove `dataSource` from the Community components (#23483) @mustafajw07
- [scheduler] Remove redundant recurrence subscriptions (#23610) @flaviendelangle
- [scheduler] Remove unused more-events popover count (#23619) @flaviendelangle
- [scheduler] Remove unused refs (#23616) @flaviendelangle
- [scheduler] Reuse precomputed timeline duration (#23620) @flaviendelangle
- [scheduler] Reuse recurrence option labels (#23609) @flaviendelangle
- [scheduler] Reuse recurrence presets for form drafts (#23615) @flaviendelangle
- [scheduler] Simplify month-view overflow counting (#23617) @flaviendelangle
- [scheduler] Use form store state to guard submissions (#23613) @flaviendelangle

#### `@mui/x-scheduler-premium@9.0.0-beta.12` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.12`, plus:

- [scheduler-premium] Dependencies - Arrows and terminals for SS, FF and SF (#23524) @rita-codes
- [scheduler-premium] Dependencies - Auto-scheduling engine (FS) (#23439) @rita-codes

### Docs

- [DataGrid][docs] Fix "Apply filters on demand" demo (#23602) @mateuseap
- [docs] Add recipe for getting the tree view's root DOM element via `ref` (#22941) @michelengelen
- [docs][pickers] Mention `Moment.js` maintenance mode (#23601) @mateuseap

### Core

- [code-infra] Gate the `DataGridScrollRestoration` screenshot on the horizontal restore (#23527) @JCQuintas
- [code-infra] Let the `NoColumnsOverlay` demo settle before screenshotting (#23529) @JCQuintas
- [code-infra] Pin the only-allow version in the preinstall hook (#23551) @Janpot
- [code-infra] Remove disabled Discord release announcement workflow (#23554) @Janpot
- [code-infra] Trial: Claude CI flake-fix caller (#23556) @Janpot

### Miscellaneous

- [chat] Add feedback form to the docs (#23403) @hasdfa
- [ci] Grant actions: read to the flake-fix caller (#23560) @Janpot
- [ci] Update flake-fix caller to mui-public#1849 (#23571) @Janpot

## 9.13.0

<!-- generated comparing v9.12.0..master -->

_Sep 4, 2026_

We'd like to extend a big thank you to the 14 contributors who made this release possible. Here are some highlights ✨:

- 🦮 Improve keyboard navigation features of the Charts.
- 🎨 Improved customization of the edit event dialog in the `EventCalendar`
- 🐞 Bugfixes
- 📚 Documentation improvements

Special thanks go out to these community members for their valuable contributions:
@Anexus5919, @jvskriubakken, @mustafajw07, @roychan1

The following team members contributed to this release:
@brijeshb42, @flaviendelangle, @hasdfa, @Janpot, @JCQuintas, @LukasTy, @michelengelen, @noraleonte, @rita-codes, @silviuaavram

### Data Grid

#### `@mui/x-data-grid@9.13.0`

- [DataGrid] Call `onValueChange` after `setEditCellValue` in edit cells (#23417) @michelengelen
- [DataGrid] Add support for replacing rows instead of merging updates (#23323) @jvskriubakken
- [DataGrid] Always render `rowHeader` in virtualized setups (#23386) @silviuaavram
- [DataGrid] Export `ToolbarRoot` (#23322) @JCQuintas
- [DataGrid] Fix `rowsPerPage` selector appearing when `autoPageSize` is enabled and `pageSize` is one of `pageSizeOptions` (#23401) @roychan1
- [DataGrid] Fix row tree reset when a data source grid becomes visible (#23288) @JCQuintas

#### `@mui/x-data-grid-pro@9.13.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.13.0`, plus:

- [DataGridPro] Remove rows deleted server-side on nested lazy loading revalidation (#23320) @JCQuintas
- [DataGridPro] Stop `disableDebounce` from reaching the DOM in multi select filter (#23445) @JCQuintas

#### `@mui/x-data-grid-premium@9.13.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.13.0`, plus:

- [DataGridPremium] Refine cell selection and speed up clipboard copy (#23473) @michelengelen
- [DataGridPremium] Select all cells with Ctrl+A (#23415) @michelengelen

### Date and Time Pickers

#### `@mui/x-date-pickers@9.13.0`

Internal changes.

#### `@mui/x-date-pickers-pro@9.13.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.13.0`.

### Charts

#### `@mui/x-charts@9.13.0`

- [charts] Activate the focused axis with Enter/Space (#23219) @JCQuintas
- [charts] Add keyboard zoom and pan (#23369) @JCQuintas
- [charts] Fix line mark position under browser zoom in Safari (#23387) @noraleonte
- [charts] Fix y axis tick labels shortened near the top of the chart (#23435) @JCQuintas
- [charts] Focus the clicked item on radar charts (#23287) @JCQuintas
- [charts] Stop text measurements leaking into each other (#23430) @JCQuintas

#### `@mui/x-charts-pro@9.13.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.13.0`.

#### `@mui/x-charts-premium@9.13.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.13.0`.

### Tree View

#### `@mui/x-tree-view@9.13.0`

- [tree view] Add `loading` prop and customizable loading UI (#22251) @michelengelen
- [tree view] Reduce selector bundle size (#23412) @flaviendelangle
- [tree view] Remove dead UI from community component (#23487) @noraleonte
- [tree view] Remove unused dependencies (#23488) @noraleonte
- [tree view] Use `useId` for the default tree id (#23341) @Anexus5919

#### `@mui/x-tree-view-pro@9.13.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.13.0`.

### Scheduler

#### `@mui/x-scheduler@9.0.0-beta.11`

- [scheduler] Absorb un-acted `ResizeObserver` deliveries after rendering the timeline (#23444) @rita-codes
- [scheduler] Add `EventContextMenu` with Edit and Delete actions (#23379) @mustafajw07
- [scheduler] Add aria-hidden to collapsed side panel and refactor landmark structure (#23425) @mustafajw07
- [scheduler] Add the `eventDialogGeneralTab` slot (#23338) @rita-codes
- [scheduler] Fix the un-awaited act warning in the event dialog slot test (#23446) @JCQuintas
- [scheduler] Improve timeline event layout performance (#23364) @flaviendelangle
- [scheduler] Keep `aria-expanded` present when ViewSwitcher and PreferencesMenu menus are closed (#23427) @mustafajw07
- [scheduler] Make the event dialog General-tab building blocks public (#23398) @rita-codes
- [scheduler] Migrate to the pragmatic-drag-and-drop v3 entry points (#23442) @rita-codes
- [scheduler] Reduce selector bundle size (#23413) @flaviendelangle
- [scheduler] Reuse processed events between updates (#23363) @flaviendelangle
- [scheduler] Add `aria-expanded` and `aria-controls` to side panel toggle button (#23402) @mustafajw07

#### `@mui/x-scheduler-premium@9.0.0-beta.11` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.11`, plus:

- [scheduler-premium] Dependencies - Keep event drags working over the arrow hit-areas (#23441) @rita-codes
- [scheduler-premium] Dependencies - Reject dependencies that would create a cycle (#23389) @rita-codes
- [scheduler-premium] Key recurring `exDates` on their data-timezone day (#23467) @rita-codes

### Codemod

#### `@mui/x-codemod@9.13.0`

Internal changes.

### Docs

- [docs] Add synchronized tooltip and crosshair demo to charts (#23368) @JCQuintas
- [docs] Add sticky headers recipe to `RichTreeView` customization (#22908) @michelengelen
- [docs] Pin the visible date of the scheduler preferences demos (#23432) @rita-codes
- [docs] Star-prefix bare :where() dark-mode selectors (#23419) @Janpot
- [docs] Consolidate demo data into shared dataset files (#23496) @michelengelen

### Core

- [code-infra] Consume shared commands from code-infra orb (#23485) @brijeshb42
- [code-infra] Move the shared spy helpers off Sinon (#23466) @JCQuintas
- [code-infra] Point the support validator link at frontend-public (#23422) @Janpot
- [code-infra] Reduce per-page memory in the browser test suite (#23424) @Janpot
- [code-infra] Remove Sinon (#23476) @JCQuintas
- [code-infra] Remove the explicit `styled-components` dependency (#23479) @LukasTy
- [code-infra] Replace the mechanical sinon `spy()` usages with `vi.fn()` (#23443) @JCQuintas
- [code-infra] Replace the sinon `spy(fn)` usages with `vi.fn(fn)` (#23460) @JCQuintas
- [code-infra] Replace the sinon spy types with the Vitest ones (#23464) @JCQuintas
- [code-infra] Replace the sinon spy-on-object calls with `vi.spyOn` (#23474) @JCQuintas
- [code-infra] Replace the sinon stubs with Vitest mocks (#23472) @JCQuintas
- [code-infra] Run TypeScript 7 alongside the TS6 JS API (#23471) @brijeshb42
- [code-infra] Trim the shared browser test setup graph (#23426) @LukasTy
- [code-infra] Update CircleCI orb (#23418) @JCQuintas
- [code-infra] Use explicit vitest imports in test files (#23375) @michelengelen

### Miscellaneous

- [chat] Enforce top-level type imports (#23037) @Janpot
- [chat] Fix global preload error from the `remend` import (#23263) @hasdfa
- [ci] Add Claude PR review via mui-public reusable workflow (#23423) @Janpot
- [telemetry] Fix get-context test leaking mock from sender test (#23447) @JCQuintas
- [test] Fail the regression run when a webfont does not load (#23376) @LukasTy

## 9.12.0

_Aug 21, 2026_

We'd like to extend a big thank you to the 12 contributors who made this release possible. Here are some highlights ✨:

- 🧮 Support [Formulas](https://mui.com/x/react-data-grid/formulas/) on the Data Grid: cells in opted-in columns can hold spreadsheet-like formulas (`=SUM(RANGE(…))`, `=price * quantity`) evaluated by a built-in engine, with a formula editor and [Formula Bar](https://mui.com/x/react-data-grid/components/formula-bar/), autocomplete, reference highlighting, optional A1 notation, fill-handle reference adjustment, custom functions, and live formula Excel export
- ♿️ Improve the accessibility of Data Grid cells and picker day cells
- 🗓️ Enable multi-resource event creation and editing in the Scheduler
- 🐞 Bugfixes
- 📚 Documentation improvements

Special thanks go out to these community members for their valuable contributions:
@Anexus5919, @mustafajw07

The following team members contributed to this release:
@brijeshb42, @flaviendelangle, @JCQuintas, @LukasTy, @MBilalShafi, @michelengelen, @noraleonte, @rita-codes, @romgrk, @silviuaavram

### Data Grid

#### `@mui/x-data-grid@9.12.0`

- [DataGrid] Expose `apiRef` on `GridCallbackDetails` for selector access in callbacks (#22973) @michelengelen
- [DataGrid] Fix header height not updating when `headerFilters` or `columnGroupingModel` change (#23059) @MBilalShafi
- [DataGrid] Fix unhandled rejection when unmounting mid-autosize (#23319) @JCQuintas
- [DataGrid] Label the blank `singleSelect` filter option (#23294) @JCQuintas
- [DataGrid] Stop sending incomplete filter items to the data source (#23303) @JCQuintas
- [DataGrid] Support the `rowheader` attribute for grid cells (#23340) @silviuaavram

#### `@mui/x-data-grid-pro@9.12.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.12.0`, plus:

- [DataGridPro] Honor `hasNextPage` in infinite lazy loading (#23048) @MBilalShafi

#### `@mui/x-data-grid-premium@9.12.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.12.0`, plus:

- [DataGridPremium] Formula support (#22807) @MBilalShafi

### Date and Time Pickers

#### `@mui/x-date-pickers@9.12.0`

- [fields] Keep the selected section on blank space clicks (#23318) @LukasTy
- [pickers] Associate the day cells with their week day column header (#23339) @LukasTy
- [pickers] Keep the `gridcell` role and the column index on filler cells (#23326) @Anexus5919

#### `@mui/x-date-pickers-pro@9.12.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.12.0`, plus:

- [DateRangeCalendar] Round the range highlight at the month grid edges (#23297) @JCQuintas
- [DateRangePicker] Keep the range highlight opaque for disabled days (#23317) @JCQuintas

### Charts

#### `@mui/x-charts@9.12.0`

- [charts] Add a demo for label on grid row (#23333) @noraleonte
- [charts] Fix React 18 `propTypes` warnings and stray-pointer test flakiness (#23384) @LukasTy
- [charts] Focus the clicked item for keyboard navigation (#23247) @JCQuintas

#### `@mui/x-charts-pro@9.12.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.12.0`.

#### `@mui/x-charts-premium@9.12.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.12.0`, plus:

- [charts-premium] Add `onItemClick` to the radial charts (#23253) @JCQuintas

### Tree View

#### `@mui/x-tree-view@9.12.0`

Internal changes.

#### `@mui/x-tree-view-pro@9.12.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.12.0`.

### Scheduler

#### `@mui/x-scheduler@9.0.0-beta.10`

- [scheduler] Add `onEventEditingStart` to let consumers open their own edit UI (#23361) @rita-codes
- [scheduler] Fix keyboard and focus issues around the "+N more" popover (#23312) @rita-codes
- [scheduler] Honor `viewConfig` hour limits in the compact day and week views (#23316) @rita-codes
- [scheduler] Share timeline event layout data (#23366) @flaviendelangle
- [scheduler] enable multi-resource event creation and editing (#23313) @mustafajw07

#### `@mui/x-scheduler-premium@9.0.0-beta.10` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.10`, plus:

- [scheduler-premium] Allow to control the min and max hour in the Event Timeline (#23212) @rita-codes
- [scheduler-premium] Dependencies - Create, select and delete via terminals (#23200) @rita-codes

### Codemod

#### `@mui/x-codemod@9.12.0`

Internal changes.

### Docs

- [docs][charts] Document line mark size customization (#23370) @JCQuintas
- [docs] Add recipe for constraining the `make-child` drop action by item type (#22940) @michelengelen
- [docs] Redirect the renamed Event Timeline views page (#23324) @brijeshb42
- [docs] Remove unused `adapter-dependencies.json` (#23328) @LukasTy

### Core

- [code-infra] Add release skill (#23308) @brijeshb42
- [code-infra] Fix changelog categorization of docs and `DateRangeCalendar` tags (#23385) @JCQuintas
- [code-infra] Sync mui-release skill (#23330) @brijeshb42

### Miscellaneous

- [core] Declare the missing `react-dom` peer dependencies (#23381) @LukasTy
- [test] Fix act warnings in the data source filter tests (#23360) @JCQuintas
- [virtualizer] Add inverse-sticky layout (#23053) @romgrk

## 9.11.1

_Aug 6, 2026_

We'd like to extend a big thank you to the 2 contributors who made this release possible. Here are some highlights ✨:

- 🐛 Fix the empty `@mui/x-charts-vendor` package published in v9.11.0

The following team members contributed to this release:
@JCQuintas, @rita-codes

### Charts

#### `@mui/x-charts@9.11.1`

- [charts] Fix empty `@mui/x-charts-vendor` published package (#23310) @JCQuintas

#### `@mui/x-charts-pro@9.11.1` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.11.1`.

#### `@mui/x-charts-premium@9.11.1` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.11.1`.

#### `@mui/x-charts-vendor@9.11.1`

- [charts] Fix empty `@mui/x-charts-vendor` published package (#23310) @JCQuintas

### Scheduler

#### `@mui/x-scheduler@9.0.0-beta.9`

- [scheduler] Show the range validation errors on the End date and End time fields (#23291) @rita-codes

#### `@mui/x-scheduler-premium@9.0.0-beta.9` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.9`.

## 9.11.0

_Aug 6, 2026_

We'd like to extend a big thank you to the 14 contributors who made this release possible. Here are some highlights ✨:

- ✨ Add `addItems()` and `getItemSelection()` API methods to Tree View

Special thanks go out to these community members for their valuable contributions:
@12joan, @Anexus5919, @kevincorizi-sbt, @mixelburg, @mustafajw07, @strazto

The following team members contributed to this release:
@flaviendelangle, @hasdfa, @JCQuintas, @LukasTy, @MBilalShafi, @michelengelen, @noraleonte, @rita-codes

### Data Grid

#### `@mui/x-data-grid@9.11.0`

- [DataGrid] Fix `updateRows` stripping class prototypes from rows in datasource mode (#22288) @mixelburg
- [DataGrid] Do not re-fetch data when an `Activity` becomes visible (#22603) @12joan
- [DataGrid] Fix toolbar button stealing focus when a sibling's disabled state changes (#23204) @MBilalShafi

#### `@mui/x-data-grid-pro@9.11.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.11.0`.

#### `@mui/x-data-grid-premium@9.11.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.11.0`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.11.0`

- [pickers] Fix day shift when editing dates predating timezone standardization (#23296) @JCQuintas

#### `@mui/x-date-pickers-pro@9.11.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.11.0`, plus:

- [DateRangePicker] Fix disabled filler cells showing the range highlight (#23293) @JCQuintas

### Charts

#### `@mui/x-charts@9.11.0`

- [charts] Activate the focused item with `Enter`/`Space` (#23218) @JCQuintas
- [charts] Extract the axis click payload builders (#23215) @JCQuintas
- [charts] Fix `GestureManager` event listener leak on chart unmount (#23283) @kevincorizi-sbt
- [charts] Fix `slotProps.legend.position` and `direction` in `RadarChart` (#23254) @JCQuintas
- [charts] Fix axis clicks being discarded on slight pointer movement (#23244) @noraleonte
- [charts] Fix image export of charts sized by their parent element (#23255) @JCQuintas
- [charts] Forward `experimentalFeatures` on `RadarChart` and `Heatmap` (#23216) @JCQuintas
- [charts] Hide focus indicator when the chart loses focus (#23213) @JCQuintas

#### `@mui/x-charts-pro@9.11.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.11.0`.

#### `@mui/x-charts-premium@9.11.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.11.0`, plus:

- [charts-premium] Fix `RangeBar` type override (#23217) @JCQuintas

### Tree View

#### `@mui/x-tree-view@9.11.0`

- [tree view] Add `addItems()` API method (#23159) @JCQuintas
- [tree view] Add `getItemSelection` API method (#23257) @noraleonte
- [tree view] Ignore `keepExistingSelection` when `multiSelect` is `false` (#23242) @JCQuintas
- [tree view] Prevent duplicate ids in multi-select arrow navigation (#23006) @Anexus5919

#### `@mui/x-tree-view-pro@9.11.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.11.0`, plus:

- [tree view] Discard superseded lazy-loading responses (#23005) @Anexus5919

### Scheduler

#### `@mui/x-scheduler@9.0.0-beta.8`

- [scheduler] Add `localeText` prop to standalone views (#23210) @rita-codes
- [scheduler] Finetune touch experience for time grid events and introduce editing drawer (#22624) @noraleonte
- [scheduler] Introduce the edit dialog form context & lifecycle contract (#23284) @rita-codes
- [scheduler] Refactor edit dialog General tab into section components (#23206) @rita-codes
- [scheduler] Replace copied Base UI internals with `@base-ui/react/internals` imports (#21972) @flaviendelangle
- [scheduler] Hide resource picker when no resources are provided (#23290) @mustafajw07
- [scheduler] Support multi-resource occurrences in `EventTimeline` (#23240) @mustafajw07

#### `@mui/x-scheduler-premium@9.0.0-beta.8` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.8`.

### Codemod

#### `@mui/x-codemod@9.11.0`

- [codemod] Remove unused `@babel/core` and `@babel/traverse` dependencies (#23245) @LukasTy

### Docs

- [docs] Add recipe for adding new rows from clipboard copy (#22913) @michelengelen
- [docs] Clarify the package versions in v8 upgrade guides (#22376) @strazto
- [docs] Replace README peer dependency lists with an npm install command (#23256) @LukasTy

### Core

- [code-infra] Align action pin version comments (#23238) @LukasTy

### Miscellaneous

- [chat] Drop the undeclared `@mui/icons-material` dependency (#23252) @LukasTy
- [chat] Sanitize image part URLs and share the URL allow-list with markdown (#23058) @hasdfa
- [test] Type the `PickersTextField` test stub instead of `as any` (#23194) @LukasTy

## 9.10.1

_Jul 23, 2026_

We'd like to extend a big thank you to the 11 contributors who made this release possible. Here are some highlights ✨:

- 🦮 Improve accessibility of the Charts and Pickers components.
- 🐞 Bugfixes
- 📚 Documentation improvements

Special thanks go out to these community members for their valuable contributions:
@kevincorizi-sbt, @mustafajw07, @SamanPandey-in

The following team members contributed to this release:
@brijeshb42, @hasdfa, @JCQuintas, @LukasTy, @michelengelen, @noraleonte, @rita-codes, @silviuaavram

### Data Grid

#### `@mui/x-data-grid@9.10.1`

- [data grid] Fix `getColumn` return type not reflecting that it can return undefined (#23165) @JCQuintas

#### `@mui/x-data-grid-pro@9.10.1` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.10.1`.

#### `@mui/x-data-grid-premium@9.10.1` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.10.1`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.10.1`

- [pickers] Fix format placeholder brightness with a start adornment (#23189) @LukasTy

#### `@mui/x-date-pickers-pro@9.10.1` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.10.1`, plus:

- [DateRangePicker] Fix broken active range position underline in single input range fields (#23166) @LukasTy

### Charts

#### `@mui/x-charts@9.10.1`

- [charts] Fix pie chart disappearing when an arc spans almost the full circle (#23145) @JCQuintas
- [charts] Set `aria-hidden` on accessibility proxy divs at initialization (#23186) @kevincorizi-sbt
- [charts] Fix keyboard navigation on series with different lengths (#23182) @JCQuintas
- [charts] Fix out of bounds keyboard navigation (#23180) @silviuaavram

#### `@mui/x-charts-pro@9.10.1` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.10.1`, plus:

- [charts-pro] Fix highlight shifting on sampled bar charts (#23190) @noraleonte
- [charts-pro] Sampled band highlight falls back to single-band width for Date/object values (#23024) @SamanPandey-in

#### `@mui/x-charts-premium@9.10.1` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.10.1`.

### Tree View

#### `@mui/x-tree-view@9.10.1`

- [TreeView] Fix selection propagation to exclude disabled items (#23012) @michelengelen

#### `@mui/x-tree-view-pro@9.10.1` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.10.1`.

### Scheduler

#### `@mui/x-scheduler@9.0.0-beta.7`

- [scheduler] Polish `EventCalendar` rendering for multi-resource events (#23161) @mustafajw07
- [scheduler] Responsive header (#22954) @noraleonte

#### `@mui/x-scheduler-premium@9.0.0-beta.7` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.7`, plus:

- [scheduler-premium] Add the dependencies data model (#23117) @rita-codes
- [scheduler-premium] Dependencies - Render the FS arrow (#23162) @rita-codes

### Codemod

#### `@mui/x-codemod@9.10.1`

Internal changes.

### Docs

- [docs] Fix clearing, layout shift, and prop leak in Pickers demos (#23191) @LukasTy

### Core

- [code-infra] Validate working of specific code-infra canary (#23207) @brijeshb42

### Miscellaneous

- [chat] Normalize message part link URLs (#23187) @hasdfa
- [x-chat] Fix object URL leaks for submitted attachments (#23198) @hasdfa
- [internals] Make disposable types self-contained without `esnext.disposable` lib (#23164) @JCQuintas

## 9.10.0

_Jul 17, 2026_

We'd like to extend a big thank you to the 7 contributors who made this release possible. Here are some highlights ✨:

- 📊 Provide `dataIndex` in `LinePlot` and `AreaPlot` `onItemClick` for Charts
- ⚙️ Allow opt-in `data-*` attributes on `slotProps`. [Read more](https://mui.com/x/common-concepts/custom-components/#passing-data-attributes-to-slots)
- 🐞 Bugfixes
- 📚 Documentation improvements

Special thanks go out to these community members for their valuable contributions:
@Anexus5919, @mustafajw07

The following team members contributed to this release:
@brijeshb42, @Janpot, @JCQuintas, @LukasTy, @noraleonte

### Data Grid

#### `@mui/x-data-grid@9.10.0`

Internal changes.

#### `@mui/x-data-grid-pro@9.10.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.10.0`.

#### `@mui/x-data-grid-premium@9.10.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.10.0`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.10.0`

Internal changes.

#### `@mui/x-date-pickers-pro@9.10.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.10.0`.

### Charts

#### `@mui/x-charts@9.10.0`

- [charts] Provide `dataIndex` in `LinePlot` and `AreaPlot` `onItemClick` (#23144) @JCQuintas

#### `@mui/x-charts-pro@9.10.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.10.0`.

#### `@mui/x-charts-premium@9.10.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.10.0`.

### Tree View

#### `@mui/x-tree-view@9.10.0`

Internal changes.

#### `@mui/x-tree-view-pro@9.10.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.10.0`, plus:

- [tree-view] Fix pre-loaded items not caching (#23155) @noraleonte

### Scheduler

#### `@mui/x-scheduler@9.0.0-beta.6`

- [scheduler] Carry custom event data through the edit dialog submit (#22874) @Anexus5919
- [scheduler] Support array values for `CalendarEvent.resource` (#23109) @mustafajw07

#### `@mui/x-scheduler-premium@9.0.0-beta.6` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.6`.

### Chat

#### `@mui/x-chat@9.0.0-alpha.14`

- [chat] Reuse `resolveComponentProps` from `@mui/utils` (#23095) @LukasTy

#### `@mui/x-chat-headless@9.0.0-alpha.14`

Internal changes.

### Codemod

#### `@mui/x-codemod@9.10.0`

Internal changes.

### Docs

- [docs] Fix bugs on Scheduler overview page (#23147) @noraleonte

### Core

- [code-infra] Fix changelog dependency exclusion and l10n routing (#23112) @LukasTy
- [code-infra] Port codebase to use `tsgo` (#22826) @brijeshb42
- [code-infra] Reduce `release:build` concurrency to mitigate `tsgo` OOM kills (#23139) @LukasTy
- [core] Allow opt-in `data-*` attributes on `slotProps` (#22128) @LukasTy

### Miscellaneous

- [core] Ignore `code-infra-renovate[bot]` commits in changelog (#23153) @Janpot
- [website] Fix broken `ChatBox` API link (#23149) @brijeshb42
- [test] Fix WebGL benchmark timeout on CI (#23142) @JCQuintas

## 9.9.0

_Jul 9, 2026_

We'd like to extend a big thank you to the 11 contributors who made this release possible. Here are some highlights ✨:

- 📊 [Data sampling](https://mui.com/x/react-charts/performance/#sampling) for better performance with large bar and line charts
- 🗺️ [Maps zoom support](https://mui.com/x/react-charts/map/#zoom)
- ☑️ Support [applying filters on demand](https://mui.com/x/react-data-grid/filtering/customization/#apply-filters-on-demand) in the Data Grid
- 🐞 Bugfixes
- 📚 Documentation improvements

Special thanks go out to these community members for their valuable contributions:
@mustafajw07, @sebastianfrey

The following team members contributed to this release:
@aemartos, @alexfauquette, @brijeshb42, @hasdfa, @Janpot, @JCQuintas, @LukasTy, @rita-codes, @sai6855

### Data Grid

#### `@mui/x-data-grid@9.9.0`

- [DataGrid] Add `dataSourceKeepPreviousData` prop (#22554) @LukasTy
- [DataGrid] Add controlled filter panel for applying filters on demand (#23023) @sebastianfrey

#### `@mui/x-data-grid-pro@9.9.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.9.0`.

#### `@mui/x-data-grid-premium@9.9.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.9.0`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.9.0`

Internal changes.

#### `@mui/x-date-pickers-pro@9.9.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.9.0`, plus:

- [DateRangeCalendar] Avoid unnecessary month switch when the value is already visible (#22996) @LukasTy

### Charts

#### `@mui/x-charts@9.9.0`

- [charts] Optimize and de-duplicate sampled axis-highlight band lookup (#23052) @JCQuintas
- [charts] Unify tooltip item position getter and selector into a single selector API (#23041) @alexfauquette
- [charts] Fix impossible condition in axis text angle warning (#23102) @sai6855

#### `@mui/x-charts-pro@9.9.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.9.0`, plus:

- [charts-pro] Add data sampling for large bar and line charts (#22830) @JCQuintas
- [charts-pro] Allow sampling on non-zoomable charts (#23051) @JCQuintas

#### `@mui/x-charts-premium@9.9.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

#### Breaking changes

The API of the `Unstable_ChartsGeoDataProviderPremium` got modified.
Props `scale`, `rotation`, and `translation` are replaced by props `view` and `initialView`.
Same behavior can be obtained with `view.zoomLevel`, `view.center`, and `view.translation`.
See the [zoom view section](https://mui.com/x/react-charts/map/#control) for detailed information

Same changes as in `@mui/x-charts-pro@9.9.0`, plus:

- [charts-premium] Maps zoom support (#22709) @alexfauquette

### Tree View

#### `@mui/x-tree-view@9.9.0`

Internal changes.

#### `@mui/x-tree-view-pro@9.9.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.9.0`.

### Scheduler

#### `@mui/x-scheduler@9.0.0-beta.5`

- [scheduler] Introduce event resource helper utilities (#23022) @mustafajw07
- [scheduler] Preserve multi-day event continuity across overflow (#22797) @mustafajw07

#### `@mui/x-scheduler-premium@9.0.0-beta.5` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.5`.

### Codemod

#### `@mui/x-codemod@9.9.0`

Internal changes.

### Docs

- [docs] Fix broken social preview image on shared docs links (#23055) @sai6855
- [docs] Review and clean up react-chat docs demos & gallery; fix actions-bar layout (#22993) @hasdfa
- [docs] Update the Pickers recommended date library bundle sizes (#23087) @LukasTy

### Core

- [mcp] Add `@mui/mcp` server and `@mui/x-agent-tools`. See the [README](https://github.com/mui/mui-x/blob/master/packages/mcp/README.md) for setup (#22947) @aemartos
- [code-infra] Avoid OOM in the Netlify docs build and CircleCI lint step (#23086) @LukasTy
- [code-infra] Group `@atlaskit/pragmatic-drag-and-drop` renovate updates (#23105) @LukasTy
- [code-infra] Validate npm publishing through dry run (#23038) @brijeshb42
- [docs-infra] Enable `webpackBuildWorker` to bound docs build memory (#23100) @Janpot

### Miscellaneous

- [test] Fix flaky "should render only the pageSize" Data Grid virtualization test (#23090) @LukasTy
- [test] Track `@mui/x-chat` bundle size via native expand (#23049) @Janpot

## 9.8.0

_Jul 2, 2026_

We'd like to extend a big thank you to the 18 contributors who made this release possible. Here are some highlights ✨:

- 🗺️ New [`MapImagePlot`](https://mui.com/x/react-charts/map/) for rendering raster base maps, with `onItemClick` support on map shapes (Premium)
- 📊 New [`usePolarGeometry`](https://mui.com/x/react-charts/hooks/use-polar-geometry/) hook to build custom radial overlays
- 🐞 Bugfixes
- 📚 Documentation improvements

Special thanks go out to these community members for their valuable contributions:
@Anexus5919, @aromanio, @greymoth-jp, @mustafajw07, @timbuckley, @voidmatcha

The following team members contributed to this release:
@alexfauquette, @arminmeh, @cherniavskii, @flaviendelangle, @Janpot, @JCQuintas, @joserodolfofreitas, @LukasTy, @mapache-salvaje, @michelengelen, @rita-codes, @sai6855

### Data Grid

#### `@mui/x-data-grid@9.8.0`

- [DataGrid] Prevent cell editing from resurrecting a deleted row (#22958) @Anexus5919
- [DataGrid] Avoid reading `type` of `undefined` in `gridRowUtils` (#21808) @timbuckley
- [DataGrid] Improved get started tutorial (#22911) @joserodolfofreitas
- [l10n] Improve Japanese (ja-JP) locale (#23001) @greymoth-jp

#### `@mui/x-data-grid-pro@9.8.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.8.0`.

#### `@mui/x-data-grid-premium@9.8.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.8.0`, plus:

- [DataGridPremium] Escape `singleSelect` values in Excel export with `escapeFormulas` enabled (#22851) @Anexus5919

### Date and Time Pickers

#### `@mui/x-date-pickers@9.8.0`

- [pickers] Fix localized digit crash (#22995) @alexfauquette
- [pickers] Flag the first and last visible day cell across year boundaries (#22981) @Anexus5919
- [pickers] Use calendar day tokens in `AdapterMomentHijri` and `AdapterMomentJalaali` formats (#22974) @Anexus5919
- [pickers] Use the Hijri day token in `AdapterMomentHijri` `normalDateWithWeekday` (#22972) @Anexus5919
- [l10n] Improve Romanian (ro-RO) locale (#22969) @aromanio

#### `@mui/x-date-pickers-pro@9.8.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.8.0`, plus:

- [DateRangeCalendar] Fix auto month-switch across the year boundary (#22987) @Anexus5919

### Charts

#### `@mui/x-charts@9.8.0`

- [charts] Decouple `d3-geo` from the universal tooltip (#23011) @sai6855
- [charts] Deduplicate `getGroupingConfig` (#22889) @sai6855
- [charts] Expose `usePolarGeometry` hook for radial overlays (#22892) @mustafajw07

#### `@mui/x-charts-pro@9.8.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.8.0`.

#### `@mui/x-charts-premium@9.8.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.8.0`, plus:

- [charts-premium] Add `onItemClick` support for the Map shapes (#22876) @sai6855
- [charts-premium] Replace `dataIndex` with `name` in map identifier (#22891) @sai6855
- [charts-premium] Share helper function (#23030) @alexfauquette
- [charts-premium] Extract shared WebGL utilities across bar/scatter/heatmap renderers (#22466) @sai6855
- [charts-premium] Add `MapImagePlot` for raster base maps (#22977) @JCQuintas

### Tree View

#### `@mui/x-tree-view@9.8.0`

- [TreeView] Fix extra selection event when clicking a collapsed parent item (#22249) @michelengelen
- [TreeView] Enforce top-level type imports (#23034) @Janpot

#### `@mui/x-tree-view-pro@9.8.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.8.0`.

### Scheduler

#### `@mui/x-scheduler@9.0.0-beta.4`

- [scheduler] Enforce top-level type imports (#22931) @Janpot
- [scheduler] Keep the occurrence date when editing only one recurring event (#23007) @Anexus5919
- [scheduler] Track bundle size of scheduler packages (#22682) @flaviendelangle
- [scheduler] Add `viewConfig` prop to limit displayed hours in the day and week views (#22929) @flaviendelangle

#### `@mui/x-scheduler-premium@9.0.0-beta.4` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.4`, plus:

- [scheduler] Collapsible resources in the timeline (#22920) @rita-codes

### Codemod

#### `@mui/x-codemod@9.8.0`

Internal changes.

### Docs

- [docs] Add recipe for conditional master-detail panels (#22971) @michelengelen
- [docs] Add recipe for describing active filters in the toolbar (#22970) @michelengelen
- [docs] Add recipe for triggering clipboard copy from a button (#22967) @michelengelen
- [docs] Clarify that `fieldRef.current.focusField()` is the canonical way to focus a field (#22937) @michelengelen
- [docs][scheduler] Another copyediting pass across the Scheduler docs (#22619) @mapache-salvaje
- [docs][charts] Add map example for arbitrary GeoJSON shapes (#22976) @JCQuintas
- [docs][charts] Double point count in `ScatterAsyncRenderer` demo (#22906) @JCQuintas

### Core

- [code-infra] Fix tracking branch bug in release script (#22956) @michelengelen
- [code-infra] Remove mark-duplicate workflow (#22994) @cherniavskii
- [code-infra] Revert `nanoid@3.3.15` `minimumReleaseAge` exemption (#22953) @LukasTy

### Miscellaneous

- [internals] Fix `ERR_UNSUPPORTED_DIR_IMPORT` for `core-js-pure` in Node ESM (#22985) @michelengelen
- [internals] Harden `useDisposable` React internals read with safeReact (#22986) @rita-codes
- [internals] Replace core-js `DisposableStack` ponyfill with a minimal fallback (#23002) @sai6855
- [test] Assert the edited `dateTime` cell value in the e2e edit test (#22982) @voidmatcha
- [virtualizer] Remeasure scrollbars when layout changes (#22914) @arminmeh

## 9.7.0

_Jun 25, 2026_

We'd like to extend a big thank you to the 13 contributors who made this release possible. Here are some highlights ✨:

- 🐞 Bugfixes
- 📚 Documentation improvements

Special thanks go out to these community members for their valuable contributions:
@Anexus5919, @mustafajw07

The following team members contributed to this release:
@alexfauquette, @arminmeh, @brijeshb42, @Janpot, @JCQuintas, @LukasTy, @MBilalShafi, @michelengelen, @romgrk, @sai6855, @siriwatknp

### Data Grid

#### `@mui/x-data-grid@9.7.0`

- [DataGrid] Fix `CustomColumnMenuGrid` demo crashing (#22897) @sai6855
- [DataGrid] Fix crash in `getRowValue` when `colDef` is `undefined` (#22838) @LukasTy
- [DataGrid] Fix `longText` expand button submitting surrounding form (#22450) @siriwatknp
- [DataGrid] Remove filename ignore list from `removePropTypesPlugin` in Babel config (#22727) @sai6855
- [DataGrid] Deduplicate scroll-preserving focus logic (#22916) @sai6855
- [DataGrid] Fix `singleSelect` clearing to use empty string instead of `null` (#22881) @michelengelen
- [DataGrid] Wait for rows before reacting on `autosizeOnMount` (#22698) @MBilalShafi

#### `@mui/x-data-grid-pro@9.7.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.7.0`.

#### `@mui/x-data-grid-premium@9.7.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.7.0`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.7.0`

- [fields] Announce cardinal day in the day section `aria-valuetext` (#22922) @LukasTy
- [fields] Avoid focusing the field on blank space clicks (#22285) @LukasTy
- [pickers] Commit `TimeClock` value when the drag ends outside the clock (#22877) @LukasTy
- [pickers] Respect explicit `notched` prop on the outlined PickersTextField (#22875) @LukasTy

#### `@mui/x-date-pickers-pro@9.7.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.7.0`.

### Charts

#### `@mui/x-charts@9.7.0`

- [charts] Add demo for displaying the sum of all values from the stacked series on top of the stacked bars (#22879) @sai6855
- [charts] Add `zAxis` custom scatter component demo (#22746) @mustafajw07
- [charts] Apply axis `colorMap` to radial bar fill (#22800) @JCQuintas
- [charts] Simplify classes type (#22626) @alexfauquette
- [charts] Stable progressive scatter batching + responsive zoom/pan (#22862) @JCQuintas
- [charts] Strip dev-only console diagnostics from production (#22917) @sai6855
- [docs] Fix scatter renderer table blocking column (#22904) @JCQuintas
- [docs] Make `ScatterAsyncRenderer` button bar responsive (#22905) @JCQuintas

#### `@mui/x-charts-pro@9.7.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.7.0`.

#### `@mui/x-charts-premium@9.7.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.7.0`.

### Tree View

#### `@mui/x-tree-view@9.7.0`

Internal changes.

#### `@mui/x-tree-view-pro@9.7.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.7.0`.

### Scheduler

#### `@mui/x-scheduler@9.0.0-beta.3`

- [scheduler] Highlight only the edited occurrence of a recurring event (#22873) @Anexus5919

#### `@mui/x-scheduler-premium@9.0.0-beta.3` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.3`.

### Codemod

#### `@mui/x-codemod@9.7.0`

Internal changes.

### Core

- [code-infra] Fix react@^18 CI failing on nanoid trust-downgrade (#22923) @LukasTy
- [code-infra] Reduce Netlify build parallelism to 2 (#22925) @LukasTy
- [code-infra] Use Turbopack for docs in dev (#22882) @brijeshb42
- [docs-infra] Pre-render API page descriptions (#22919) @brijeshb42
- [internal] Use `@base-ui/utils/platform` for platform detection (#22710) @romgrk
- [internal] Enforce top-level type imports (#22679) @Janpot

### Miscellaneous

- [internal] Enable mui/no-floating-cleanup and fix leaks (#22872) @romgrk
- [infra] Update `.gitignore` to exclude `.claude` sub-directories (#22435) @michelengelen
- [virtualizer] Improve the dimensions' initial state (#22885) @arminmeh

## 9.6.0

_Jun 18, 2026_

We'd like to extend a big thank you to the 17 contributors who made this release possible. Here are some highlights ✨:

- 📊 New features for the radial bar charts, like percentage min radius and disabling tick labels.

Special thanks go out to these community members for their valuable contributions:
@adamowski10, @Anexus5919, @Morteza-hp, @mustafajw07, @TargiX

The following team members contributed to this release:
@alexfauquette, @arminmeh, @brijeshb42, @cherniavskii, @hasdfa, @Janpot, @JCQuintas, @michelengelen, @noraleonte, @oliviertassinari, @rita-codes, @sai6855

### Data Grid

#### `@mui/x-data-grid@9.6.0`

- [DataGrid] Define `overflowAnchor` style at the right element (#22849) @arminmeh
- [DataGrid] Fix scrollbars not showing up on scroll on iOS (#22832) @cherniavskii

#### `@mui/x-data-grid-pro@9.6.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.6.0`, plus:

- [DataGridPro] Prevent incorrect row range capping on the first page with known `rowCount` (#22808) @michelengelen

#### `@mui/x-data-grid-premium@9.6.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.6.0`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.6.0`

- [pickers] Fix `AdapterMomentHijri.getDaysInMonth` returning the Gregorian month length (#22774) @Anexus5919
- [l10n] Improve Persian (fa-IR) locale (#22454) @Morteza-hp

#### `@mui/x-date-pickers-pro@9.6.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.6.0`.

### Charts

#### `@mui/x-charts@9.6.0`

- [charts] Add `disableTickLabel` prop to radial axes (#22801) @JCQuintas
- [charts] Fix bug when `min` is in axis domain (#22827) @alexfauquette
- [charts] Fix wheel zoom not centering on cursor position (#22811) @JCQuintas
- [charts] Remove zoom gesture registration from community package (#22753) @sai6855
- [charts] Support percentage values for radial axis `minRadius`/`maxRadius` (#22803) @JCQuintas
- [charts] Support `unknownColor` in color scale (#22813) @alexfauquette
- [charts] Document click listener for scatter composition (#22809) @sai6855

#### `@mui/x-charts-pro@9.6.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.6.0`.

#### `@mui/x-charts-premium@9.6.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.6.0`, plus:

- [charts-premium] Add `geoFeatureKey` to transform features identifier (#22848) @alexfauquette
- [charts-premium] Allow to remove Antartica (#22815) @alexfauquette
- [charts-premium] Regenerate `ScatterPlotPremium` `propTypes` (#22829) @rita-codes
- [charts-premium] Support maps tooltip positioned on items (#22648) @alexfauquette
- [docs] Show how to export maps (#22837) @alexfauquette

### Tree View

#### `@mui/x-tree-view@9.6.0`

Internal changes.

#### `@mui/x-tree-view-pro@9.6.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.6.0`.

### Scheduler

#### `@mui/x-scheduler@9.0.0-beta.2`

- [scheduler] Add dispose lifecycle to `SchedulerLazyLoadingPlugin` (#22532) @rita-codes
- [scheduler] Add responsive mobile week view and responsive typography (#22593) @noraleonte
- [scheduler] Add stable weekday token to `recurrenceWeeklyPresetLabel` (#22733) @mustafajw07
- [scheduler] Create accessibility documentation section (#22557) @mustafajw07
- [scheduler] Decouple `MonthViewProps` from day time grid props (#22802) @mustafajw07
- [scheduler] Export missing public scheduler types (#22785) @mustafajw07
- [scheduler] Fix JSDoc defaults and improve public type readability (#22784) @mustafajw07
- [scheduler] Fix `aria-labelledby` on events referencing non-existent header IDs (#22778) @rita-codes
- [scheduler] Move `EventCalendarStyledContext` to internals (#22787) @mustafajw07
- [scheduler] Normalize all-day recurring occurrences to whole days (#22792) @Anexus5919
- [scheduler] Recalculate `DayTimeGrid` `hasScroll` on container resize (#22780) @Anexus5919
- [scheduler] Recompute `nowUpdatedEveryMinute` only on timezone change (#22793) @Anexus5919
- [scheduler] Register auto-scroll once instead of on every render (#22794) @Anexus5919
- [scheduler] Remove duplicate dividers in the day/time grid (#22795) @Anexus5919
- [scheduler] Remove unused `--has-scroll` CSS variable from `DayTimeGrid` (#22799) @Anexus5919
- [scheduler] Remove vestigial async from internal drop handler (#22781) @mustafajw07
- [scheduler] Return a primitive key from the Calendar lazy-loading selector (#22791) @Anexus5919
- [scheduler] Throw on invalid event dates instead of emitting `NaN` timestamps (#22740) @rita-codes
- [scheduler] Tighten `StandaloneEventProps` data typing (#22796) @mustafajw07
- [scheduler] Update feedback banner to say beta instead of alpha (#22804) @rita-codes
- [scheduler] Use `@base-ui` `generateId` for event ids in `createEventModel` (#22788) @rita-codes
- [scheduler] Clear clipboard after pasting a cut event (#22773) @Anexus5919
- [scheduler] Show drag placeholder when re-entering the same position (#22775) @Anexus5919
- [scheduler] Validate missing and duplicate event ids (#22790) @Anexus5919
- [l10n] Improve Polish (pl-PL) locale (#22612) @adamowski10

#### `@mui/x-scheduler-premium@9.0.0-beta.2` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.2`, plus:

- [scheduler-premium] Expose premium model types through public API (#22798) @mustafajw07
- [scheduler-premium] Remove non-functional `onPreferencesChange` prop from `EventTimelinePremium` (#22777) @rita-codes
- [scheduler-premium] Validate the `FREQ` value in `parseRRule`] (#22786) @rita-codes

### Codemod

#### `@mui/x-codemod@9.6.0`

Internal changes.

### Docs

- [docs] Fix link-check build timeout by disabling serve directory listing (#22836) @Janpot
- [docs] Show how to export maps (#22837) @alexfauquette
- [docs] Add radial bar overview demo with custom overlays (#22776) @JCQuintas
- [docs] Add weather composition demo (#22723) @TargiX
- [docs] Add docs overview gallery and playground (#22488) @hasdfa
- [docs] Clarify 'Scrolling without render gaps' (#22629) @oliviertassinari
- [docs] Fix typo in release instructions (#22864) @brijeshb42

### Core

- [code-infra] Fix lint issues (#22757) @brijeshb42
- [code-infra] Fix remaining Dependabot security alerts (#22761) @Janpot
- [code-infra] Remove release:build from docs:build script (#22852) @brijeshb42
- [code-infra] Unpin `@mui/utils` version to allow dedupe (#22828) @mustafajw07
- [docs-infra] Cap Netlify Next.js build parallelism to avoid OOM (#22847) @Janpot
- [docs-infra] Remove i18n codebase (#22591) @brijeshb42
- [internal] Fix failing React 18 unit tests (#22846) @brijeshb42

### Miscellaneous

- [core] Add remove-proptypes markers to generated `propTypes` (#22850) @JCQuintas
- [core] Bump vitest packages to 4.1.8 to fix browser-test version skew (#22845) @Janpot
- [core] Reduce e2e build concurrency to avoid OOM (#22843) @Janpot
- [core] Strip proptypes from Production bundles (#22750) @sai6855
- [test] Wait for `GridToolbarCustom` rows before screenshot (#22844) @Janpot

## 9.5.0

_Jun 11, 2026_

We'd like to extend a big thank you to the 9 contributors who made this release possible. Here are some highlights ✨:

- 🎁 New [`multiSelect` column type for Data Grid Pro](https://mui.com/x/react-data-grid/column-definition/#MultiSelectColumn)
- 🚀 New [renderer="svg-progressive"](https://mui.com/x/react-charts/scatter/#progressive-renderer) paints scatter points in batched frames so large datasets render smoothly without blocking the main thread.
- 🐞 Bugfixes
- 📚 Documentation improvements

Special thanks go out to community members @mustafajw07 and @Anexus5919 for their valuable contribution.

The following team members contributed to this release:
@alexfauquette, @JCQuintas, @rita-codes, @rluzists1, @sai6855, @siriwatknp, @arminmeh, @brijeshb42

### Data Grid

#### `@mui/x-data-grid@9.5.0`

- [DataGrid] Restrict warning messages to non-production environments in various components (#22461) @sai6855
- [DataGrid] Prevent React state update before mount (#22374) @arminmeh

#### `@mui/x-data-grid-pro@9.5.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.5.0`, plus:

- [DataGridPro] Add new `multiSelect` column type (#21157) @siriwatknp

#### `@mui/x-data-grid-premium@9.5.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.5.0`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.5.0`

- [pickers] Fix missing export of `th-TH` (#22703) @alexfauquette

#### `@mui/x-date-pickers-pro@9.5.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.5.0`.

### Charts

#### `@mui/x-charts@9.5.0`

- [charts] Add `FocusedBar` component to `BarScatterComposition` demo (#22704) @sai6855
- [charts] Add dedicated Bubble Chart documentation page (#22688) @mustafajw07
- [charts] Add progressive scatter renderer (#22518) @JCQuintas
- [charts] Avoid full axis pipeline rebuild on resize (#22695) @JCQuintas
- [charts] Document focus indicator in composition page (#22712) @JCQuintas
- [charts] Fix `ChartsTooltip` `container` and `disablePortal` props being ignored (#22690) @JCQuintas
- [charts] Make ordinal scales O(1) to copy and re-range (#22691) @JCQuintas
- [charts] Stabilize WebGL bar rendering at sub-pixel widths (#22678) @JCQuintas
- [charts] Use the series config to define value types (#22693) @sai6855
- [charts] Decouple interaction hook from the cartesian zoom (#22708) @alexfauquette

#### `@mui/x-charts-pro@9.5.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.5.0`, plus:

- [charts-pro] Add missing focus highlight (#22689) @alexfauquette

#### `@mui/x-charts-premium@9.5.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.5.0`, plus:

- [charts-premium] Set `Heatmap` WebGL render as stable (#22665) @alexfauquette
- [charts-premium] Stabilize candlestick charts (#22666) @alexfauquette
- [charts-premium] Stabilize the radial charts (#22655) @alexfauquette

### Scheduler

#### `@mui/x-scheduler@9.0.0-beta.1`

Internal changes.

#### `@mui/x-scheduler-premium@9.0.0-beta.1` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.1`, plus:

- [scheduler] Remove dead CSS variable writes in `EventTimelinePremiumContent` (#22720) @rita-codes
- [scheduler] Show scope dialog when deleting a recurring event (#22552) @Anexus5919

### Core

- [docs-infra] Fix immutable cache headers for `/\_next/static` assets (#22747) @brijeshb42
- [docs-infra] Prefix `/\_next/static` cache header rule with `/x` basePath (#22748) @brijeshb42
- [code-infra] Update dependencies to resolve Dependabot security alerts (#22714) @Janpot

### Docs

- [docs] Fix broken links checker crashing on 404 known-targets fetch (#22707) @sai6855
- [docs] Fix country data (#22716) @alexfauquette

### Miscellaneous

- [legal] Update EULA links in docs (#22717) @rluzists1

## 9.4.0

<!-- generated comparing v9.3.0..master -->

_Jun 4, 2026_

We'd like to extend a big thank you to the 21 contributors who made this release possible. Here are some highlights ✨:

- 🎉 Scheduler is now in Beta shipping with Timeline vitualization and lazy loading
- 📆 Implement Event Timeline virtualization (#22339)
- 🫧 Introduce bubble charts (#22537)
- 🐞 Bugfixes
- 📚 Documentation improvements

Special thanks go out to these community members for their valuable contributions:
@imxv, @mixelburg, @mustafajw07

The following team members contributed to this release:
@aemartos, @alexfauquette, @arminmeh, @bernardobelchior, @cherniavskii, @flaviendelangle, @hasdfa, @Janpot, @JCQuintas, @joserodolfofreitas, @LukasTy, @MBilalShafi, @michelengelen, @mj12albert, @noraleonte, @oliviertassinari, @rita-codes, @romgrk, @sai6855

### Data Grid

#### `@mui/x-data-grid@9.4.0`

- [DataGrid] Fix `avg` aggregation when the average is zero (#22652) @mj12albert
- [DataGrid] Inherit icon `fontSize` from `baseIconButton` size (#22187) @imxv
- [DataGrid] Fix `noRowsOverlay` flicker between `dataSource` re-fetches (#22465) @LukasTy

#### `@mui/x-data-grid-pro@9.4.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.4.0`.

#### `@mui/x-data-grid-premium@9.4.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

> This release includes a version bump of the `@mui/x-internal-exceljs-fork` package to address the vulnerable dependencies.
> The following CVEs are fixed:
>
> - <https://github.com/advisories/GHSA-ph9p-34f9-6g65>
> - <https://github.com/isaacs/minimatch/security/advisories/GHSA-23c5-xmqv-rm74>
> - <https://github.com/advisories/GHSA-w5hq-g745-h8pq>
>
> To make this security update possible, we bumped the `node` version requirement from `>=14.0.0` to `>=14.17.0`.
> [Node.js 14.17.0](https://nodejs.org/en/blog/release/v14.17.0) was released in May 2021, so we consider it safe to bump the requirement without causing issues for our users.

Same changes as in `@mui/x-data-grid-pro@9.4.0`, plus:

- [DataGridPremium] Nested Lazy Loading (#21043) @MBilalShafi
- [DataGridPremium] Update exceljs fork (#22658) @cherniavskii

### Date and Time Pickers

#### `@mui/x-date-pickers@9.4.0`

Internal changes.

#### `@mui/x-date-pickers-pro@9.4.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.4.0`.

### Charts

#### `@mui/x-charts@9.4.0`

- [charts] Add functionality to hide elements during chart export (#22525) @sai6855
- [charts] Add option to show marks only on the first/last values (#22645) @alexfauquette
- [charts] Add text customization section and demo for axis labels (#22597) @sai6855
- [charts] Allow axes to scale according to the visible series only (#22566) @alexfauquette
- [charts] Correctly handle different identifiers for each series (#22556) @sai6855
- [charts] Fix inverted Y axis zoom/pan on ordinal scales (#22654) @JCQuintas
- [charts] Introduce bubble charts (#22537) @alexfauquette
- [charts] Let scatter chart tooltip ignore hidden series (#22614) @alexfauquette
- [charts] Make `'sqrt'` size mapping the default (#22683) @alexfauquette
- [charts] Remove unused proptypes (#22618) @alexfauquette
- [charts] Support module augmentation for slots (#22519) @sai6855
- [charts] Support multiple marker size in `findClosestPoint` (#22622) @alexfauquette
- [charts] Upgrade bezier-easing to v3 and use it for line chart hit-detection (#22608) @sai6855
- [charts] Use `useLayoutEffect` with `ResizeObserver` (#22646) @JCQuintas

#### `@mui/x-charts-pro@9.4.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.4.0`, plus:

- [charts-pro] Auto-select range button matching current zoom (#22137) @JCQuintas
- [charts-pro] Support range values in `initialZoom` (#22563) @JCQuintas

#### `@mui/x-charts-premium@9.4.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.4.0`, plus:

- [charts-premium] Support range-bar series in WebGL bar renderer (#22607) @JCQuintas
- [charts-premium] Fix `onAxisClick` for radial bar and lines (#22522) @alexfauquette

### Tree View

#### `@mui/x-tree-view@9.4.0`

Internal changes.

#### `@mui/x-tree-view-pro@9.4.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.4.0`.

### Scheduler

#### Breaking changes

The theme `styleOverrides` slots for the skeleton and the error container were
renamed and unified. The CSS utility class names (for example
`.MuiEventCalendar-eventSkeleton`) are **not** affected — only
`theme.components.*` overrides need updating.

**Event skeleton**

| Before                                  | After                          |
| --------------------------------------- | ------------------------------ |
| `MuiEventCalendar` slot `EventSkeleton` | `MuiEventSkeleton` slot `Root` |
| `MuiEventTimeline` slot `EventSkeleton` | `MuiEventSkeleton` slot `Root` |

**Error container**

| Before                                                        | After                                   |
| ------------------------------------------------------------- | --------------------------------------- |
| `MuiEventCalendar` / `MuiEventTimeline` slot `ErrorContainer` | `MuiEventErrorContainer` slot `Root`    |
| `MuiEventCalendar` / `MuiEventTimeline` slot `ErrorAlert`     | `MuiEventErrorContainer` slot `Alert`   |
| `MuiEventCalendar` / `MuiEventTimeline` slot `ErrorMessage`   | `MuiEventErrorContainer` slot `Message` |

If you customized these through the theme, update the component name and slot
names accordingly:

```diff
 components: {
-  MuiEventCalendar: {
+  MuiEventSkeleton: {
     styleOverrides: {
-      EventSkeleton: { /* ... */ },
+      Root: { /* ... */ },
     },
    },
  },
 }
```

#### `@mui/x-scheduler@9.0.0-beta.0`

- [scheduler] Add a prop to control whether the resource of an event can be cleared (#22464) @rita-codes
- [scheduler] Add week number labels to agenda, day and week views (#22594) @mustafajw07
- [scheduler] Add `weekStartsOn` preference and update date functions to support custom week start (#22426) @mustafajw07
- [scheduler] Export premium version of the standalone views (#22621) @flaviendelangle
- [scheduler] Implement timeline virtualization (#22339) @romgrk
- [scheduler] Split scheduler overview (#22453) @joserodolfofreitas
- [scheduler] Unify `EventSkeleton` and `ErrorContainer` between `EventCalendar` and `EventTimeline` (#22676) @noraleonte

#### `@mui/x-scheduler-premium@9.0.0-beta.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-beta.0`.

### Docs

- [docs] Add a performance docs page for charts (#22656) @alexfauquette
- [docs] Add real dataset for maps documentation (#22599) @alexfauquette
- [docs] Add spacing between selects on charts overview demo (#22589) @bernardobelchior
- [docs] Reorganize existing chat docs navigation (#22478) @hasdfa
- [docs] Switch to visionscarto's world atlas dataset (#22669) @cherniavskii
- [docs] Update TreeView `domstructure` docs and add demo (#22420) @mj12albert
- [docs] Fix indexation of Scheduler (#22567) @oliviertassinari
- [docs] Fix wide layout on event timeline lazy loading and Import title (#22604) @rita-codes
- [docs] Derive class name owners for shared charts classes (#22674) @JCQuintas

### Core

- [code-infra] Drop unused and now-transitive deps from docs/package.json (#22549) @LukasTy
- [code-infra] Refresh CI Node pins to 22.22.3 (#22598) @LukasTy
- [code-infra] Skip empty product sections in changelog (#22541) @rita-codes
- [code-infra] Stabilize DataGridScrollRestoration visual regression test (#22553) @Janpot
- [internal] Add license to the `x-data-grid-generator` (#22240) @arminmeh
- [internal] Express default value for resource_class (#22569) @oliviertassinari
- [internal] Fix use of ellipsis (#21852) @oliviertassinari
- [internal] `useLayoutEffect` with `ResizeObserver` (#22428) @romgrk

### Miscellaneous

- [chat-headless] Add built-in chat adapters (#22479) @hasdfa
- [chat-headless] Harden runtime model and message errors (#22480) @hasdfa
- [core] Prepare for TypeScript 6 bump (#22551) @LukasTy
- [core] Use CircleCI Gen2 resource classes (#22610) @LukasTy
- [infra] Fix broken tag retrieval on `master` during release (#22174) @michelengelen
- [infra] Group Base UI renovate updates (#22590) @LukasTy
- [pnpm] Add security settings to pnpm-workspace.yaml (#22611) @Janpot
- [release] Fix release PR scripts (#22680) @JCQuintas
- [test] Add a Tree View regression test for lazy loading with getChildrenCount returning -1 (#22605) @mixelburg
- [test] Disable LCD subpixel antialiasing in regression screenshots (#22602) @Janpot
- [test] Fix flaky Data Grid Pro data source tree data tests (#22659) @LukasTy
- [test] Remove stale form-submit TODO from e2e suite (#22564) @LukasTy
- [x-license] Exclude test keys from the published npm package (#22647) @aemartos
- [test] Fix flaky WebGL benchmark by polling for canvas content (#22535) @JCQuintas

## 9.3.0

_May 21, 2026_

We'd like to extend a big thank you to the 16 contributors who made this release possible. Here are some highlights ✨:

- 📆 Refactor Calendar Range drag editing to use Pointer Events instead of drag and touch events combination (#22279)
- ✨ Apply lazy loading to `EventTimelinePremium` (#22308)
- 🐞 Bugfixes
- 📚 Documentation improvements
- 🌎 Added Norwegian bokmål (nb-NO) locale to the Scheduler
- 🌎 Improved Swedish (sv-SE) locale on the Data Grid

Special thanks go out to these community members for their valuable contributions:
@Anexus5919, @jvskriubakken, @oscar-b, @rin, @viktormelin

The following team members contributed to this release:
@aemartos, @alexfauquette, @arminmeh, @Janpot, @JCQuintas, @LukasTy, @mj12albert, @oliviertassinari, @rita-codes, @romgrk, @sai6855

### Data Grid

#### `@mui/x-data-grid@9.3.0`

- [DataGrid] Fix scrollbar disappearing after multiple resizes (#22512) @LukasTy
- [DataGrid] Revert "Add support for pinned columns in `GridVirtualScroller`" (#22467) @oliviertassinari
- [l10n] Improve Swedish (svSE) locale (#21851) @viktormelin

#### `@mui/x-data-grid-pro@9.3.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.3.0`.

#### `@mui/x-data-grid-premium@9.3.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.3.0`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.3.0`

- [pickers] Fix disabled state styling for `PickersTextField` standard and filled variants (#22189) @LukasTy
- [pickers] Fix previous month disabled state calculation (#22524) @mj12albert
- [pickers] Merge `slotProps.sectionContent` in `PickersInputBase` (#22324) @rin

#### `@mui/x-date-pickers-pro@9.3.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.3.0`, plus:

- [DateRangeCalendar] Use Pointer Events for drag editing (#22279) @LukasTy

### Charts

#### `@mui/x-charts@9.3.0`

- [charts] Add `data-series` to elements of radar chart (#22523) @alexfauquette
- [charts] Add environment check for warning messages in axis and radar hooks (#22506) @sai6855
- [charts] Chart `seriesConfig` deduplication for lines and bars (#22257) @sai6855
- [charts] Fix highlighted item crash (#22539) @oscar-b
- [charts] Fix the line and mark class (#22526) @alexfauquette
- [charts] Fix use of deprecated API in docs (#22469) @oliviertassinari
- [charts] Improve performance of `evaluateCurveY` function (#22407) @sai6855

#### `@mui/x-charts-pro@9.3.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.3.0`.

#### `@mui/x-charts-premium@9.3.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.3.0`, plus:

- [charts-premium] Add `closePath` option to the radial line series (#22517) @alexfauquette

### Tree View

#### `@mui/x-tree-view-pro@9.3.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Internal changes.

### Scheduler

#### `@mui/x-scheduler@9.0.0-alpha.7`

- [I10n] Add Norwegian bokmål (nb-NO) locale (#22415) @jvskriubakken

#### `@mui/x-scheduler-premium@9.0.0-alpha.7` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-alpha.7`, plus:

- [scheduler] Apply lazy loading to `EventTimelinePremium` (#22308) @rita-codes
- [scheduler] Deduplicate staged ranges within the debounce window (#22476) @Anexus5919
- [scheduler] Pass full event objects to `dataSource.updateEvents` (#22462) @rita-codes

### Docs

- [docs] Automatically update supported versions (#21850) @arminmeh
- [docs] Fix `New` label on bar charts docs (#22473) @oliviertassinari
- [docs] Improve premium page header for charts (#22474) @oliviertassinari
- [docs] Sync `README` with licensing/licensing.md in scheduler (#22468) @oliviertassinari

### Core

- [code-infra] Cover docs overview composites with Argos (#22283) @LukasTy
- [code-infra] Enable `mui/no-presentation-role` lint rule (#22360) @Janpot
- [code-infra] Make generated `propTypes` union order deterministic (#22521) @JCQuintas
- [code-infra] Make screenshots stable across different ordering of the tests (#22449) @Janpot
- [code-infra] Optimize visual regression testing (#22447) @Janpot
- [code-infra] Replace markdownlint with remark from code-infra (#22255) @Janpot

### Miscellaneous

- [virtualizer] Improve `controlled` mode performance (#22123) @romgrk
- [data-grid-generator] Include `tree-data` params in `useDemoData` cache key (#22456) @Janpot
- [test] Fix flaky browser tests and optimize (#22431) @Janpot
- [test] Speed up `test_types` job (#22442) @Janpot
- [test] Trim ffmpeg install in `test_regressions` (#22459) @Janpot
- [test] Add WebGL performance benchmarks for charts (#22471) @JCQuintas
- [test] Expand chart performance benchmarks for charts (#22472) @JCQuintas
- [x-license] use workspace dep for v9 in cross-major compat tests (#22504) @aemartos

## 9.2.0

_May 13, 2026_

We'd like to extend a big thank you to the 9 contributors who made this release possible. Here are some highlights ✨:

- ⚡️ Add a WebGL renderer to the [Bar chart](https://mui.com/x/react-charts/bars/#webgl-renderer)
- 📊 Add a radial charts with the [radial line](https://mui.com/x/react-charts/radial-lines/), [radial bar](https://mui.com/x/react-charts/radial-bars/), and the [radial grid and axes](https://mui.com/x/react-charts/radial-axes/)
- 🐞 Bugfixes
- 📚 Documentation improvements

Special thanks go out to these community members for their valuable contributions:
@Anexus5919, @mustafajw07

The following team members contributed to this release:
@aemartos, @alexfauquette, @bernardobelchior, @JCQuintas, @oliviertassinari, @sai6855, @siriwatknp

### Data Grid

#### `@mui/x-data-grid@9.2.0`

- [data grid] Add support for pinned columns in `GridVirtualScroller` (#22347) @sai6855
- [data grid] Remove unused CSS (#22390) @oliviertassinari

#### `@mui/x-data-grid-pro@9.2.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.2.0`.

#### `@mui/x-data-grid-premium@9.2.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.2.0`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.2.0`

- [pickers] Trim test helpers' default load graph (#22421) @JCQuintas

#### `@mui/x-date-pickers-pro@9.2.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.2.0`.

### Charts

#### `@mui/x-charts@9.2.0`

Internal changes.

#### `@mui/x-charts-pro@9.2.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.2.0`.

#### `@mui/x-charts-premium@9.2.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.2.0`, plus:

- [charts-premium] Add `Highlight` support to `RadialBarChart` (#22322) @alexfauquette
- [charts-premium] Add `WebGL` renderer to `BarChartPremium` (#22354) @JCQuintas
- [charts-premium] Add mark shape support to the radial line (#22242) @alexfauquette
- [charts-premium] `RadialBarChart` support axis interaction with layout horizontal (#22319) @alexfauquette

### Tree View

#### `@mui/x-tree-view@9.1.0`

Internal changes.

#### `@mui/x-tree-view-pro@9.1.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.1.0`.

### Scheduler

#### `@mui/x-scheduler@9.0.0-alpha.6`

- [scheduler] Complete ARIA grid semantics on `EventTimeline` and `EventCalendar` (#22266) @Anexus5919
- [scheduler] Improve UX for recurrence tab (#22287) @mustafajw07

#### `@mui/x-scheduler-premium@9.0.0-alpha.6` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-alpha.6`.

### Codemod

#### `@mui/x-codemod@9.1.0`

Internal changes.

### Docs

- [docs] Document the `RadialBarChart` (#22320) @alexfauquette
- [docs] Add histogram demo to bar-demo page (#22373) @siriwatknp
- [docs] Add radial bar to the nav bar (#22429) @alexfauquette
- [docs] Split radial grid and radial line pages (#22238) @alexfauquette

### Miscellaneous

- [test] Disable animations in chart benchmarks (#22433) @bernardobelchior
- [test] Move `x-internal-gestures` vitest isolate flag to test block (#22427) @JCQuintas
- [test] Reduce flakiness in `MobileTimeRangePicker` multi-input `describeValue` tests (#22422) @JCQuintas
- [x-license] Exclude compat test pins from Renovate major bumps (#22414) @aemartos
- [x-license] Add cross-major license format compatibility tests (#22335) @aemartos

## 9.1.0

_May 8, 2026_

We'd like to extend a big thank you to the 14 contributors who made this release possible. Here are some highlights ✨:

- ⚡️ Add a WebGL renderer to the [Scatter chart](https://mui.com/x/react-charts/scatter/#webgl-renderer), and apply the same WebGL performance patterns to the candlestick and heatmap [Premium]
- 🐞 Bugfixes
- 📚 Documentation improvements

Special thanks go out to these community members for their valuable contributions:
@Anexus5919, @gaetanodanelli, @imazizbohra, @mustafajw07

The following team members contributed to this release:
@alexfauquette, @brijeshb42, @flaviendelangle, @JCQuintas, @LukasTy, @mapache-salvaje, @MBilalShafi, @michelengelen, @oliviertassinari, @rita-codes

### Data Grid

#### `@mui/x-data-grid@9.1.0`

- [DataGrid] Fix accessibility violation in detail panel toggle column header (#22178) @michelengelen
- [DataGrid] Fix active filter detection for array values (#22340) @MBilalShafi
- [DataGrid] Fix crash when grouping/tree-data values match `Object.prototype` property names (#22312) @LukasTy
- [DataGrid] Position overlays below top pinned rows (#22341) @MBilalShafi
- [l10n] Improve Italian (it-IT) locale (#22290) @gaetanodanelli

#### `@mui/x-data-grid-pro@9.1.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.1.0`, plus:

- [DataGridPro] Fix column unpin restoring stale position after reorder (#22250) @michelengelen

#### `@mui/x-data-grid-premium@9.1.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.1.0`, plus:

- [DataGridPremium] Fix aggregation column header title truncation without ellipsis (#22248) @michelengelen

### Date and Time Pickers

#### `@mui/x-date-pickers@9.1.0`

- [pickers] Fix duplicate hour label in `MultiSectionDigitalClock` on DST day (#22110) @LukasTy
- [l10n] Improve Italian (it-IT) locale (#22290) @gaetanodanelli

#### `@mui/x-date-pickers-pro@9.1.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.1.0`.

### Charts

#### `@mui/x-charts@9.1.0`

- [charts] Add `ChartsAxisHighlightValue` component (#21803) @Copilot
- [charts] Create `ChartsRadialAxisHighlight` (#22241) @alexfauquette
- [charts] Remove useless extends (#22313) @alexfauquette
- [charts] Use `PolarAxisConfig` in polar plugin internals (#22315) @alexfauquette

#### `@mui/x-charts-pro@9.1.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.1.0`.

#### `@mui/x-charts-premium@9.1.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.1.0`, plus:

- [charts-premium] Add WebGL renderer to `ScatterChartPremium` (#22157) @JCQuintas
- [charts-premium] Add highlight to the `RadialLineChart` (#22156) @alexfauquette
- [charts-premium] Apply WebGL perf patterns to candlestick + heatmap (#22223) @JCQuintas
- [charts-premium] Introduce the `RadialBarChart` (#22268) @alexfauquette

### Tree View

#### `@mui/x-tree-view@9.1.0`

- [tree view] Fix stale Tree View `apiRef` after keyed remount (#22342) @MBilalShafi

#### `@mui/x-tree-view-pro@9.1.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.1.0`.

### Scheduler

#### `@mui/x-scheduler@9.0.0-alpha.5`

- [scheduler] Make `EventItem` interactive by integrating button props for keyboard accessibility (#22160) @mustafajw07
- [scheduler] Migrate color switch to Base UI `ToggleGroup` (#22254) @flaviendelangle
- [scheduler] Rename Scheduler headless packages (#22273) @rita-codes
- [scheduler] Use TreeView for the resource sidebar (#22261) @flaviendelangle
- [scheduler] Use fieldset/legend instead of headings for form sections in the event dialog (#22095) @Anexus5919
- [scheduler] Added `position: relative` for consistent layout (#22284) @mustafajw07
- [l10n] Improve Italian (it-IT) locale (#22290) @gaetanodanelli

#### `@mui/x-scheduler-premium@9.0.0-alpha.5` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-alpha.5`, plus:

- [scheduler] Replace per-view headers with a generic `EventTimelinePremiumHeader` in the `EventTimeline` (#22222) @rita-codes

### Codemod

#### `@mui/x-codemod@9.1.0`

Internal changes.

### Docs

- [docs] Migrate `FlightPicker` overview demo to v9 `slotProps` shape (#22272) @LukasTy
- [docs] Standardize Scheduler docs style and formatting (#22161) @mapache-salvaje
- [docs] Add feedback form to the scheduler docs (#22237) @rita-codes
- [docs] Fix `GridToolbarCustom` demo crash in DataGrid (#21950) @MBilalShafi
- [docs] Do not resolve axes in charts (#22307) @alexfauquette
- [docs] Fix no longer valid link (#22371) @LukasTy
- [docs] Replace broken CodeSandbox iframes in migration guides (#22352) @LukasTy

### Core

- [code-infra] Bump browser `testTimeout` to absorb React 19 slowness (#22236) @LukasTy
- [code-infra] Use vale rules from code-infra package (#22256) @brijeshb42
- [code-infra] Fix broken valelint and docs build (#22362) @LukasTy
- [internal] Prepare renaming LICENSE file to LICENSE.md (#22055) @imazizbohra
- [internal] Remove outdated .woff files (#22286) @oliviertassinari
- [internal] Replace Codspeed with `@mui/internal-benchmark` for charts (#22243) @JCQuintas

### Miscellaneous

- [internal-gestures] Add passive option to `TurnWheelGesture` (#22349) @JCQuintas
- [internal-gestures] Enforce pointer-type filter in `ShadowRoot` branch (#22327) @JCQuintas
- [internal-gestures] Improve passive event listener handling (#22329) @JCQuintas
- [internal-gestures] Inline wheel-delta clamp per axis (#22331) @JCQuintas
- [internal-gestures] Return read-only pointer map without copy (#22330) @JCQuintas
- [internal-gestures] Track multi-tap reset timeout to prevent leak (#22326) @JCQuintas

## 9.0.4

_Apr 28, 2026_

We'd like to extend a big thank you to the 4 contributors who made this release possible. Here are some highlights ✨:

- Fix Pickers previous (v9.0.3) release ensuring the latest `@mui/x-internals` version usage

The following team members contributed to this release:
@alexfauquette, @JCQuintas, @LukasTy, @mj12albert

### Data Grid

#### `@mui/x-data-grid@9.0.4`

Internal changes.

#### `@mui/x-data-grid-pro@9.0.4` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.0.4`.

#### `@mui/x-data-grid-premium@9.0.4` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.0.4`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.0.4`

Internal changes.

#### `@mui/x-date-pickers-pro@9.0.4` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.0.4`.

### Charts

#### `@mui/x-charts@9.0.4`

- [charts] Exclude hidden series and items from keyboard navigation (alt approach) (#22221) @JCQuintas
- [charts] Fix line interaction with `area` and `conectNulls` (#22227) @alexfauquette
- [charts] Implement the continuous case of `getAxisIndex` for rotation axis (#22230) @alexfauquette

#### `@mui/x-charts-pro@9.0.4` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.0.4`.

#### `@mui/x-charts-premium@9.0.4` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.0.4` plus:

- [charts-premium] Add `showMark` and `shape` properties to radial line (#22226) @alexfauquette

### Tree View

#### `@mui/x-tree-view@9.0.4`

Internal changes.

#### `@mui/x-tree-view-pro@9.0.4` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.0.4`.

### Scheduler

#### `@mui/x-scheduler@9.0.4`

Internal changes.

#### `@mui/x-scheduler-premium@9.0.4` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.4`.

### Codemod

#### `@mui/x-codemod@9.0.4`

Internal changes.

### Docs

- [docs] Update WCAG links (#22234) @mj12albert

### Core

- [code-infra] Avoid overriding `renovate` `ignoredPaths` (#22228) @LukasTy

## 9.0.3

_Apr 27, 2026_

We'd like to extend a big thank you to the 16 contributors who made this release possible. Here are some highlights ✨:

- ⌨️ Keyboard support for creating events in the Scheduler

Special thanks go out to these community members for their valuable contributions:
@supunsathsara, @ZAKIURREHMAN

The following team members contributed to this release:
@aemartos, @alexfauquette, @arminmeh, @brijeshb42, @Janpot, @JCQuintas, @LukasTy, @MBilalShafi, @michelengelen, @oliviertassinari, @rita-codes, @romgrk, @sai6855, @siriwatknp

### Data Grid

#### `@mui/x-data-grid@9.0.3`

- [DataGrid] Fix `:first-child` SSR warning when `MuiDataGrid.styleOverrides` is set (#22081) @siriwatknp
- [DataGrid] Fix row reordering when filter hides rows (#22096) @siriwatknp
- [DataGrid] Remove unused `LayoutDataGridLegacy` class (#22009) @romgrk
- [DataGrid] Remove unused code, clean up grid-related utilities and deprecate `GridPanelHeader` (#22112) @sai6855
- [DataGrid] Fix columns cutting off after resizing (#22088) @ZAKIURREHMAN

#### `@mui/x-data-grid-pro@9.0.3` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.0.3`.

#### `@mui/x-data-grid-premium@9.0.3` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.0.3`, plus:

- [DataGridPremium] Fix row grouping model updates not being reflected (#22122) @MBilalShafi

### Date and Time Pickers

#### `@mui/x-date-pickers@9.0.3`

- [pickers] Fix `DateRangeCalendar` drag with `AdapterDayjs` plain-constructor values (#22165) @LukasTy
- [pickers] Fix disabled state not overriding error border color (#21169) @supunsathsara
- [pickers] Forward `data-*` and `aria-*` attributes to the root (#22147) @LukasTy
- [pickers] Support `K` and `k` hour format tokens (#22108) @michelengelen

#### `@mui/x-date-pickers-pro@9.0.3` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.0.3`, plus:

- [DateRangeCalendar] Ensure date dragging triggers regardless of trigger element (#21868) @michelengelen

### Charts

#### `@mui/x-charts@9.0.3`

- [charts] Centralize WebGL clear/render cycle (context-based) (#22127) @JCQuintas
- [charts] Fix closest series detection for line charts (#22168) @alexfauquette
- [charts] Fix radius grid lines when axis uses point scale (#22134) @alexfauquette
- [charts] Use cubic solver for berzier intersection (#22152) @alexfauquette

#### `@mui/x-charts-pro@9.0.3` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.0.3`, plus:

- [charts-pro] Fix wheel zoom clamping with custom `minStart`/`maxEnd` (#22159) @JCQuintas

#### `@mui/x-charts-premium@9.0.3` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.0.3`, plus:

- [charts] Create a `'radialLine'` series type (#22066) @alexfauquette
- [charts] Plot radial line (#22133) @alexfauquette
- [charts] Remove `HeatmapWebGLRenderer` indirection (#22169) @JCQuintas

### Tree View

#### `@mui/x-tree-view@9.0.2`

Internal changes.

#### `@mui/x-tree-view-pro@9.0.2` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.0.2`.

### Scheduler

#### Breaking changes

- The `views` of `EventTimelinePremium` have been renamed to `presets`, with names that describe the header layout. The props `view`/`defaultView`/`views`/`onViewChange` are now `preset`/`defaultPreset`/`presets`/`onPresetChange`, and the type `EventTimelinePremiumView` is now `EventTimelinePremiumPreset`.

| Old      | New            |
| :------- | :------------- |
| `time`   | `dayAndHour`   |
| `days`   | `day`          |
| `weeks`  | `dayAndWeek`   |
| `months` | `monthAndYear` |
| `years`  | `year`         |

CSS variables (`--time-cell-width`, etc.) and headless store state (`state.view`, `setView`) follow the same rename. The `presets` array is now sorted internally against a canonical zoom order.

#### `@mui/x-scheduler@9.0.0-alpha.3`

- [scheduler] Allow creating events via keyboard - EventCalendar (#21967) @rita-codes
- [scheduler] Prefix element IDs with a unique Scheduler instance ID (#22109) @rita-codes

#### `@mui/x-scheduler-premium@9.0.0-alpha.3` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-alpha.3`.

- [scheduler] Allow creating events via keyboard - `EventTimeline` (#22119) @rita-codes
- [scheduler] Rename `EventTimeline` `views` to ordered presets (#22130) @rita-codes

### Docs

- [docs] Cleanup generated llm md files for chat (#22163) @brijeshb42
- [docs] Fix `highlightScope` description (#22154) @alexfauquette
- [docs] Remove obsolete v7 deprecation warning for `dayOfWeekFormatter` (#22111) @LukasTy
- [docs] Use mui.com for broken links checker known targets (#22129) @JCQuintas
- [docs] Document picker behavior inside MUI `Dialog` and provide recommended solutions (#22144) @michelengelen
- [docs] Improve v9 license key version mismatch error guidance (#22180) @aemartos

### Core

- [code-infra] Reduce concurrency for package build to 5 (#22115) @Janpot
- [code-infra] Rename `docsx` alias to `docs` (#22155) @brijeshb42
- [docs-infra] Remove monorepo dependency (#22025) @brijeshb42
- [docs-infra] Use latest published packages (#22086) @brijeshb42
- [test] Refactor Pickers tests to async user-event (#22043) @LukasTy
- [test] Remove redundant explicit `unmount()` calls from Pickers tests (#22118) @LukasTy

### Miscellaneous

- [infra] Update `.gitignore` to exclude `.claude/worktrees` (#22145) @michelengelen
- [infra] Enable branch tracking when creating release branch (#22177) @michelengelen
- [license] Add MIT license to `x-virtualizer` package (#22164) @michelengelen
- [website] Fix outdated MUI logos (#22117) @oliviertassinari
- [internal] Try avoiding store update when virtualization is disabled (#22093) @arminmeh

## 9.0.2

<!-- generated comparing v9.0.1..master -->

_Apr 15, 2026_

We'd like to extend a big thank you to the 12 contributors who made this release possible. Here are some highlights ✨:

- 📊 Added `valueGetter` to axes and series configurations, which allow for dynamically getting data out of a `dataset`.
- 🐞 Bugfixes
- 📚 Docs updates

Special thanks go out to these community members for their valuable contributions:
@Anexus5919, @nk10nikhil

The following team members contributed to this release:
@aemartos, @alexfauquette, @brijeshb42, @Janpot, @JCQuintas, @LukasTy, @MBilalShafi, @michelengelen, @rita-codes, @sai6855

### Data Grid

#### `@mui/x-data-grid@9.0.2`

- [DataGrid] Fix skeleton overlay backdrop issue (#21951) @MBilalShafi
- [DataGrid] Make `overridesResolver` of `ResizablePanelHandle` dynamic (#21724) @sai6855

#### `@mui/x-data-grid-pro@9.0.2` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.0.2`.

#### `@mui/x-data-grid-premium@9.0.2` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.0.2`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.0.2`

- [fields] Allow `openPickerButtonPosition` on single-input range fields (#22011) @LukasTy
- [pickers] Fix spurious `onBlur`/`onFocus` firing during field focus transitions (#22098) @LukasTy
- [pickers] Use `convertToMeridiem` utility in `transferDateSectionValue` (#22062) @michelengelen

#### `@mui/x-date-pickers-pro@9.0.2` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.0.2`.

### Charts

#### `@mui/x-charts@9.0.2`

- [charts] Add `valueGetter` to axes and series (#21963) @JCQuintas
- [charts] Create a `ChartsRadialDataProvider` (#22047) @alexfauquette
- [charts] Create a `ChartsRadialGrid` (#22085) @alexfauquette
- [charts] Deprecate `Scatter` component (#22060) @JCQuintas
- [charts] Remove duplicate `useThemeProps` call (#22045) @alexfauquette
- [charts] Simplify focus state handling in `BarElement` component (#22101) @sai6855

#### `@mui/x-charts-pro@9.0.2` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.0.2`, plus:

- [charts-pro] Add range buttons to toolbar (#21964) @JCQuintas

#### `@mui/x-charts-premium@9.0.2` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.0.2`.

### Tree View

#### `@mui/x-tree-view@9.0.2`

Internal changes.

#### `@mui/x-tree-view-pro@9.0.2` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.0.2`, plus:

- [tree view] Move `lazyLoadedItems` initialization to state initializer (#22073) @michelengelen

### Scheduler

#### `@mui/x-scheduler@9.0.0-alpha.2`

- [scheduler] Add recurrence icon to recurring events in `EventTimeline` (#22019) (#22046) @nk10nikhil
- [scheduler] Reset scroll position when navigating to a new time period (#22036) @Anexus5919
- [l10n] Improve German (de-DE) locale (#21944) @rita-codes
- [l10n] Improve Portuguese - Portugal (pt-PT) locale & Improve Portuguese - Brazil (pt-BR) locale (#21943) @rita-codes

#### `@mui/x-scheduler-premium@9.0.0-alpha.2` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-alpha.2`.

### Chat

#### `@mui/x-chat@9.0.0-alpha.1`

- Internal changes.

#### `@mui/x-chat-headless@9.0.0-alpha.1`

- Internal changes.

### Docs

- [docs] Add data grid `isAnyOf` paste recipe (#21961) @MBilalShafi
- [docs] Add `@mui/material` upgrade requirement to v9 migration guides (#22068) @LukasTy
- [docs] Fix pages width with `disableToc` (#22051) @LukasTy
- [docs] Split charts axis page (#22069) @alexfauquette
- [docs] Update `ChartsRadialDataProvider` API page imports (#22072) @JCQuintas

### Core

- [code-infra] Fix lock file (#22053) @JCQuintas
- [code-infra] Limit `release:build` lerna concurrency to 6 (#22077) @Janpot
- [docs-infra] Update monorepo dependency with relevant migration (#22041) @brijeshb42

### Miscellaneous

- [telemetry] Skip runtime resolution when telemetry is disabled (#22078) @aemartos
- [test] Remove v7 suffix from test helpers and stale comments (#22023) @LukasTy
- [scheduler] Fix README for published packages (#22042) @rita-codes

## 9.0.1

<!-- generated comparing v9.0.0..master -->

_Apr 8, 2026_

We'd like to extend a big thank you to the 8 contributors who made this release possible. Here are some highlights ✨:

- Docs updates 📚
- Chat release 🥳

Special thanks go out to community member @mixelburg for their valuable contribution.

The following team members contributed to this release:
@alexfauquette, @cherniavskii, @hasdfa, @Janpot, @LukasTy, @MBilalShafi, @rita-codes

### Data Grid

#### `@mui/x-data-grid@9.0.1`

- [DataGrid] Fix `processRowUpdate` invoked when cancelling edit for non-existent rows (#21990) @mixelburg
- [DataGrid] Remove flaky argos tests (#22034) @MBilalShafi

#### `@mui/x-data-grid-pro@9.0.1` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.0.1`.

#### `@mui/x-data-grid-premium@9.0.1` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.0.1`.

### Charts

#### `@mui/x-charts@9.0.1`

- [charts] Small code cleanup (#22031) @alexfauquette

#### `@mui/x-charts-pro@9.0.1` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.0.1`.

#### `@mui/x-charts-premium@9.0.1` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.0.1`.

### Tree View

#### `@mui/x-tree-view@9.0.1`

Internal changes.

#### `@mui/x-tree-view-pro@9.0.1` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.0.1`.

### Scheduler

#### `@mui/x-scheduler@9.0.0-alpha.1`

Internal changes.

#### `@mui/x-scheduler-premium@9.0.0-alpha.1` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-alpha.1`.

### Chat

#### `@mui/x-chat@9.0.0-alpha.0`

- [chat] Add x-chat package family (#21666) @hasdfa

#### `@mui/x-chat-headless@9.0.0-alpha.0`

- [chat] Add x-chat package family (#21666) @hasdfa

### Docs

- [docs] Add charts a11y page in the menu (#22028) @alexfauquette
- [docs] Signal BC severity in v8 to v9 pickers migration guide (#22026) @LukasTy
- [docs] Use the same heading level data grid packages (#22024) @cherniavskii

### Core

- [code-infra] Fix changelog generator for Premium-without-Pro products (#22029) @LukasTy
- [code-infra] Remove `@mui/x-charts-vendor` check in ci (#22030) @alexfauquette
- [code-infra] Remove push to remote fallback in release script (#22021) @Janpot

### Miscellaneous

- [code] Fix few typos in JSDocs and error messages (#22032) @alexfauquette
- [core] Post stable release changes (#22033) @LukasTy
- [core-infra] Update monorepo hash and remove temporary patch (#22038) @rita-codes

## 9.0.0

<!-- generated comparing v9.0.0-rc.0..master -->

_Apr 8, 2026_

🥳 We're excited to announce the stable release of MUI X v9!
This major release includes many new features and improvements. Here are some highlights ✨:

- Data Grid – [Charts integration](https://mui.com/x/react-data-grid/charts-integration/) [Premium]
- Data Grid – [AI Assistant](https://mui.com/x/react-data-grid/ai-assistant/) [Premium]
- Data Grid – [Undo and redo](https://mui.com/x/react-data-grid/undo-redo/) [Premium]
- Data Grid – [Drag fill](https://mui.com/x/react-data-grid/clipboard/#drag-to-fill) [Premium]
- Data Grid – [longText column type](https://mui.com/x/react-data-grid/column-definition/#column-types)
- Charts – [Interaction and accessibility](https://mui.com/x/react-charts/accessibility/)
- Charts – [Candlestick](https://mui.com/x/react-charts/candlestick/) [Premium]
- Charts – [Range bar charts](https://mui.com/x/react-charts/range-bar/) [Premium]
- Charts – [WebGL Heatmap renderer](https://mui.com/x/react-charts/heatmap/#webgl-renderer) [Premium]
- Tree View – [Virtualization](https://mui.com/x/react-tree-view/rich-tree-view/virtualization/) [Pro]
- New [Scheduler](https://mui.com/x/react-scheduler/) packages [Alpha]

We'd like to extend a big thank you to the 5 contributors who made this release possible.
The following team members contributed to this release:
@DanailH, @LukasTy, @MBilalShafi, @oliviertassinari, @siriwatknp

### Data Grid

#### `@mui/x-data-grid@9.0.0`

Internal changes.

#### `@mui/x-data-grid-pro@9.0.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.0.0`, plus:

- [DataGridPro] Preserve parent selection for non-selectable children (#21132) @MBilalShafi

#### `@mui/x-data-grid-premium@9.0.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.0.0`, plus:

- [DataGridPremium] Drag fill (#21717) @MBilalShafi

### Date and Time Pickers

#### Breaking changes

- Removed the legacy Pickers and Field TextField props (for example: `InputProps`) in favor of the nested `slotProps`. [Read more](https://mui.com/x/migration/migration-pickers-v8/#drop-deprecated-pickerstextfield-props)
- The `utils` field in `PickersAdapterContextValue` has been removed in favor of the `adapter` field.
  This should no longer affect you, as the context export has also been removed.
- `MuiPickersAdapterContext` export has been removed.
  Prefer using the `usePickerAdapter` hook. [Read more](https://mui.com/x/migration/migration-pickers-v8/#localizationprovider-breaking-changes).

#### `@mui/x-date-pickers@9.0.0`

- [pickers] Refactor `PickersTextField` to use `slotProps` approach (#22002) @LukasTy
- [pickers] Remove deprecated LocalizationProvider legacy API (#22010) @LukasTy

#### `@mui/x-date-pickers-pro@9.0.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.0.0`.

### Charts

#### `@mui/x-charts@9.0.0`

Internal changes.

#### `@mui/x-charts-pro@9.0.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.0.0`.

#### `@mui/x-charts-premium@9.0.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.0.0`.

### Tree View

#### `@mui/x-tree-view@9.0.0`

Internal changes.

#### `@mui/x-tree-view-pro@9.0.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.0.0`.

### Scheduler

#### `@mui/x-scheduler@9.0.0-alpha.0`

Internal changes.

#### `@mui/x-scheduler-premium@9.0.0-alpha.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-alpha.0`.

### Codemod

#### `@mui/x-codemod@9.0.0`

Internal changes.

### Docs

- [docs] Add explanation for v8 -> v9 license migration (#22004) @DanailH

### Core

- [code-infra] Optimize dependency definition (#22006) @LukasTy
- [internal] Prepare v9 stable (#22018) @siriwatknp
- [internal] Remove 'conf' from codebase (#21989) @oliviertassinari

## 9.0.0-rc.0

<!-- generated comparing v9.0.0-beta.0..master -->

_Apr 7, 2026_

We'd like to extend a big thank you to the 18 contributors who made this release possible.

Special thanks go out to these community members for their valuable contributions:
@mixelburg, @sibananda485, @youjin-hong

The following team members contributed to this release:
@aemartos, @alexfauquette, @arminmeh, @brijeshb42, @flaviendelangle, @JCQuintas, @LukasTy, @mapache-salvaje, @MBilalShafi, @michelengelen, @noraleonte, @rita-codes, @romgrk, @siriwatknp, @ZeeshanTamboli

### Data Grid

#### `@mui/x-data-grid@9.0.0-rc.0`

- [DataGrid] Rename filter panel `Columns` label to singular `Column` (#21935) @youjin-hong
- [DataGrid] Export `GridColumnUnsortedIconProps` for custom column icon slots (#21658) @mixelburg
- [DataGrid] Remove `x-virtualizer`'s `virtualScroller` from public API (#21936) @romgrk
- [DataGrid][virtualizer] Scrolling without render gaps (#21616) @romgrk

#### `@mui/x-data-grid-pro@9.0.0-rc.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.0.0-rc.0`, plus:

- [DataGridPro] Improve trigger for nested row reordering (#21642) @MBilalShafi
- [DataGridPro] Undeprecate `onRowsScrollEnd` prop (#21912) @MBilalShafi

#### `@mui/x-data-grid-premium@9.0.0-rc.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.0.0-rc.0`, plus:

- [DataGridPremium] Fix clipboard paste issue in portal (#21931) @sibananda485

### Date and Time Pickers

#### Breaking changes

- Accessible DOM structure is now the only default. [Read more](https://mui.com/x/migration/migration-pickers-v8/#accessible-dom-structure-is-now-the-default)
- The `PickerDay2` and `DateRangePickerDay2` components were propagated to stable while removing the previous defaults. [Read more](https://mui.com/x/migration/migration-pickers-v8/#day-slot)

#### `@mui/x-date-pickers@9.0.0-rc.0`

- [pickers] Remove `PickersDay` and `DateRangePickerDay` and promote their `2` versions as replacements (#21739) @michelengelen

#### `@mui/x-date-pickers-pro@9.0.0-rc.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.0.0-rc.0`.

### Charts

#### `@mui/x-charts@9.0.0-rc.0.0`

- [charts] Make line visibility toggle start from the baseline (#21893) @alexfauquette
- [charts] Remove the container overflow (#21955) @alexfauquette
- [charts] Revert `theme.alpha` for non-channel token (#21965) @siriwatknp

#### `@mui/x-charts-pro@9.0.0-rc.0.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.0.0-rc.0.0`, plus:

- [charts-pro] Zoom slider touch improvements (#21832) @JCQuintas
- [charts-pro] Add `seriesIds` filter to zoom slider preview (#21933) @JCQuintas
- [charts-pro] Fix zoom slider preview with discard filter mode (#21883) @JCQuintas

#### `@mui/x-charts-premium@9.0.0-rc.0.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.0.0-rc.0.0`, plus:

- [charts-premium] Add series `valueFormatter` to candlestick chart (#21905) @JCQuintas
- [charts-premium] Add zoom slider preview support for candlestick charts (#21914) @JCQuintas
- [charts-premium] Allow color customization in `Candlestick` chart (#21838) @JCQuintas
- [charts-premium] Support hide/show for OHLC (candlestick) series (#21807) @Copilot
- [charts-premium] Add `dataset` support to `Candlestick` chart (#21872) @JCQuintas
- [charts-premium] Add candlestick page to sidebar navigation (#21834) @JCQuintas

### Tree View

#### `@mui/x-tree-view@9.0.0-rc.0`

Internal changes.

#### `@mui/x-tree-view-pro@9.0.0-rc.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.0.0-rc.0`, plus:

- [RichTreeViewPro] Allow to auto-expand lazy loaded items (#21759) @flaviendelangle

### Scheduler

#### `@mui/x-scheduler@9.0.0-alpha.0`

- [scheduler] Add locale files, adapt l10n scripts, and add localization table to docs (#21870) @rita-codes
- [scheduler] Add planned features to the docs (#21705) @rita-codes
- [scheduler] Add scheduler to docs introduction (#21845) @rita-codes
- [scheduler] Add wide docs to scheduler (#21860) @noraleonte
- [scheduler] All day event bugfixes (#21884) @noraleonte
- [scheduler] Autofocus title field (#21947) @noraleonte
- [scheduler] Change default event creation trigger to single click (#21979) @rita-codes
- [scheduler] Change order of the views on the view selector (#21904) @rita-codes
- [scheduler] Disabled border color for the repeat day picker in dark mode (#21987) @rita-codes
- [scheduler] Drop unused dependency (#21956) @flaviendelangle
- [scheduler] Fix all-day event shifting to previous day in negative UTC offsets (#21994) @rita-codes
- [scheduler] Fix dark theme localization demos (#21992) @noraleonte
- [scheduler] Fix licensing confusion in docs (#21939) @rita-codes
- [scheduler] Fix preferences menu width shift when toggling options + Improve preferences menu accessibility (#21902) @rita-codes
- [scheduler] Prepare for the alpha launch (#21859) @rita-codes
- [scheduler] Sync Base UI internals and apply good practices (#21946) @flaviendelangle
- [scheduler] Update close modal aria label translation (#21940) @rita-codes
- [scheduler] Add Spanish (es-ES) locale (#21900) @rita-codes
- [scheduler] Improve French (fr-FR) locale (#21941) @rita-codes
- [scheduler] Improve Romanian (ro-RO) locale (#21942) @rita-codes

#### `@mui/x-scheduler-premium@9.0.0-alpha.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-scheduler@9.0.0-alpha.0`.

### Codemod

#### `@mui/x-codemod@9.0.0-rc.0`

Internal changes.

### Docs

- [docs] Fix JSDOM → jsdom casing (#21907) @JCQuintas
- [docs] Remove Joy UI references and dependency (#21937) @siriwatknp
- [docs] Remove none generated files (#21886) @alexfauquette
- [docs] Remove unused interactive demo code (#21945) @LukasTy
- [docs] Revise the Funnel doc (#21677) @mapache-salvaje
- [docs] Revise the Line chart docs (#21554) @mapache-salvaje
- [docs] Revise the Radar doc (#21674) @mapache-salvaje
- [docs] Revise the Sankey doc (#21678) @mapache-salvaje
- [docs] Revise the Scatter chart docs (#21564) @mapache-salvaje

### Core

- [docs-infra] Update to the latest monorepo (#21971) @brijeshb42
- [internal] Remove checks for `materialVersion >= 6` (#21975) @LukasTy

### Miscellaneous

- [core] Bump @mui/material to v9.0.0-beta.1 (#21858) @siriwatknp
- [core] Update browserslistrc (#21974) @siriwatknp
- [deps] Bump minimum core packages to 7.3.0 to adopt theme color manipulator (#21892) @siriwatknp
- [telemetry] Prefer upstream remote over origin for `projectId` (#21882) @aemartos
- [telemetry] Send `repoHash`, `[x]packageNameHash`, and `rootPathHash` alongside `projectId` (#21896) @aemartos
- [test] Exclude flaky `DataGrid` argos test (#21977) @MBilalShafi
- [test] Fix flaky `DataGrid` test (#22000) @arminmeh
- [test] Remove `componentsProp` test from `describeConformance` (#21897) @ZeeshanTamboli
- [x-license] Change `orderId` type from `number` to `string` (#21885) @aemartos

## 9.0.0-beta.0

<!-- generated comparing v9.0.0-alpha.4..master -->

_Mar 27, 2026_

We'd like to extend a big thank you to the 10 contributors who made this release possible. Here are some highlights ✨:

- 🔊 New Charts voiceover component for improved screen reader support
- ⌨️ Charts keyboard navigation improvements: axis tooltip now shows when navigating with the keyboard
- 📊 Charts axes now can be set to automatically resize to fit their content
- 📝 New `rowCheckbox` slot in Data Grid for easier checkbox column customization
- ⚡️ `fetchRows()` API in Data Grid Pro now defaults `start` and `end` based on scroll position with lazy loading
- 🐞 Bugfixes and internal improvements

The following team members contributed to this release:
@aemartos, @alexfauquette, @arminmeh, @cherniavskii, @Janpot, @JCQuintas, @mapache-salvaje, @michelengelen, @noraleonte, @rita-codes

### Data Grid

#### `@mui/x-data-grid@9.0.0-beta.0`

- [DataGrid] Add `rowCheckbox` slot for easier customization (#21797) @michelengelen
- [DataGrid] Prevent repeated `hasScrollbar` state updates (#21820) @arminmeh

#### `@mui/x-data-grid-pro@9.0.0-beta.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.0.0-beta.0`, plus:

- [DataGridPro] `fetchRows()` API's default `start` and `end` params based on scroll position with lazy loading (#21742) @arminmeh

#### `@mui/x-data-grid-premium@9.0.0-beta.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.0.0-beta.0`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.0.0-beta.0`

Internal changes.

#### `@mui/x-date-pickers-pro@9.0.0-beta.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.0.0-beta.0`.

### Charts

#### `@mui/x-charts@9.0.0-beta.0`

- [charts] Add `className` prop to Pro chart plot components (#21793) @JCQuintas
- [charts] Add experimental position-based pointer interaction for line series (#21809) @JCQuintas
- [charts] Add l10n to the bar accessibility (#21815) @alexfauquette
- [charts] Add localization for the basic charts (#21822) @alexfauquette
- [charts] Add voiceover component (#21344) @alexfauquette
- [charts] Allow axes to automatically resize to content (#21087) @JCQuintas
- [charts] Document multiple use-cases for references (#21768) @alexfauquette
- [charts] Remove compatibility layer for React vs native events (#21780) @JCQuintas
- [charts] Remove deprecated `barLabel` props (#21783) @alexfauquette
- [charts] Show axis tooltip when navigating with keyboard (#21689) @Copilot

#### `@mui/x-charts-pro@9.0.0-beta.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.0.0-beta.0`.

#### `@mui/x-charts-premium@9.0.0-beta.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.0.0-beta.0`.

### Tree View

#### `@mui/x-tree-view@9.0.0-alpha.4`

Internal changes.

#### `@mui/x-tree-view-pro@9.0.0-alpha.4` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.0.0-alpha.4`.

### Codemod

#### `@mui/x-codemod@9.0.0-alpha.4`

Internal changes.

### Docs

- [docs] Document how to customize voiceover announcement (#21833) @alexfauquette
- [docs] Remove Discord mention from docs (#21855) @mapache-salvaje
- [docs] Remove stabilized experimental feature from demo (#21869) @JCQuintas
- [docs] Update telemetry guide to reflect pseudonymous data collection and license compliance (#21812) @aemartos
- [docs] Revise the Sparkline doc (#21614) @mapache-salvaje
- [docs] Revise the Gauge doc (#21673) @mapache-salvaje
- [docs] Revise the Heatmap doc (#21676) @mapache-salvaje

### Core

- [code-infra] Remove unused deps and unify es-toolkit via catalog (#21840) @Janpot
- [code-infra] Update @mui/internal-bundle-size-checker to canary.68 (#21836) @Janpot
- [code-infra] Update next (#21837) @Janpot
- [internal] Remove headless data grid packages (#21843) @cherniavskii

### Miscellaneous

- Add @romgrk to CODEOWNERS for `x-virtualizer` and `x-internals` (#21819) @Copilot
- [x-license] add 2022 plan version (#21814) @aemartos

## 9.0.0-alpha.4

_Mar 19, 2026_

We'd like to extend a big thank you to the 12 contributors who made this release possible. Here are some highlights ✨:

- 🐞 Bugfixes and internal improvements

The following team members contributed to this release:
@aemartos, @alexfauquette, @bernardobelchior, @Janpot, @JCQuintas, @LukasTy, @mapache-salvaje, @michelengelen, @noraleonte, @rita-codes, @sai6855, @siriwatknp

### Data Grid

#### `@mui/x-data-grid@9.0.0-alpha.4`

- [DataGrid] Mark charts integration as stable (#21764) @JCQuintas
- [DataGrid] Move `elementOverrides` to constants and remove duplicates (#21618) @sai6855
- [DataGrid] Migrate from deprecated Material UI APIs (#21682) @siriwatknp

#### `@mui/x-data-grid-pro@9.0.0-alpha.4` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.0.0-alpha.4`.

#### `@mui/x-data-grid-premium@9.0.0-alpha.4` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.0.0-alpha.4`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.0.0-alpha.4`

- [pickers] Avoid stealing focus on click away (#13434) @LukasTy
- [pickers] Promote `fieldRef` to stable and add `clearValue` method (#21655) @michelengelen

#### `@mui/x-date-pickers-pro@9.0.0-alpha.4` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.0.0-alpha.4`.

### Charts

#### `@mui/x-charts@9.0.0-alpha.4`

- [charts] Add v9 chart series types and helper functions migration (#21009) @bernardobelchior
- [charts] Extract event listener to the layer container (#21751) @alexfauquette
- [charts] Fix WebGL print export canvas stretching (#21738) @JCQuintas
- [charts] Improve deprecation warnings (#21760) @alexfauquette
- [charts] Improve type safety in `identifierCleaner` (#21719) @bernardobelchior
- [charts] Make `preferStrictDomainInLineCharts` the default (#21744) @JCQuintas
- [charts] Move title and description to the layer container (#21757) @alexfauquette
- [charts] Refactor `FunnelChart` classes structure (#21652) @JCQuintas
- [charts] Refactor `Heatmap` classes structure (#21653) @JCQuintas
- [charts] Refactor `RadarChart` classes structure (#21650) @JCQuintas
- [charts] Refactor `SankeyChart` classes structure (#21654) @JCQuintas
- [charts] Refactor legend getters to use utility functions (#21628) @sai6855
- [charts] Remove deprecated `ChartContainer` and `ChartDataProvider` (#21777) @alexfauquette
- [charts] Remove deprecated `itemId` from `SeriesLegendItemContext` (#21788) @alexfauquette
- [charts] Remove deprecated `useMouseTracker()` (#21787) @alexfauquette
- [charts] Remove deprecated classes (#21775) @alexfauquette
- [charts] Remove deprecated props from PieArcLabel animation (#21789) @alexfauquette
- [charts] Remove get\*UtilityClass from public exports (#21769) @JCQuintas
- [charts] Remove the deprecated `disableHover` property (#21785) @alexfauquette
- [charts] Remove the deprecated `message` prop (#21784) @alexfauquette
- [charts] Remove deprecated props about voronoi (#21796) @alexfauquette
- [charts] Remove deprecated pieArcClasses (#21795) @alexfauquette
- [charts] Rename `data-series-id` by `data-series` (#21761) @alexfauquette
- [charts] Rename `voronoiMaxRadius`/`disableVoronoi` to `hitAreaRadius`/`disableHitArea` (#21750) @bernardobelchior
- [charts] Update pt-PT locale (#21296) @bernardobelchior
- [charts] Use different shape per series by default (#21713) @alexfauquette
- [charts] Add className prop to Radar components (#21794) @JCQuintas
- [charts] Add className prop to shared chart components (#21792) @JCQuintas
- [charts] Add className prop to BarPlot (#21791) @JCQuintas
- [charts] Portal tooltip into ChartsLayerContainer (#21801) @JCQuintas

#### `@mui/x-charts-pro@9.0.0-alpha.4` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.0.0-alpha.4`, plus:

- [charts-pro] Allow `brush` interaction to accept `requiredKeys/pointerMode` (#21716) @JCQuintas
- [charts-pro] Remove deprecated `onAxisClick` for Heatmap (#21786) @alexfauquette

#### `@mui/x-charts-premium@9.0.0-alpha.4` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.0.0-alpha.4`, plus:

- [charts-premium] Add candlestick chart (#21129) @bernardobelchior

### Tree View

#### `@mui/x-tree-view@9.0.0-alpha.4`

Internal changes.

#### `@mui/x-tree-view-pro@9.0.0-alpha.4` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.0.0-alpha.4`.

### Codemod

#### `@mui/x-codemod@9.0.0-alpha.4`

Internal changes.

### Docs

- [docs-infra] Exclude `ServerSideLazyLoadingRevalidation` from argos (#21734) @sai6855
- [docs] Update charts v9 migration guide to include premium package (#21743) @bernardobelchior
- [docs] Update v9 migration guides to install next tag (#21741) @bernardobelchior
- [docs] Revise the Pie chart docs (#21565) @mapache-salvaje
- [docs] Revise the Bar Chart docs (#21482) @mapache-salvaje
- [docs] Removed a `console.log` from an aggregation demo (#21698) @michelengelen

### Core

- [code-infra] Add pkg-pr-new as dev dependency (#21754) @Janpot
- [code-infra] Prevent `combiner` to have default parameters (#21707) @JCQuintas
- [code-infra] Remove CI coverage collection and upload to Codecov (#21671) @Janpot
- [internal] Remove @bernardobelchior from Charts CODEOWNERS (#21776) @Copilot

### Miscellaneous

- [x-license] Fix process.env.MUI_VERSION not being replaced during build (#21727) @aemartos
- [x-license] Add new watermark license status message (#21720) @aemartos

## 9.0.0-alpha.3

_Mar 12, 2026_

We'd like to extend a big thank you to the 13 contributors who made this release possible. Here are some highlights ✨:

- 🐞 Bugfixes and internal improvements

The following team members contributed to this release:
@aemartos, @alexfauquette, @bernardobelchior, @brijeshb42, @cherniavskii, @flaviendelangle, @Janpot, @JCQuintas, @MBilalShafi, @michelengelen, @rita-codes, @sai6855, @siriwatknp

### Data Grid

#### `@mui/x-data-grid@9.0.0-alpha.3`

- [DataGrid] Fix crash when `rows` and `rowModesModel` are updated simultaneously (#21265) @michelengelen
- [DataGrid] Add missing `resizablePanelHandle` classes to `gridClasses` object (#21538) @sai6855
- [DataGrid] Refactor `headerAlign` style calls (#21541) @sai6855

#### `@mui/x-data-grid-pro@9.0.0-alpha.3` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.0.0-alpha.3`, plus:

- [DataGridPro] Add `role="presentation"` to detail panel toggle header content (#21634) @michelengelen
- [DataGridPro] Fix sorting not reflected in nested server-side data (#21619) @MBilalShafi

#### `@mui/x-data-grid-premium@9.0.0-alpha.3` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.0.0-alpha.3`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.0.0-alpha.3`

- [pickers] Refactor `DateRangePickerDay` overrides to use a centralized `elementOverrides` object (#21426) @sai6855
- [pickers] Migrate from deprecated props for `PickersModalDialog` (#21702) @siriwatknp

#### `@mui/x-date-pickers-pro@9.0.0-alpha.3` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.0.0-alpha.3`.

### Charts

#### `@mui/x-charts@9.0.0-alpha.3`

- [charts] Differentiate Line Plot roots classes (#21679) @JCQuintas
- [charts] Enable keyboard navigation by default (#21675) @alexfauquette
- [charts] Fix keyboard tooltip radar (#21667) @alexfauquette
- [charts] Fix selector default parameter (#21638) @JCQuintas
- [charts] Fix tooltip blink between node and pointer anchor (#21611) @alexfauquette
- [charts] Let tooltip and legend reflect the line shape (#21475) @alexfauquette
- [charts] Refactor `BarChart` classes structure (#21601) @JCQuintas
- [charts] Refactor `LineChart` classes structure (#21648) @JCQuintas
- [charts] Refactor `ScatterChart` classes structure (#21651) @JCQuintas
- [charts] Refactor `PieChart` classes structure (#21649) @JCQuintas
- [charts] Remove batch rendering checks in highlight selectors (#21646) @bernardobelchior
- [charts] Standardize generic arg names to `SeriesType` (#21694) @alexfauquette
- [charts] Simplify highlight hooks return types (#21695) @alexfauquette

#### `@mui/x-charts-pro@9.0.0-alpha.3` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.0.0-alpha.3`, plus:

- [charts-pro] Fix heatmap style override from `arc` to `cell` (#21693) @Copilot
- [charts-pro] Fix image export truncated when page is zoomed out (#21685) @bernardobelchior
- [charts-pro] Speed-up heatmap cell search with an index lookup (#21130) @alexfauquette
- [charts-pro] Fix heatmap highlight not working (#21710) @Copilot

#### `@mui/x-charts-premium@9.0.0-alpha.3` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.0.0-alpha.3`, plus:

- [charts-premium] Re-enable WebGL tests (#21708) @bernardobelchior

### Tree View

#### Breaking changes

- Remove `TreeViewBaseItem` type (use `TreeViewDefaultItemModelProperties` or a custom interface)
- Remove `useTreeViewApiRef` hook (use `useRichTreeViewApiRef`, `useSimpleTreeViewApiRef`, or `useRichTreeViewProApiRef`)
- Remove `status` from content slot props returned by `getContentProps()` (use `data-*` attributes; `status` on `useTreeItem` return value is unchanged)
- Remove deprecated CSS state classes from `treeItemClasses`: `expanded`, `selected`, `focused`, `disabled`, `editable`, `editing` (use `[data-expanded]`, `[data-selected]`, etc.)
- The `<RichTreeViewPro />` component has now virtualization enabled by default.
- The items used inside the `<RichTreeViewPro />` now have a default height of `32px`.
- The items of the `<RichTreeViewPro />` are now rendered as a flat list instead of a nested tree.

#### `@mui/x-tree-view@9.0.0-alpha.3`

- [tree view] Remove deprecated APIs (#21591) @flaviendelangle
- [tree view] Fix collapsed children not selected with `selectionPropagation.descendants` in `SimpleTreeView` (#21253) @flaviendelangle

#### `@mui/x-tree-view-pro@9.0.0-alpha.3` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.0.0-alpha.3`, plus:

- [RichTreeViewPro] Make the virtualization opt-out and port the layout doc from the data grid (#21461) @flaviendelangle

### Codemod

#### `@mui/x-codemod@9.0.0-alpha.3`

Internal changes.

### Docs

- [docs] Fix `AssistantWithDataSource` demo crashing (#21555) @sai6855
- [docs] Remove `Preview` pill from Sankey (#21623) @bernardobelchior
- [docs] Migrate internal Material UI deprecated APIs (#21680) @siriwatknp
- [docs] Remove `New` flag on Tree View and Date and Time Pickers features released before v9 alpha (#21585) @flaviendelangle

### Core

- [code-infra] Remove checkout step (#21688) @Janpot
- [code-infra] Fix contributor generation in changelog (#21718) @brijeshb42
- [docs-infra] Do not point to non-existent v8 subdomain (#21640) @cherniavskii

### Miscellaneous

- [test] Add missing tests for forwarding props to filter operators in DataGrid (#21441) @siriwatknp
- [x-license] Export additional license types and constants (#21625) @aemartos
- [x-license] Refactor license verification to accept package info object and add v9 version gating (#21690) @aemartos

## 9.0.0-alpha.2

_Mar 5, 2026_

We'd like to extend a big thank you to the 12 contributors who made this release possible. Here are some highlights ✨:

- ✅ Stabilize Sankey chart
- 🐞 Bugfixes and internal improvements

The following team members contributed to this release:
@aemartos, @alelthomas, @alexfauquette, @arminmeh, @bernardobelchior, @brijeshb42, @Janpot, @JCQuintas, @mapache-salvaje, @michelengelen, @mj12albert, @sai6855, @siriwatknp

### Data Grid

#### `@mui/x-data-grid@9.0.0-alpha.2`

- [dataGrid] Fix keyboard nav with single-row checkbox selection (#21149) @mj12albert
- [DataGrid] Add `checkboxColDef` prop to customize the selection column (#21331) @michelengelen
- [DataGrid] Format pagination numbers by default (#21117) @siriwatknp
- [DataGrid] Prevent unnecessary row selection checkbox rerendering (#21570) @arminmeh
- [DataGrid] Make GridScrollArea overrides resolver dynamic (#21532) @sai6855

#### `@mui/x-data-grid-pro@9.0.0-alpha.2` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.0.0-alpha.2`, plus:

- [DataGridPro] Use `getRowId` prop to calculate the tree data row update (#21540) @arminmeh

#### `@mui/x-data-grid-premium@9.0.0-alpha.2` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.0.0-alpha.2`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.0.0-alpha.2`

- [pickers] Add `keepOpenDuringFieldFocus` prop (#20782) @michelengelen

#### `@mui/x-date-pickers-pro@9.0.0-alpha.2` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.0.0-alpha.2`.

### Charts

#### `@mui/x-charts@9.0.0-alpha.2`

- [charts] Add `ChartsLayerContainer` component (#21264) @bernardobelchior
- [charts] Add codemod for `ChartsContainer` rename (#21504) @JCQuintas
- [charts] Add codemod for `ChartsDataProvider` rename (#21552) @JCQuintas
- [charts] Add codemod for `ChartsZoomSlider` rename (#21597) @JCQuintas
- [charts] Base the highlight items on the item identifiers (#21161) @alexfauquette
- [charts] Deprecate `ChartDataProvider` in favour of `ChartsDataProvider` (#21191) @JCQuintas
- [charts] Deprecate `highlighted` and `faded` classes (#21476) @alexfauquette
- [charts] Migrate to latest v8 warning (#21518) @JCQuintas
- [charts] Rename `ChartZoomSlider` to `ChartsZoomSlider` (#21553) @JCQuintas
- [charts] Rename `WebGl` to `WebGL` (#21524) @JCQuintas
- [charts] Rename `useSvgRef()` by `useChartsLayerContainerRef()` (#21494) @alexfauquette
- [charts] Restore focus on last focused item (#21522) @alexfauquette
- [charts] Warn users when controlled tooltip state does not match the trigger (#21520) @Copilot
- [charts] Fix controlled tooltip position (#21603) @bernardobelchior

#### `@mui/x-charts-pro@9.0.0-alpha.2` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.0.0-alpha.2`, plus:

- [charts-pro] Center the watermark (#21550) @alexfauquette
- [charts-pro] Stabilize `SankeyChart` API (#21133) @Copilot

#### `@mui/x-charts-premium@9.0.0-alpha.2` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.0.0-alpha.2`.

### Tree View

#### `@mui/x-tree-view@9.0.0-alpha.2`

Internal changes.

#### `@mui/x-tree-view-pro@9.0.0-alpha.2` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.0.0-alpha.2`.

### Codemod

#### `@mui/x-codemod@9.0.0-alpha.2`

Internal changes.

### Docs

- [docs] Add backticks and parentheses to all functions and hooks (DX-173) (#21496) @mapache-salvaje
- [docs] Remove mentions of `mySvgRef` (#21559) @bernardobelchior
- [docs] Update Roadmap section in the docs (#20892) @alelthomas
- [docs] Add tutorial and example app for aggregation with row grouping (DX-162) (#21102) @mapache-salvaje
- [docs] Fix missing codemod docs (#21604) @JCQuintas

### Core

- [code-infra] Add eslint rule to prevent `Math.random` in docs (#21505) @JCQuintas
- [code-infra] Avoid static props for pageContent (#21038) @Janpot
- [code-infra] Isolate `date-pickers-pro` in the browser tests (#21383) @Janpot
- [code-infra] Remove `--coverage` (#21410) @Janpot
- [code-infra] Remove unneeded `skipIf`s (#21569) @JCQuintas
- [code-infra] Remove vale as a workspace dependency (#21489) @brijeshb42
- [code-infra] Remove x-charts-vendor from nextjs processing (#21534) @brijeshb42
- [code-infra] Set BASE_BRANCH env var in CircleCI config (#21548) @brijeshb42
- [code-infra] Setup error code extraction (#21469) @brijeshb42
- [code-infra] Setup flat build for packages (#21029) @brijeshb42
- [code-infra] Upgrade test_unit to large resource class (#21558) @Janpot
- [code-infra] Removed getTeamMembers function and usage from release script (#21605) @michelengelen

### Miscellaneous

- [x-license] Add Q1-2026 plan version with quantity and appType support (#21574) @aemartos
- [x-license] Add v3 key format support, centralize test keys, and trim public API (#21485) @aemartos
- [x-telemetry] telemetry opt-out by default, remove conf dependency (#21470) @aemartos
- [x-telemetry] test: mock context module directly in sender tests (#21546) @aemartos

## 9.0.0-alpha.1

_Feb 26, 2026_

We'd like to extend a big thank you to the 18 contributors who made this release possible. Here are some highlights ✨:

- ⚡️ Improved dynamic data support and cache invalidation in lazy loading for Data Grid Pro
- ⌨️ Keyboard support for selecting day, month, and year in Date Pickers
- 📊 Axis tooltip sorting and control improvements in Charts
- 🐞 Bugfixes and internal improvements

Special thanks go out to these community members for their valuable contributions:
@EllGree, @lion1963

The following team members contributed to this release:
@alexfauquette, @arminmeh, @brijeshb42, @cherniavskii, @dav-is, @flaviendelangle, @Janpot, @JCQuintas, @mapache-salvaje, @MBilalShafi, @michelengelen, @noraleonte, @rita-codes, @sai6855, @siriwatknp, @ZeeshanTamboli

### Data Grid

#### `@mui/x-data-grid@9.0.0-alpha.1`

- [DataGrid] Forward rest props in `GridFilterInputMultipleValue` (#21407) @siriwatknp
- [DataGrid] Preserve key input during row edit when using `rowModesModel` (#20759) @michelengelen
- [DataGrid] Remove double rtl inversion logic for columns pinning (#21371) @siriwatknp

#### `@mui/x-data-grid-pro@9.0.0-alpha.1` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.0.0-alpha.1`, plus:

- [DataGridPro] Fix number input visibility in header filters (#21328) @michelengelen
- [DataGridPro] Improve dynamic data support and cache invalidation in lazy loading (#21282) @MBilalShafi

#### `@mui/x-data-grid-premium@9.0.0-alpha.1` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.0.0-alpha.1`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.0.0-alpha.1`

- [DatePicker] Add keyboard support for selecting day, month, and year (#20859) @michelengelen

#### `@mui/x-date-pickers-pro@9.0.0-alpha.1` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.0.0-alpha.1`, plus:

- [DateRangePicker] Fix timezone update issue leading to `invalidRange` error (#20863) @michelengelen

### Charts

#### `@mui/x-charts@9.0.0-alpha.1`

- [charts] Add `sort` props to the axis tooltip (#21293) @alexfauquette
- [charts] Controll axis tooltip (#21351) @alexfauquette
- [charts] De duplicate keyboard focus handler function (#21267) @sai6855
- [charts] Make `type` optional in identifiers (#21311) @alexfauquette
- [charts] Move ref to the root component (#21396) @alexfauquette
- [charts] Refactor loading and no data overlays to use a shared OverlayText component (#21414) @sai6855
- [charts] Require series ids to be unique (#21330) @alexfauquette
- [charts] Set `showMark` as `false` by default (#21373) @alexfauquette
- [charts] Use `createGetNextIndexFocusedItem()` util in Funnel and RangeBar charts (#21390) @sai6855
- [charts] Remove unnecessary string concatenation (#21418) @sai6855

#### `@mui/x-charts-pro@9.0.0-alpha.1` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.0.0-alpha.1`.

#### `@mui/x-charts-premium@9.0.0-alpha.1` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.0.0-alpha.1`.

### Tree View

#### `@mui/x-tree-view@9.0.0-alpha.1`

- [tree view] Focus item sibling on unmount instead of the 1st item (#21254) @flaviendelangle

#### `@mui/x-tree-view-pro@9.0.0-alpha.1` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.0.0-alpha.1`.

### Codemod

#### `@mui/x-codemod@9.0.0-alpha.1`

Internal changes.

### Docs

- [docs] Fix external 301s (#21377) @Janpot
- [docs] Show premium in the overview (#21343) @alexfauquette
- [docs][charts] Revise the useLegend hook doc (#21352) @mapache-salvaje
- [docs][charts] Revise the axis hooks doc (#21317) @mapache-salvaje
- [docs][charts] Revise the scale hooks doc (#21316) @mapache-salvaje
- [docs][charts] Revise the series hooks doc (#21353) @mapache-salvaje
- [docs][charts] Revise the useDataset doc (#21336) @mapache-salvaje
- [docs][charts] Revise the useDrawingArea doc (#21333) @mapache-salvaje

### Core

- [core] Update docs deploy script to the `docs-next` branch (#21341) @siriwatknp
- [code-infra] Cleanup unused babel plugins (#21453) @brijeshb42
- [code-infra] Do not append `x` to the last version for the compare API (#21408) @arminmeh
- [code-infra] Upgrade react-docgen to v8 X (#21155) @JCQuintas
- [code-infra] Modernize codemod (#21096) @JCQuintas
- [docs-infra] Fix current version detection logic (#21417) @cherniavskii
- [docs-infra] Reapply Cookie Banner (#21281) @dav-is
- [internal] Headless filtering plugin (#21302) @arminmeh
- [internal] Headless pagination plugin (#21183) @arminmeh
- [internal] Headless virtualization followups (#21327) @cherniavskii
- [internal] Keep cached data for disabled pipe processors (#21348) @arminmeh
- [internal] Remove autoprefixer package (#21440) @ZeeshanTamboli

### Miscellaneous

- [l10n] Fix Czech (csCZ) locale: sort/filter labels are swapped (#21400) @EllGree
- [l10n] Improve Ukrainian (uk-UA) locale (#21366) @lion1963

## 9.0.0-alpha.0

_Feb 16, 2026_

We'd like to extend a big thank you to the 21 contributors who made this release possible. Here are some highlights ✨:

- Add support for virtualized items on `<RichTreeViewPro />`:

  ```tsx
  <RichTreeViewPro items={ITEMS} virtualization itemHeight={48} />
  ```

- Add Thai (`thTH`) locale on the Data Grid and the Date and Time Pickers (#21116) @siriwatknp
- Add a new `AdapterDayjsBuddhist` adapter for Date and Time Pickers (#20984) @siriwatknp
- Add support for virtualization in the rich tree view (#20780) @flaviendelangle
- Add WebGL renderer to Heatmap (#20756) @bernardobelchior

Special thanks go out to these community members for their valuable contributions:
@jhe-iqbis

The following team members contributed to this release:
@alexfauquette, @arminmeh, @bernardobelchior, @brijeshb42, @cherniavskii, @dav-is, @flaviendelangle, @Janpot, @JCQuintas, @mapache-salvaje, @MBilalShafi, @michelengelen, @mj12albert, @noraleonte, @oliviertassinari, @rita-codes, @romgrk, @sai6855, @siriwatknp

### Data Grid

#### `@mui/x-data-grid@9.0.0-alpha.0`

- [DataGrid] Update default `logicOperator` behavior in filtering docs (#21098) @michelengelen
- [DataGrid] Add `thTH` locale (#21116) @siriwatknp
- [DataGrid] Fix initial filter value state in CustomMultiValueOperator demo (#21217) @sai6855

#### `@mui/x-data-grid-pro@9.0.0-alpha.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-data-grid@9.0.0-alpha.0`, plus:

- [DataGridPro] Cleanup outdated rows on `dataSource` reference update (#21138) @MBilalShafi

#### `@mui/x-data-grid-premium@9.0.0-alpha.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-data-grid-pro@9.0.0-alpha.0`.

### Date and Time Pickers

#### `@mui/x-date-pickers@9.0.0-alpha.0`

- [pickers] Add `AdapterDayjsBuddhist` adapter (#20984) @siriwatknp
- [pickers] Add `thTH` locale (#21116) @siriwatknp

#### `@mui/x-date-pickers-pro@9.0.0-alpha.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-date-pickers@9.0.0-alpha.0`.

### Charts

#### `@mui/x-charts@9.0.0-alpha.0`

- [charts] Add Legend actions (#20404) @JCQuintas
- [charts] Add `Chart` suffix to MUI Classes (#21042) @JCQuintas
- [charts] Add `axesGap` props to put space between axes (#20904) @alexfauquette
- [charts] Add `cleanIdentifier` function to charts series instance (#20832) @JCQuintas
- [charts] Add `initialHiddenItems` prop to set initial state (#20894) @JCQuintas
- [charts] Add `useXAxisCoordinates` and `useYAxisCoordinates` hooks (#20972) @bernardobelchior
- [charts] Add axis slots and expose axis ticks hooks (#20935) @bernardobelchior
- [charts] Change `line` legend marker to be a line (#21059) @JCQuintas
- [charts] Codemod test pattern with function (#21111) @JCQuintas
- [charts] Control the item tooltip (#20617) @alexfauquette
- [charts] Enable keyboard navigation in radar chart (#20765) @alexfauquette
- [charts] Export `CartesianChartSeriesType` and `StackableChartSeriesType` (#21012) @bernardobelchior
- [charts] Export plugins from premium (#20866) @JCQuintas
- [charts] Filter hidden series from axis tooltip (#21273) @Copilot
- [charts] Filter hidden series from axis tooltip (#21273) @Copilot
- [charts] Fix rename `getSVGPoint` to `getChartPoint` (#21335) @bernardobelchior
- [charts] Fix cleanup function in useChartInteractionListener to correctly remove event listeners with options (#21218) @sai6855
- [charts] Fix import rename in codemod (#21112) @JCQuintas
- [charts] Fix multiple exports of `HighlightScope` (#21270) @bernardobelchior
- [charts] Fix test inconsistency in charts (#20907) @JCQuintas
- [charts] Fix tooltip position for stacked line series (#20901) @alexfauquette
- [charts] Make Highlight scope a generic (#21189) @alexfauquette
- [charts] Make `LegendItemParams.type` required (#21003) @alexfauquette
- [charts] Make `seriesId` a string only (#20997) @alexfauquette
- [charts] Make the `useChartRootRef` support typing parameter (#21023) @alexfauquette
- [charts] Memoize HeatmapItem to avoid re-render when fading/highlighting (#20865) @bernardobelchior
- [charts] Move axis id to `data-axis-id` attribute instead of class (#21037) @JCQuintas
- [charts] Move `cleanIdentifier` and `serializeIdentifier` instance methods to `useChartSeriesConfig` plugin (#21025) @JCQuintas
- [charts] Move `seriesConfig` to `useChartSeriesConfig` plugin (#21004) @JCQuintas
- [charts] Move element refs to `useChartElementRef` plugin (#21099) @JCQuintas
- [charts] Move types related to `seriesConfig` into the `useChartSeriesConfig` plugin folder (#21026) @JCQuintas
- [charts] Remove `data-has-focused-item` from `ChartsSurface` (#21255) @bernardobelchior
- [charts] Remove default generic of item identifiers (#21182) @alexfauquette
- [charts] Remove deprecated `id` from `LegendItemParams` (#21055) @alexfauquette
- [charts] Remove deprecated `ChartApi` export from `ChartContainer` (#20975) @JCQuintas
- [charts] Remove deprecated `useAxisTooltip` in favor of `useAxesTooltip` (#20962) @Copilot
- [charts] Remove deprecated series type helpers and functions (#20998) @alexfauquette
- [charts] Rename `ChartContainer` to `ChartsContainer` (#21173) @JCQuintas
- [charts] Rename `getSVGPoint` to `getChartPoint` (#21322) @bernardobelchior
- [charts] Rename `TickItemType` to `TickItem` (#21008) @bernardobelchior
- [charts] Replace props `id` by `seriesId` when necessary (#21057) @alexfauquette
- [charts] Revert `touch-action: pan-y` removal when zoom is disabled (#20852) @bernardobelchior
- [charts] The `useXxxSeries([])` return empty array (#21001) @alexfauquette
- [charts] Use `NumberValue` in domain limit function (#21054) @JCQuintas

#### `@mui/x-charts-pro@9.0.0-alpha.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-charts@9.0.0-alpha.0`, plus:

- [charts-pro] Add border radius to heatmap (#20931) @bernardobelchior
- [charts-pro] Add keyboard navigation to funnel (#20766) @alexfauquette
- [charts-pro] Add keyboard navigation to heatmap (#20786) @alexfauquette
- [charts-pro] Add keyboard navigation to sankey (#20777) @alexfauquette
- [charts-pro] Fix Heatmap's `onItemClick` not triggering (#21016) @bernardobelchior
- [charts-pro] Fix crash when two same-direction axes have a zoom preview (#20916) @bernardobelchior
- [charts-pro] Handle edge case in export image (#21190) @bernardobelchior
- [charts-pro] Prefer global pointer interaction tracker in Heatmap (#20697) @bernardobelchior
- [charts-pro] Support composition for Sankey (#20604) @alexfauquette
- [charts-pro] Update Heatmap identifier (#21124) @alexfauquette
- [charts-pro] Update default value of `hideLegend` prop in `Heatmap` (#20961) @Copilot

#### `@mui/x-charts-premium@9.0.0-alpha.0` [![premium](https://mui.com/r/x-premium-svg)](https://mui.com/r/x-premium-svg-link 'Premium plan')

Same changes as in `@mui/x-charts-pro@9.0.0-alpha.0`, plus:

- [charts-premium] Add WebGL renderer to Heatmap (#20756) @bernardobelchior
- [charts-premium] Add `ChartContainerPremium` (#20910) @bernardobelchior
- [charts-premium] Add `HeatmapPremium` (#20930) @bernardobelchior
- [charts-premium] Add keyboard navigation to range-bar (#21272) @alexfauquette
- [charts-premium] Extract `HeatmapSVGPlot` from `HeatmapPlot` component (#21015) @bernardobelchior
- [charts-premium] Fix `ChartDataProviderPremium` tests (#20868) @bernardobelchior
- [charts-premium] Fix links in comments for chart containers and data providers (#21105) @bernardobelchior

### Tree View

#### `@mui/x-tree-view@9.0.0-alpha.0`

_No changes._

#### `@mui/x-tree-view-pro@9.0.0-alpha.0` [![pro](https://mui.com/r/x-pro-svg)](https://mui.com/r/x-pro-svg-link 'Pro plan')

Same changes as in `@mui/x-tree-view@9.0.0-alpha.0`, plus:

- [RichTreeViewPro] Add support for virtualization (#20780) @flaviendelangle

### Codemod

#### `@mui/x-codemod@9.0.0-alpha.0`

- [codemod] Document and Clean the codemod utils (#21014) @alexfauquette

### Docs

- [docs] Add focus highlight in composition snipets (#20614) @alexfauquette
- [docs] Add simple candlestick chart demo (#20912) @bernardobelchior
- [docs] Fix Waterfall Chart documentation badge from Pro to Premium (#20888) @Copilot
- [docs] Fix broken links on Data Grid Editing sub-pages (#20911) @arminmeh
- [docs] Fix docs API for HeatmapPremium (#21137) @alexfauquette
- [docs] Fix horizontal overflow in heatmap docs (#20968) @bernardobelchior
- [docs] Move Range Bar Chart to existing charts (#21120) @bernardobelchior
- [docs] Prepare the scheduler doc for the alpha (#21268) @flaviendelangle
- [docs] Rewording of the heatmap item click (#20987) @alexfauquette
- [scheduler][docs] Create the Quickstart page (#20913) @flaviendelangle
- [charts][docs] Revise the Charts CSP doc (#20906) @mapache-salvaje
- [charts][docs] Revise the Charts Composition doc (#20032) @mapache-salvaje
- [charts][docs] Revise the Charts Hooks Overview doc (#20921) @mapache-salvaje
- [charts][docs] Revise the Charts Legend doc (#20821) @mapache-salvaje
- [charts][docs] Revise the Charts Localization doc (#20800) @mapache-salvaje
- [charts][docs] Revise the Charts Plugins doc (#20933) @mapache-salvaje
- [charts][docs] Revise the Charts Stacking doc (#20830) @mapache-salvaje
- [charts][docs] Revise the Charts Styling doc (#20835) @mapache-salvaje
- [charts][docs] Revise the Charts Toolbar doc (#20867) @mapache-salvaje
- [charts][docs] Revise the Charts Tooltip doc (#20869) @mapache-salvaje
- [charts][docs] Revise the Charts Zoom and Pan doc (#20893) @mapache-salvaje
- [DataGrid][docs] Add a recipe for handling long text cell (#20754) @siriwatknp
- [DataGrid][docs] Add high-level competitor comparison to Overview doc (DX-117) (#20870) @mapache-salvaje
- [DataGrid][docs] Remove Bundling section from quickstart (#21177) @MBilalShafi

### Core

- [code-infra] Add `MUI_TEST_ENV` global (#21187) @Janpot
- [code-infra] Fix `material-ui/disallow-react-api-in-server-components` (#20909) @JCQuintas
- [code-infra] Fix `renameImports` codemod not preserving comments (#20977) @JCQuintas
- [code-infra] Fix the label comparison to use lower case (#20934) @brijeshb42
- [code-infra] Github action to sync title and label (#20922) @brijeshb42
- [code-infra] Ignore scheduler demo with random data (#20982) @JCQuintas
- [code-infra] Improve `codemod` testing setup (#20981) @JCQuintas
- [code-infra] Only ignore renovate[bot] in changelog generation script (#21185) @bernardobelchior
- [code-infra] Prepare for v9 (#20860) @JCQuintas
- [code-infra] Set `rasterizehtml` version in pnpm catalog (#21175) @bernardobelchior
- [code-infra] Update codeowners (#20886) @JCQuintas
- [code-infra] V9 preparation (#20928) @JCQuintas
- [code-infra] eslint rule rename (#21172) @Janpot
- [code-infra][docs] V9 charts migration doc kickoff (#20973) @JCQuintas
- [docs-infra] Add Cookie Banner and Analytics Provider (#21228) @dav-is
- [docs-infra] Fix missing slots section on API page (#20915) @Janpot
- [docs-infra] Fix two broken links (#20914) @Janpot
- [docs-infra] Port demo changes (#20971) @Janpot
- [internal] Add information about codemods to AGENTS.md (#21011) @bernardobelchior
- [internal] Fix codemod versioning instructions in `AGENTS.md` (#21024) @bernardobelchior
- [internal] Fix missing generated props in master (#21142) @bernardobelchior
- [internal] Headless sorting plugin (#21089) @arminmeh
- [internal] Remove duplicate code (#20896) @oliviertassinari

### Miscellaneous

- Bump next to ^15.5.11 (#21171) @Copilot
- [core] Fix CI (#21223) @flaviendelangle
- [PoC] Headless data grid (#20645) @cherniavskii
