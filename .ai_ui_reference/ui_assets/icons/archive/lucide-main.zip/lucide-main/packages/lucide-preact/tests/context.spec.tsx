import { render } from '@testing-library/preact';
import { describe, expect, it } from 'vitest';
import { House, LucideProvider } from '../src/lucide-preact';

describe('Using LucideProvider', () => {
  it('should render the icon with LucideProvider', () => {
    const { container } = render(
      <LucideProvider
        size={48}
        color="red"
      >
        <House />
      </LucideProvider>,
    );

    expect(container.firstChild).toMatchSnapshot();
  });

  it('should render the icon with LucideProvider and custom strokeWidth', () => {
    const { container } = render(
      <LucideProvider
        size={48}
        color="red"
        strokeWidth={4}
      >
        <House />
      </LucideProvider>,
    );

    const IconComponent = container.firstElementChild;

    expect(IconComponent).toHaveAttribute('width', '48');
    expect(IconComponent).toHaveAttribute('height', '48');
    expect(IconComponent).toHaveAttribute('stroke', 'red');
    expect(IconComponent).toHaveAttribute('stroke-width', '4');
  });

  it('should render the icon with LucideProvider and custom absoluteStrokeWidth', () => {
    const { container } = render(
      <LucideProvider
        size={48}
        color="red"
        absoluteStrokeWidth
      >
        <House />
      </LucideProvider>,
    );

    const IconComponent = container.firstElementChild;

    expect(IconComponent).toHaveAttribute('stroke-width', '1');
  });

  it('should render the icon with LucideProvider and custom nonScalingStroke', () => {
    const { container } = render(
      <LucideProvider
        size={48}
        color="red"
        nonScalingStroke
      >
        <House />
      </LucideProvider>,
    );

    const IconComponent = container.firstElementChild;

    expect(IconComponent?.firstElementChild).toHaveAttribute('vector-effect', 'non-scaling-stroke');
  });

  it("should override the provider's global props when passing props to the icon", () => {
    const { container } = render(
      <LucideProvider
        size={48}
        color="red"
        strokeWidth={4}
      >
        <House
          size={24}
          color="blue"
          strokeWidth={2}
        />
      </LucideProvider>,
    );

    const IconComponent = container.firstElementChild;

    expect(IconComponent).toHaveAttribute('width', '24');
    expect(IconComponent).toHaveAttribute('height', '24');
    expect(IconComponent).toHaveAttribute('stroke', 'blue');
    expect(IconComponent).toHaveAttribute('stroke-width', '2');
  });

  it('should merge class names from LucideProvider and icon props', () => {
    const { container } = render(
      <LucideProvider class="provider-class">
        <House class="icon-class" />
      </LucideProvider>,
    );

    const IconComponent = container.firstElementChild;

    expect(IconComponent).toHaveAttribute(
      'class',
      'lucide lucide-house lucide-home provider-class icon-class',
    );
  });
});
