import React from 'react';
import {
  act,
  fireEvent,
  render,
  renderHook,
  screen,
  waitFor,
} from '@testing-library/react';

import { Controller } from '../../controller';
import type {
  Control,
  FieldErrors,
  UseFormRegister,
  UseFormReturn,
} from '../../types';
import { useController } from '../../useController';
import { useFieldArray } from '../../useFieldArray';
import { useForm } from '../../useForm';
import { useWatch } from '../../useWatch';
import isEmptyObject from '../../utils/isEmptyObject';
import noop from '../../utils/noop';

jest.useFakeTimers();

describe('reset', () => {
  it('should reset the form and re-render the form', async () => {
    const { result } = renderHook(() => useForm<{ test: string }>());

    result.current.register('test');
    result.current.setValue('test', 'data');

    expect(result.current.formState.isSubmitted).toBeFalsy();
    await act(async () => {
      await result.current.handleSubmit((data) => {
        expect(data).toEqual({
          test: 'data',
        });
      })({
        preventDefault: noop,
        persist: noop,
      } as React.SyntheticEvent);
    });

    expect(result.current.formState.isSubmitted).toBeTruthy();
    act(() => result.current.reset());
    expect(result.current.formState.isSubmitted).toBeFalsy();
  });

  it('should reset form value', () => {
    let methods: any;
    const App = () => {
      methods = useForm<{
        test: string;
      }>();
      return (
        <form>
          <input {...methods.register('test')} />
        </form>
      );
    };
    render(<App />);

    act(() =>
      methods.reset({
        test: 'test',
      }),
    );

    expect(methods.getValues()).toEqual({
      test: 'test',
    });
  });

  it('should reset the form with callback action', () => {
    const App = () => {
      const { register, reset } = useForm({
        defaultValues: {
          test: '',
        },
      });

      React.useEffect(() => {
        reset((formValues) => {
          return {
            ...formValues,
            test: 'test',
          };
        });
      }, [reset]);

      return (
        <form>
          <input {...register('test')} />
        </form>
      );
    };

    render(<App />);

    expect((screen.getByRole('textbox') as HTMLInputElement).value).toEqual(
      'test',
    );
  });

  it('should set array value of multiple checkbox inputs correctly', async () => {
    const App = () => {
      const { register } = useForm<{
        test: string[];
      }>({
        defaultValues: {
          test: ['1', '2'],
        },
      });

      return (
        <>
          <input type="checkbox" value={'1'} {...register('test')} />
          <input type="checkbox" value={'2'} {...register('test')} />
        </>
      );
    };

    render(<App />);

    screen
      .getAllByRole('checkbox')
      .forEach((checkbox) =>
        expect((checkbox as HTMLInputElement).checked).toBeTruthy(),
      );
  });

  it('should reset the form if ref is HTMLElement and parent element is not form', async () => {
    const mockReset = jest.spyOn(window.HTMLFormElement.prototype, 'reset');
    let methods: UseFormReturn<{
      test: string;
    }>;
    const App = () => {
      methods = useForm<{
        test: string;
      }>();
      return <input {...methods.register('test')} />;
    };
    render(<App />);

    act(() => methods.reset());

    expect(mockReset).not.toHaveBeenCalled();
  });

  it('should set default value if values is specified to first argument', async () => {
    const { result } = renderHook(() =>
      useForm<{
        test: string;
      }>(),
    );

    result.current.register('test');

    act(() => result.current.reset({ test: 'test' }));

    expect(result.current.control._defaultValues).toEqual({
      test: 'test',
    });
  });

  it('should reset unmountFieldsState value when shouldUnregister set to false', () => {
    const { result } = renderHook(() =>
      useForm<{
        test: string;
      }>(),
    );

    result.current.register('test');

    act(() => result.current.reset({ test: 'test' }));
  });

  it('should not reset unmountFieldsState value by default', () => {
    const { result } = renderHook(() =>
      useForm<{
        test: string;
      }>(),
    );

    result.current.register('test');

    act(() => result.current.reset({ test: 'test' }));
  });

  it('should keep dirtyFields in sync with isDirty when reset with keepValues', () => {
    const { result } = renderHook(() => {
      const form = useForm({ defaultValues: { test: 'test1' } });
      form.formState.isDirty;
      form.formState.dirtyFields;
      return form;
    });

    result.current.register('test');

    act(() => {
      result.current.setValue('test', 'test', { shouldDirty: true });
    });

    act(() => {
      result.current.reset(undefined, { keepValues: true });
    });

    expect(result.current.formState.isDirty).toBeTruthy();
    expect(result.current.formState.dirtyFields).toEqual({ test: true });
  });

  it('should not reset form values when keepValues is specified', () => {
    const App = () => {
      const { register, reset } = useForm();

      return (
        <>
          <input {...register('test')} />
          <button
            type={'button'}
            onClick={() =>
              reset(undefined, {
                keepValues: true,
              })
            }
          >
            reset
          </button>
        </>
      );
    };

    render(<App />);

    fireEvent.change(screen.getByRole('textbox'), {
      target: {
        value: 'test',
      },
    });

    fireEvent.click(screen.getByRole('button'));

    expect((screen.getByRole('textbox') as HTMLInputElement).value).toEqual(
      'test',
    );
  });

  it('should not reset form defaultValues when keepDefaultValues is specified', async () => {
    const App = () => {
      const {
        register,
        reset,
        formState: { isDirty },
      } = useForm({
        defaultValues: {
          test: 'test1',
        },
      });

      return (
        <>
          <input {...register('test')} />
          <p>{isDirty ? 'dirty' : ''}</p>
          <button
            type={'button'}
            onClick={() =>
              reset(undefined, {
                keepValues: true,
              })
            }
          >
            reset
          </button>
        </>
      );
    };

    render(<App />);

    fireEvent.change(screen.getByRole('textbox'), {
      target: {
        value: 'test',
      },
    });

    fireEvent.click(screen.getByRole('button'));

    expect((screen.getByRole('textbox') as HTMLInputElement).value).toEqual(
      'test',
    );

    fireEvent.change(screen.getByRole('textbox'), {
      target: {
        value: 'test2',
      },
    });

    expect(await screen.findByText('dirty')).toBeVisible();

    fireEvent.change(screen.getByRole('textbox'), {
      target: {
        value: 'test1',
      },
    });

    expect(screen.queryByText('dirty')).not.toBeInTheDocument();
  });

  it('should update dirty and dirtyFields when keepDefaultValues and updatedValues is provided', async () => {
    function App() {
      const {
        register,
        reset,
        formState: { isDirty, dirtyFields },
      } = useForm({
        defaultValues: {
          firstName: 'test',
        },
      });

      return (
        <form>
          <input {...register('firstName')} placeholder="First Name" />
          <p>{isDirty ? 'dirty' : 'pristine'}</p>
          <p>{JSON.stringify(dirtyFields)}</p>

          <button
            type="button"
            onClick={() => {
              reset(
                {
                  firstName: 'other',
                },
                {
                  keepDefaultValues: true,
                },
              );
            }}
          >
            test
          </button>
        </form>
      );
    }

    render(<App />);

    fireEvent.click(screen.getByRole('button'));

    expect(await screen.findByText('dirty')).toBeVisible();
    expect(screen.getByText('{"firstName":true}')).toBeVisible();
  });

  it('should not reset if keepStateOption is specified', async () => {
    let formState = {};
    const onSubmit = jest.fn();

    const App = () => {
      const {
        register,
        handleSubmit,
        reset,
        formState: { touchedFields, errors, isDirty },
      } = useForm<{ test: string }>({
        defaultValues: {
          test: '',
        },
      });

      formState = { touchedFields, errors, isDirty };

      return (
        <form onSubmit={handleSubmit(onSubmit)}>
          <input {...register('test', { required: true, minLength: 3 })} />
          <button>submit</button>
          <button
            onClick={() => {
              reset(
                { test: '' },
                {
                  keepErrors: true,
                  keepDirty: true,
                  keepIsSubmitted: true,
                  keepIsSubmitSuccessful: true,
                  keepTouched: true,
                  keepSubmitCount: true,
                },
              );
            }}
            type={'button'}
          >
            reset
          </button>
        </form>
      );
    };

    render(<App />);

    fireEvent.change(screen.getByRole('textbox'), {
      target: {
        value: 'test',
      },
    });

    fireEvent.blur(screen.getByRole('textbox'));

    fireEvent.click(screen.getByRole('button', { name: 'submit' }));

    await waitFor(() => expect(onSubmit).toHaveBeenCalled());
    await waitFor(() =>
      expect(formState).toEqual({
        errors: {},
        isDirty: true,
        touchedFields: {
          test: true,
        },
      }),
    );

    fireEvent.click(screen.getByRole('button', { name: 'reset' }));

    expect(formState).toEqual({
      errors: {},
      isDirty: true,
      touchedFields: {
        test: true,
      },
    });
  });

  it('should reset field array fine with empty value', async () => {
    let data: unknown;
    const App = () => {
      const { control, register, reset, handleSubmit } = useForm<{
        test: {
          firstName: string;
          lastName: string;
        }[];
      }>();
      const { fields } = useFieldArray({
        control,
        name: 'test',
      });

      return (
        <form
          onSubmit={handleSubmit((d) => {
            data = d;
          })}
        >
          {fields.map((field, index) => (
            <div key={field.id}>
              <input {...register(`test.${index}.firstName` as const)} />
              <Controller
                control={control}
                name={`test.${index}.lastName` as const}
                render={({ field }) => <input {...field} />}
              />
            </div>
          ))}

          <button>submit</button>

          <button type={'button'} onClick={() => reset()}>
            reset
          </button>
          <button
            type={'button'}
            onClick={() =>
              reset({
                test: [{ firstName: 'test', lastName: 'test' }],
              })
            }
          >
            reset with value
          </button>
        </form>
      );
    };

    render(<App />);

    const resetButton = screen.getByRole('button', { name: 'reset' });
    const submitButton = screen.getByRole('button', { name: 'submit' });

    fireEvent.click(resetButton);
    fireEvent.click(submitButton);

    await waitFor(() => expect(data).toEqual({}));

    fireEvent.click(screen.getByRole('button', { name: 'reset with value' }));
    fireEvent.click(submitButton);

    await waitFor(() =>
      expect(data).toEqual({
        test: [{ firstName: 'test', lastName: 'test' }],
      }),
    );
  });

  it('should return reset nested value', () => {
    const getValuesResult: unknown[] = [];

    function App() {
      const [, update] = React.useState({});
      const { register, reset, getValues } = useForm<{
        names: { name: string }[];
      }>({
        defaultValues: {
          names: [{ name: 'test' }],
        },
      });

      React.useEffect(() => {
        reset({ names: [{ name: 'Bill' }, { name: 'Luo' }] });
      }, [reset]);

      getValuesResult.push(getValues());

      return (
        <form>
          <input {...register('names.0.name')} placeholder="Name" />
          <button type={'button'} onClick={() => update({})}>
            update
          </button>
        </form>
      );
    }

    render(<App />);

    fireEvent.click(screen.getByRole('button'));

    expect(getValuesResult).toEqual([
      {
        names: [
          {
            name: 'test',
          },
        ],
      },
      {
        names: [
          {
            name: 'Bill',
          },
          {
            name: 'Luo',
          },
        ],
      },
      {
        names: [
          {
            name: 'Bill',
          },
          {
            name: 'Luo',
          },
        ],
      },
    ]);
  });

  it('should keep defaultValues after reset with shouldKeepDefaultValues', async () => {
    type FormValues = { test: string; test1: string };
    const ControlledInput = ({ control }: { control: Control<FormValues> }) => {
      const { field } = useController({
        name: 'test',
        control,
      });

      return <input {...field} />;
    };

    function App() {
      const { control, register, reset } = useForm<FormValues>({
        defaultValues: { test: 'test', test1: 'test1' },
      });
      const resetData = () => {
        reset(undefined, { keepDefaultValues: true });
      };

      return (
        <form>
          <ControlledInput control={control} />
          <input {...register('test1')} />
          <input type="button" onClick={resetData} value="Reset" />
        </form>
      );
    }

    render(<App />);

    fireEvent.change(screen.getAllByRole('textbox')[0], {
      target: { value: 'data' },
    });

    fireEvent.change(screen.getAllByRole('textbox')[1], {
      target: { value: 'data' },
    });

    fireEvent.click(screen.getByRole('button'));

    expect(
      (screen.getAllByRole('textbox')[0] as HTMLInputElement).value,
    ).toEqual('test');
    expect(
      (screen.getAllByRole('textbox')[1] as HTMLInputElement).value,
    ).toEqual('test1');
  });

  describe('when reset optional props set to keepDirtyValues', () => {
    describe('with uncontrolled components', () => {
      let updatedDirtyFields: Record<string, boolean> = {};
      let updatedDirty = false;
      let submittedValue: unknown = {};

      function App() {
        const [showButton, setShowButton] = React.useState(false);
        const {
          reset,
          register,
          handleSubmit,
          formState: { dirtyFields, isDirty },
        } = useForm();

        updatedDirtyFields = dirtyFields;
        updatedDirty = isDirty;

        React.useEffect(() => {
          setTimeout(() => {
            reset(
              {
                firstName: 'bill',
                lastName: 'luo',
              },
              { keepDirtyValues: true },
            );
            setShowButton(true);
          }, 500);
        }, [reset]);

        return (
          <form
            onSubmit={handleSubmit((data) => {
              submittedValue = data;
            })}
          >
            <input {...register('firstName')} placeholder="First Name" />
            <input {...register('lastName')} placeholder="Last Name" />

            {showButton && (
              <button
                type="button"
                onClick={() => {
                  reset();
                }}
              >
                reset
              </button>
            )}
            <button>submit</button>
          </form>
        );
      }

      it('should only update new reset values', async () => {
        render(<App />);

        await waitFor(() =>
          expect(
            (screen.getByPlaceholderText('First Name') as HTMLInputElement)
              .value,
          ).toEqual('bill'),
        );

        fireEvent.click(screen.getByRole('button', { name: 'reset' }));

        expect(updatedDirtyFields).toEqual({});
        expect(updatedDirty).toBeFalsy();

        expect(
          (screen.getByPlaceholderText('First Name') as HTMLInputElement).value,
        ).toEqual('bill');

        expect(updatedDirtyFields).toEqual({});
        expect(updatedDirty).toBeFalsy();

        fireEvent.click(screen.getByRole('button', { name: 'submit' }));

        await waitFor(() =>
          expect(submittedValue).toEqual({
            firstName: 'bill',
            lastName: 'luo',
          }),
        );
      });

      it('should treat previously-undirty fields as dirty when keepDefaultValues is set', async () => {
        let updatedDirtyFields: Record<string, boolean> = {};
        let updatedDirty = false;

        function App() {
          const {
            reset,
            register,
            handleSubmit,
            formState: { dirtyFields, isDirty },
          } = useForm({ defaultValues: { firstName: '', lastName: '' } });

          function resetKeepDefaults() {
            reset(
              {
                firstName: 'bill',
                lastName: 'luo',
              },
              {
                keepDefaultValues: true,
                keepDirtyValues: true,
              },
            );
          }

          updatedDirtyFields = dirtyFields;
          updatedDirty = isDirty;

          return (
            <form
              onSubmit={handleSubmit((data) => {
                submittedValue = data;
              })}
            >
              <input {...register('firstName')} placeholder="First Name" />
              <input {...register('lastName')} placeholder="Last Name" />

              <button
                type="button"
                onClick={() => {
                  resetKeepDefaults();
                }}
              >
                reset keep defaults
              </button>
              <button>submit</button>
            </form>
          );
        }

        render(<App />);

        fireEvent.click(
          screen.getByRole('button', { name: 'reset keep defaults' }),
        );

        await waitFor(() =>
          expect(
            (screen.getByPlaceholderText('Last Name') as HTMLInputElement)
              .value,
          ).toEqual('luo'),
        );

        expect(
          (screen.getByPlaceholderText('First Name') as HTMLInputElement).value,
        ).toEqual('bill');

        // Both fields were updated, the defaults were kept, so both should be dirty
        expect(updatedDirtyFields).toEqual({
          firstName: true,
          lastName: true,
        });

        expect(updatedDirty).toBeTruthy();
      });
    });

    describe('with controlled components', () => {
      let updatedDirtyFields: Record<string, boolean> = {};
      let updatedDirty = false;
      let submittedValue: unknown = {};

      function App() {
        const [showButton, setShowButton] = React.useState(false);
        const {
          reset,
          control,
          handleSubmit,
          formState: { dirtyFields, isDirty },
        } = useForm({
          defaultValues: {
            firstName: '',
            lastName: '',
          },
        });

        updatedDirtyFields = dirtyFields;
        updatedDirty = isDirty;

        React.useEffect(() => {
          setTimeout(() => {
            reset(
              {
                firstName: 'bill',
                lastName: 'luo',
              },
              { keepDirtyValues: true },
            );
            setShowButton(true);
          }, 500);
        }, [reset]);

        return (
          <form
            onSubmit={handleSubmit((data) => {
              submittedValue = data;
            })}
          >
            <Controller
              control={control}
              render={({ field }) => {
                return <input {...field} placeholder="First Name" />;
              }}
              name={'firstName'}
            />
            <Controller
              control={control}
              render={({ field }) => {
                return <input {...field} placeholder="Last Name" />;
              }}
              name={'lastName'}
            />

            {showButton && (
              <button
                type="button"
                onClick={() => {
                  reset();
                }}
              >
                reset
              </button>
            )}

            <button>submit</button>
          </form>
        );
      }

      it('should only update new reset values', async () => {
        render(<App />);

        await waitFor(() =>
          expect(
            (screen.getByPlaceholderText('First Name') as HTMLInputElement)
              .value,
          ).toEqual('bill'),
        );

        fireEvent.click(screen.getByRole('button', { name: 'reset' }));

        expect(updatedDirtyFields).toEqual({});
        expect(updatedDirty).toBeFalsy();

        expect(
          (screen.getByPlaceholderText('First Name') as HTMLInputElement).value,
        ).toEqual('bill');

        expect(updatedDirtyFields).toEqual({});
        expect(updatedDirty).toBeFalsy();

        fireEvent.click(screen.getByRole('button', { name: 'submit' }));

        await waitFor(() =>
          expect(submittedValue).toEqual({
            firstName: 'bill',
            lastName: 'luo',
          }),
        );
      });

      it('should only update none dirty fields and keep other values updated', async () => {
        render(<App />);

        fireEvent.change(screen.getByPlaceholderText('First Name'), {
          target: {
            value: 'test',
          },
        });

        await waitFor(() =>
          expect(
            (screen.getByPlaceholderText('Last Name') as HTMLInputElement)
              .value,
          ).toEqual('luo'),
        );

        expect(updatedDirtyFields).toEqual({
          firstName: true,
        });
        expect(updatedDirty).toBeTruthy();

        fireEvent.click(screen.getByRole('button', { name: 'submit' }));

        await waitFor(() =>
          expect(submittedValue).toEqual({
            firstName: 'test',
            lastName: 'luo',
          }),
        );

        fireEvent.click(screen.getByRole('button', { name: 'reset' }));

        expect(
          (screen.getByPlaceholderText('First Name') as HTMLInputElement).value,
        ).toEqual('bill');

        expect(updatedDirtyFields).toEqual({});
        expect(updatedDirty).toBeFalsy();

        fireEvent.click(screen.getByRole('button', { name: 'submit' }));

        await waitFor(() =>
          expect(submittedValue).toEqual({
            firstName: 'bill',
            lastName: 'luo',
          }),
        );
      });
    });

    it('should merge nested object at leaf granularity, keeping only the dirty leaf and updating a clean sibling that is not bound to an input (#13627)', async () => {
      type FormValues = {
        user: { name: string; email: string };
      };

      let submittedValue: FormValues | undefined = undefined;
      let doReset: (() => void) | undefined;

      function App() {
        const { register, handleSubmit, reset, getValues } =
          useForm<FormValues>({
            values: {
              user: { name: 'bill', email: 'bill@old.com' },
            },
            resetOptions: { keepDirtyValues: true },
          });

        doReset = () =>
          reset(
            { user: { name: getValues('user.name'), email: 'bill@new.com' } },
            { keepDirtyValues: true },
          );

        return (
          <form
            onSubmit={handleSubmit((data) => {
              submittedValue = data;
            })}
          >
            <input {...register('user.name')} placeholder="Name" />
            <button>submit</button>
          </form>
        );
      }

      render(<App />);

      fireEvent.change(screen.getByPlaceholderText('Name'), {
        target: { value: 'edited-name' },
      });

      act(() => doReset!());

      expect(
        (screen.getByPlaceholderText('Name') as HTMLInputElement).value,
      ).toEqual('edited-name');

      fireEvent.click(screen.getByRole('button', { name: 'submit' }));

      await waitFor(() =>
        expect(submittedValue).toEqual({
          user: { name: 'edited-name', email: 'bill@new.com' },
        }),
      );
    });
  });

  it('should allow resetting unmounted field array', () => {
    type FormValues = {
      test: { name: string }[];
    };

    const FieldArray = ({
      control,
      register,
    }: {
      control: Control<FormValues>;
      register: UseFormRegister<FormValues>;
    }) => {
      const { fields, append } = useFieldArray({
        control,
        name: 'test',
      });

      return (
        <div>
          {fields.map((field, index) => {
            return (
              <input
                key={field.id}
                {...register(`test.${index}.name` as const)}
              />
            );
          })}
          <button
            onClick={() => {
              append({ name: '' });
            }}
          >
            append
          </button>
        </div>
      );
    };

    const App = () => {
      const [show, setShow] = React.useState(true);
      const { control, register, reset } = useForm<FormValues>();

      return (
        <div>
          {show && <FieldArray control={control} register={register} />}
          <button
            onClick={() => {
              setShow(!show);
            }}
          >
            toggle
          </button>
          <button
            onClick={() => {
              reset({
                test: [{ name: 'test' }],
              });
            }}
          >
            reset
          </button>
        </div>
      );
    };

    render(<App />);

    fireEvent.click(screen.getByRole('button', { name: 'append' }));
    fireEvent.click(screen.getByRole('button', { name: 'append' }));

    expect(screen.getAllByRole('textbox').length).toEqual(2);

    fireEvent.click(screen.getByRole('button', { name: 'toggle' }));
    fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    fireEvent.click(screen.getByRole('button', { name: 'toggle' }));

    expect(screen.getAllByRole('textbox').length).toEqual(1);
  });

  it('should only return register input when reset is invoked with shouldUnregister:true', async () => {
    let submittedData = {};

    const App = () => {
      const { reset, handleSubmit } = useForm({
        defaultValues: {
          test: 'bill',
        },
        shouldUnregister: true,
      });

      return (
        <form
          onSubmit={handleSubmit((data) => {
            submittedData = data;
          })}
        >
          <button>submit</button>
          <button
            type={'button'}
            onClick={() => {
              reset({
                test: '1234',
              });
            }}
          >
            reset
          </button>
        </form>
      );
    };

    render(<App />);

    fireEvent.click(screen.getByRole('button', { name: 'submit' }));

    expect(submittedData).toEqual({});

    fireEvent.click(screen.getByRole('button', { name: 'reset' }));

    fireEvent.click(screen.getByRole('button', { name: 'submit' }));

    expect(submittedData).toEqual({});
  });

  it('should update controlled input correctly with shouldUnregister set to true', () => {
    function App() {
      const { register, reset, control } = useForm({
        defaultValues: { uncontrolled: '', control: '' },
        shouldUnregister: true,
      });

      return (
        <form>
          <input {...register('uncontrolled')} />
          <Controller
            render={({ field }) => (
              <input
                ref={field.ref}
                value={field.value}
                onChange={field.onChange}
              />
            )}
            name="control"
            control={control}
          />

          <button
            type="button"
            onClick={() => {
              reset({ uncontrolled: 'uncontrolled', control: 'control' });
            }}
          >
            reset
          </button>
        </form>
      );
    }

    render(<App />);

    fireEvent.click(screen.getByRole('button'));

    expect(
      (screen.getAllByRole('textbox')[0] as HTMLInputElement).value,
    ).toEqual('uncontrolled');
    expect(
      (screen.getAllByRole('textbox')[1] as HTMLInputElement).value,
    ).toEqual('control');
  });

  it('should keep reset value for conditionally mounted controlled fields with shouldUnregister', async () => {
    let submittedData = {};

    const App = () => {
      const { control, watch, handleSubmit, reset } = useForm<{
        name: string;
        age: string;
      }>({
        shouldUnregister: true,
        defaultValues: {
          name: '',
        },
      });
      const showAge = !!watch('name');

      return (
        <form
          onSubmit={handleSubmit((data) => {
            submittedData = data;
          })}
        >
          <Controller
            name="name"
            control={control}
            render={({ field: { onChange, name, ref, value } }) => (
              <input
                ref={ref}
                name={name}
                value={value || ''}
                onChange={onChange}
              />
            )}
          />
          {showAge && (
            <Controller
              name="age"
              control={control}
              render={({ field: { onChange, name, ref, value } }) => (
                <input
                  ref={ref}
                  name={name}
                  value={value || ''}
                  onChange={onChange}
                />
              )}
            />
          )}
          <button
            type="button"
            onClick={() => {
              reset({ name: 'name', age: '3' });
            }}
          >
            reset with values
          </button>
          <button>submit</button>
        </form>
      );
    };

    render(<App />);

    fireEvent.click(screen.getByRole('button', { name: 'reset with values' }));

    await waitFor(() =>
      expect(
        (screen.getAllByRole('textbox')[1] as HTMLInputElement).value,
      ).toBe('3'),
    );

    fireEvent.click(screen.getByRole('button', { name: 'submit' }));

    await waitFor(() =>
      expect(submittedData).toEqual({ name: 'name', age: '3' }),
    );
  });

  it('should keep input values when keepValues is set to true', () => {
    function App() {
      const { register, handleSubmit, reset } = useForm();
      const [show, setShow] = React.useState(true);

      return (
        <form onSubmit={handleSubmit(noop)}>
          <input {...register('firstName')} placeholder="First Name" />
          {show && <input {...register('lastName')} placeholder="Last Name" />}
          <button
            type="button"
            onClick={() => {
              reset({}, { keepValues: true });
            }}
          >
            reset
          </button>
          <button
            type="button"
            onClick={() => {
              setShow(!show);
            }}
          >
            toggle
          </button>
          <input type="submit" />
        </form>
      );
    }

    render(<App />);

    fireEvent.change(screen.getAllByRole('textbox')[0], {
      target: { value: 'test' },
    });
    fireEvent.change(screen.getAllByRole('textbox')[1], {
      target: { value: 'test' },
    });
    fireEvent.click(screen.getByRole('button', { name: 'toggle' }));
    fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    fireEvent.click(screen.getByRole('button', { name: 'toggle' }));

    expect(
      (screen.getAllByRole('textbox')[1] as HTMLInputElement).value,
    ).toEqual('test');
  });

  it('should not update isMounted when isValid is subscribed', async () => {
    const mounted: unknown[] = [];

    const App = () => {
      const { control, reset } = useForm();

      mounted.push(control._state.mount);

      React.useEffect(() => {
        reset({});
      }, [reset]);

      return <form />;
    };

    render(<App />);

    expect(mounted).toEqual([false, true]);
  });

  it('should update isMounted when isValid is subscribed', async () => {
    const mounted: unknown[] = [];
    let tempControl: Control = {} as Control;

    const App = () => {
      const {
        control,
        reset,
        formState: { isValid },
      } = useForm();

      mounted.push(control._state.mount);
      tempControl = control;

      React.useEffect(() => {
        reset({});
      }, [reset]);

      return (
        <form>
          <p>{isValid ? 'true' : 'false'}</p>
        </form>
      );
    };

    render(<App />);

    expect(await screen.findByText('false')).toBeVisible();

    // With fix for #13088, mount is set based on conditions including !isEmptyObject(_formValues)
    // When reset({}) is called, _formValues becomes {}, so mount becomes true
    expect(mounted).toEqual([false, false]);

    expect(tempControl._state.mount).toBeTruthy();
  });

  it('should reset values but keep defaultValues', async () => {
    const App = () => {
      const { register, control, reset } = useForm({
        defaultValues: {
          test: 'test',
          test1: 'test1',
        },
      });

      return (
        <>
          <input {...register('test')} />
          <Controller
            control={control}
            render={({ field }) => <input {...field} />}
            name={'test1'}
          />
          <button
            onClick={() => {
              reset(
                {
                  test: 'changed1',
                  test1: 'changed2',
                },
                { keepDefaultValues: true },
              );
            }}
          >
            reset
          </button>
          <p>{JSON.stringify(control._defaultValues)}</p>
        </>
      );
    };

    render(<App />);

    fireEvent.click(screen.getByRole('button'));

    expect(
      await screen.findByText('{"test":"test","test1":"test1"}'),
    ).toBeVisible();
    expect(
      (screen.getAllByRole('textbox')[0] as HTMLInputElement).value,
    ).toEqual('changed1');
    expect(
      (screen.getAllByRole('textbox')[1] as HTMLInputElement).value,
    ).toEqual('changed2');
  });

  it('should reset field array async', () => {
    let tempFields: unknown[] = [];

    function App() {
      const { control, reset } = useForm<{
        names: {
          test: string;
        }[];
      }>({
        defaultValues: {
          names: [],
        },
      });
      const { fields, append } = useFieldArray({
        control,
        name: 'names',
      });

      tempFields = fields;

      return (
        <form>
          <button
            type="button"
            onClick={() => {
              setTimeout(() => {
                reset();
              }, 100);
            }}
          >
            reset
          </button>
          <button
            type="button"
            onClick={() =>
              append({
                test: '1',
              })
            }
          >
            append
          </button>
          <ul>
            {fields.map((item, index) => (
              <Controller
                key={item.id}
                render={({ field }) => <input {...field} />}
                name={`names.${index}.test`}
                control={control}
              />
            ))}
          </ul>
        </form>
      );
    }

    render(<App />);

    fireEvent.click(screen.getByRole('button', { name: 'append' }));
    fireEvent.click(screen.getByRole('button', { name: 'append' }));

    fireEvent.click(screen.getByRole('button', { name: 'reset' }));

    act(() => {
      jest.advanceTimersByTime(100);
    });

    expect(tempFields).toEqual([]);
  });

  it('should reset the form after submitted', async () => {
    function App() {
      const {
        register,
        control,
        handleSubmit,
        reset,
        formState: { isDirty, dirtyFields },
      } = useForm({
        defaultValues: {
          something: 'anything',
          test: [{ firstName: 'Bill', lastName: 'Luo' }],
        },
      });
      const { fields } = useFieldArray({
        control,
        name: 'test',
      });

      return (
        <form
          onSubmit={handleSubmit((data) => {
            reset({ ...data });
          })}
        >
          <p>is dirty? {isDirty ? 'yes' : 'no'}</p>
          <p>{JSON.stringify(dirtyFields)}</p>
          <input {...register('something')} />
          <ul>
            {fields.map((item, index) => {
              return (
                <li key={item.id}>
                  <input
                    defaultValue={`${item.firstName}`}
                    {...register(`test.${index}.firstName`)}
                  />

                  <Controller
                    render={({ field }) => <input {...field} />}
                    name={`test.${index}.lastName`}
                    control={control}
                    defaultValue={item.lastName}
                  />
                </li>
              );
            })}
          </ul>

          <button>Submit</button>
        </form>
      );
    }

    render(<App />);

    fireEvent.change(screen.getAllByRole('textbox')[0], {
      target: { value: '1' },
    });
    fireEvent.change(screen.getAllByRole('textbox')[1], {
      target: { value: '2' },
    });
    fireEvent.change(screen.getAllByRole('textbox')[2], {
      target: { value: '3' },
    });

    expect(screen.getByText(/yes/i)).toBeVisible();
    expect(
      screen.getByText(
        `{"something":true,"test":[{"firstName":true,"lastName":true}]}`,
      ),
    ).toBeVisible();

    fireEvent.click(screen.getByRole('button'));

    expect(await screen.findByText(/no/i)).toBeVisible();

    expect(
      (screen.getAllByRole('textbox')[0] as HTMLInputElement).value,
    ).toEqual('1');
    expect(
      (screen.getAllByRole('textbox')[1] as HTMLInputElement).value,
    ).toEqual('2');
    expect(
      (screen.getAllByRole('textbox')[2] as HTMLInputElement).value,
    ).toEqual('3');
  });

  it('should keep isSubmitted and isSubmitSuccessful value when flags are set', async () => {
    const { result } = renderHook(() => useForm<{ test: string }>());

    expect(result.current.formState.isSubmitted).toBeFalsy();
    expect(result.current.formState.isSubmitSuccessful).toBeFalsy();

    await act(() =>
      result.current.reset(undefined, {
        keepIsSubmitted: true,
        keepIsSubmitSuccessful: true,
      }),
    );
    expect(result.current.formState.isSubmitted).toBeFalsy();
    expect(result.current.formState.isSubmitSuccessful).toBeFalsy();

    result.current.register('test');
    result.current.setValue('test', 'data');

    await act(async () => {
      await result.current.handleSubmit((data) => {
        expect(data).toEqual({
          test: 'data',
        });
      })({
        preventDefault: noop,
        persist: noop,
      } as React.SyntheticEvent);
    });

    expect(result.current.formState.isSubmitted).toBeTruthy();
    expect(result.current.formState.isSubmitSuccessful).toBeTruthy();

    act(() =>
      result.current.reset(undefined, {
        keepIsSubmitted: true,
        keepIsSubmitSuccessful: true,
      }),
    );

    expect(result.current.formState.isSubmitted).toBeTruthy();
    expect(result.current.formState.isSubmitSuccessful).toBeTruthy();
  });

  it('should keep track on updated defaultValues', async () => {
    function App() {
      const {
        handleSubmit,
        reset,
        formState: { defaultValues },
      } = useForm({
        defaultValues: { firstName: 'Bill', lastName: 'Luo' },
      });

      return (
        <form
          onSubmit={handleSubmit(() => {
            reset({ firstName: 'Bill1', lastName: 'Luo1' });
          })}
        >
          <button>Submit</button>
          <p>{defaultValues?.firstName}</p>
          <p>{defaultValues?.lastName}</p>
        </form>
      );
    }

    render(<App />);

    fireEvent.click(screen.getByRole('button'));

    await waitFor(() => {
      expect(screen.getByText('Bill1')).toBeVisible();
      expect(screen.getByText('Luo1')).toBeVisible();
    });
  });

  it('should reset to empty values in useWatch and watch when calling reset with empty object', async () => {
    const defaultValues = {
      something: 'anything',
    };

    function App() {
      const { control, reset, register, watch } = useForm({
        defaultValues,
      });
      const watchValue = watch('something');
      const useWatchValue = useWatch({
        control,
        name: 'something',
      });

      return (
        <form>
          <input {...register('something')} />
          <button
            type="button"
            onClick={() => {
              reset({});
            }}
          >
            reset
          </button>
          <p>watch: {watchValue}</p>
          <p>useWatch: {useWatchValue}</p>
        </form>
      );
    }

    render(<App />);

    fireEvent.change(screen.getByRole('textbox'), {
      target: { value: '1' },
    });

    expect(screen.getByText('watch: 1')).toBeVisible();
    expect(screen.getByText('useWatch: 1')).toBeVisible();

    fireEvent.click(screen.getByRole('button'));

    expect(screen.getByText('watch:')).toBeVisible();
    expect(screen.getByText('useWatch:')).toBeVisible();
  });

  it('should use values passed to reset({}) as new defaultValues on submit', async () => {
    let submittedData: unknown;

    function App() {
      const { reset, handleSubmit } = useForm({
        defaultValues: {
          name: {
            firstName: 'John',
            lastName: 'Doe',
          },
        },
      });

      return (
        <form
          onSubmit={handleSubmit((data) => {
            submittedData = data;
          })}
        >
          <button type="submit">submit</button>
          <button
            type="button"
            onClick={() => {
              reset({});
            }}
          >
            reset
          </button>
        </form>
      );
    }

    render(<App />);

    fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    fireEvent.click(screen.getByRole('button', { name: 'submit' }));

    await waitFor(() => expect(submittedData).toEqual({}));
  });

  it('should set _formValues to empty object after reset({})', () => {
    const { result } = renderHook(() =>
      useForm({
        defaultValues: {
          name: {
            firstName: 'John',
            lastName: 'Doe',
          },
        },
      }),
    );

    act(() => result.current.reset({}));

    expect(result.current.getValues()).toEqual({});
    expect(result.current.control._defaultValues).toEqual({});
  });

  it('should keep mounted value after reset with keep dirty values', async () => {
    function App() {
      const {
        getValues,
        reset,
        register,
        formState: { isValid },
      } = useForm({
        mode: 'onChange',
      });

      return (
        <form>
          <input
            {...register('value', { required: true })}
            defaultValue="Any default value!"
          />
          <p>{getValues().test}</p>
          <p>isValid = {isValid ? 'true' : 'false'}</p>
          <button
            type="button"
            onClick={() => reset({ test: '34' }, { keepDirtyValues: true })}
          >
            reset
          </button>
        </form>
      );
    }

    render(<App />);

    expect(await screen.findByText('isValid = true')).toBeVisible();

    fireEvent.click(screen.getByRole('button'));

    await waitFor(() => {
      screen.getByText('34');
    });
  });

  it('should keep dirty array value after reset with keepDirtyValues', async () => {
    function App() {
      const {
        getValues,
        reset,
        setValue,
        formState: { isDirty },
      } = useForm<{
        array: string[];
      }>({
        mode: 'onChange',
        defaultValues: {
          array: [],
        },
      });

      return (
        <form>
          <input defaultValue="users#0" />
          <p>{`users#${getValues().array.length}`}</p>
          <p>isDirty = {isDirty ? 'true' : 'false'}</p>
          <button
            data-testid="dirtyButton"
            type="button"
            onClick={() => setValue('array', ['1'], { shouldDirty: true })}
          >
            dirty
          </button>
          <button
            data-testid="resetButton"
            type="button"
            onClick={() => reset({ array: [] }, { keepDirtyValues: true })}
          >
            reset
          </button>
        </form>
      );
    }

    render(<App />);

    expect(await screen.findByText('isDirty = false')).toBeVisible();
    await waitFor(() => {
      screen.getByText('users#0');
    });

    fireEvent.click(screen.getByTestId('dirtyButton'));
    expect(await screen.findByText('isDirty = true')).toBeVisible();
    await waitFor(() => {
      screen.getByText('users#1');
    });

    fireEvent.click(screen.getByTestId('resetButton'));

    await waitFor(() => {
      screen.getByText('users#1');
    });
  });

  it('should keep dirty fields for dynamic controller name when keepDirty and keepDirtyValues are true', async () => {
    type FormValues = {
      name_es: string;
      name_en: string;
    };

    const defaultValues: FormValues = {
      name_es: 'Espanol',
      name_en: 'English',
    };

    function App() {
      const {
        control,
        reset,
        formState: { dirtyFields },
      } = useForm<FormValues>({
        defaultValues,
      });
      const [language, setLanguage] = React.useState<'es' | 'en'>('en');

      return (
        <form>
          <Controller
            control={control}
            name={`name_${language}`}
            render={({ field }) => <input {...field} />}
          />
          <button
            type="button"
            onClick={() => {
              setLanguage((prev) => (prev === 'en' ? 'es' : 'en'));
              reset(defaultValues, { keepDirty: true, keepDirtyValues: true });
            }}
          >
            toggle
          </button>
          <p data-testid="dirtyFields">{JSON.stringify(dirtyFields)}</p>
        </form>
      );
    }

    render(<App />);

    fireEvent.change(screen.getByRole('textbox'), {
      target: {
        value: 'Test 1',
      },
    });

    expect(screen.getByTestId('dirtyFields').textContent).toBe(
      '{"name_en":true}',
    );

    fireEvent.click(screen.getByRole('button', { name: 'toggle' }));

    await waitFor(() =>
      expect(screen.getByTestId('dirtyFields').textContent).toBe(
        '{"name_en":true}',
      ),
    );
  });

  it('should not mutate data outside of library', () => {
    const defaultValues = {
      test: 'ok',
    };

    const App = () => {
      const { register, reset, resetField } = useForm();

      return (
        <form>
          <input {...register('test')} />
          <button type="button" onClick={() => reset(defaultValues)}>
            reset
          </button>
          <button
            type="button"
            onClick={() => resetField('test', { defaultValue: 'error' })}
          >
            resetField
          </button>
        </form>
      );
    };

    render(<App />);

    fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    fireEvent.click(screen.getByRole('button', { name: 'resetField' }));

    expect(defaultValues.test).toBe('ok');
  });

  it('should not reset value to undefined with onSubmit data', async () => {
    const onSubmit = jest.fn();
    const App = () => {
      const { handleSubmit, reset, register } = useForm({
        defaultValues: {
          test: 'test' as string | undefined,
        },
      });

      return (
        <form onSubmit={handleSubmit((data) => onSubmit(data))}>
          <button
            onClick={() => {
              reset(
                {
                  test: undefined,
                },
                {
                  keepDefaultValues: true,
                },
              );
            }}
          >
            reset
          </button>
          <input {...register('test')} />
          <button>submit</button>
        </form>
      );
    };

    render(<App />);

    fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    fireEvent.click(screen.getByRole('button', { name: 'submit' }));

    await waitFor(() =>
      expect(onSubmit).toHaveBeenCalledWith({
        test: 'test',
      }),
    );
  });

  it('should clear validation errors after reset to prevent false errors on subsequent submissions (Next.js 16 Server Actions fix)', async () => {
    const resolver = jest.fn(
      async (data: { name: string; description?: string }) => {
        const errors: FieldErrors<{ name: string; description?: string }> = {};

        if (!data.name || data.name.length < 2) {
          errors.name = {
            type: 'min',
            message: 'Name must be at least 2 characters',
          };
        }

        if (data.description && data.description.length < 5) {
          errors.description = {
            type: 'min',
            message: 'Description must be at least 5 characters',
          };
        }

        return {
          values: isEmptyObject(errors) ? data : {},
          errors,
        };
      },
    );

    const onSubmit = jest.fn();
    let methods: UseFormReturn<{ name: string; description?: string }>;

    const App = () => {
      methods = useForm<{ name: string; description?: string }>({
        resolver,
        defaultValues: {
          name: '',
          description: '',
        },
      });

      return (
        <form
          onSubmit={methods.handleSubmit(async (data) => {
            // Simulate Next.js Server Action
            await new Promise((resolve) => setTimeout(resolve, 100));
            onSubmit(data);
            // Call reset after successful submission
            methods.reset();
          })}
        >
          <input {...methods.register('name')} />
          {methods.formState.errors.name && (
            <p>{methods.formState.errors.name.message}</p>
          )}
          <input {...methods.register('description')} />
          {methods.formState.errors.description && (
            <p>{methods.formState.errors.description.message}</p>
          )}
          <button type="submit">Submit</button>
        </form>
      );
    };

    render(<App />);

    // First submission with valid data
    fireEvent.change(screen.getAllByRole('textbox')[0], {
      target: { value: 'validname' },
    });
    fireEvent.change(screen.getAllByRole('textbox')[1], {
      target: { value: 'validdescription' },
    });

    fireEvent.click(screen.getByRole('button', { name: 'Submit' }));

    await waitFor(() => expect(onSubmit).toHaveBeenCalledTimes(1));
    expect(onSubmit).toHaveBeenCalledWith({
      name: 'validname',
      description: 'validdescription',
    });

    // Wait for reset to complete
    await waitFor(() => {
      expect(methods.formState.errors).toEqual({});
    });

    // Second submission with valid data after reset
    // This should not show validation errors
    fireEvent.change(screen.getAllByRole('textbox')[0], {
      target: { value: 'newname' },
    });
    fireEvent.change(screen.getAllByRole('textbox')[1], {
      target: { value: 'newdescription' },
    });

    // Clear previous calls
    onSubmit.mockClear();
    resolver.mockClear();

    fireEvent.click(screen.getByRole('button', { name: 'Submit' }));

    await waitFor(() => expect(onSubmit).toHaveBeenCalledTimes(1));
    expect(onSubmit).toHaveBeenCalledWith({
      name: 'newname',
      description: 'newdescription',
    });

    // Verify no error messages are displayed
    expect(
      screen.queryByText('Name must be at least 2 characters'),
    ).not.toBeInTheDocument();
    expect(
      screen.queryByText('Description must be at least 5 characters'),
    ).not.toBeInTheDocument();
  });

  it('should keep isValid value when reset is called with keepIsValid option', async () => {
    let formState: { isValid: boolean } = { isValid: false };

    const App = () => {
      const {
        register,
        reset,
        formState: { isValid },
      } = useForm({
        defaultValues: { name: 'Mike' },
        mode: 'onChange',
      });

      formState = { isValid };

      return (
        <div>
          <p>
            <input {...register('name', { required: true })} />
          </p>
          <button
            onClick={() => {
              reset({ name: '' }, { keepIsValid: true });
            }}
          >
            reset with keepIsValid
          </button>
          <button
            onClick={() => {
              reset({ name: '' });
            }}
          >
            reset without keepIsValid
          </button>
          <p>is valid: {isValid ? 'true' : 'false'}</p>
        </div>
      );
    };

    render(<App />);

    const input = screen.getByRole('textbox') as HTMLInputElement;

    await waitFor(() => {
      expect(screen.getByText('is valid: true')).toBeInTheDocument();
    });

    expect(formState).toEqual({ isValid: true });
    expect(input.value).toBe('Mike');

    // Reset with keepIsValid
    await act(async () => {
      fireEvent.click(
        screen.getByRole('button', { name: 'reset with keepIsValid' }),
      );
    });

    await waitFor(() => {
      expect(input.value).toBe('');
    });

    await act(async () => {
      jest.advanceTimersByTime(1000);
    });

    expect(screen.getByText('is valid: true')).toBeInTheDocument();
    expect(formState).toEqual({ isValid: true });

    // Reset without keepIsValid
    await act(async () => {
      fireEvent.click(
        screen.getByRole('button', { name: 'reset without keepIsValid' }),
      );
    });

    await waitFor(() => {
      expect(input.value).toBe('');
    });

    await act(async () => {
      jest.advanceTimersByTime(1000);
    });

    // Verify isValid value is false after reset without keepIsValid
    expect(screen.getByText('is valid: false')).toBeInTheDocument();
    expect(formState).toEqual({ isValid: false });
  });

  it('should keep isValid value when form has resetOptions.keepIsValid configured', async () => {
    let formState: { isValid: boolean } = { isValid: false };

    const App = () => {
      const {
        register,
        reset,
        formState: { isValid },
      } = useForm({
        defaultValues: { name: 'Mike' },
        mode: 'onChange',
        resetOptions: {
          keepIsValid: true,
        },
      });

      formState = { isValid };

      return (
        <div>
          <p>
            <input {...register('name', { required: true })} />
          </p>
          <button
            onClick={() => {
              reset({ name: '' });
            }}
          >
            reset
          </button>
          <p>is valid: {isValid ? 'true' : 'false'}</p>
        </div>
      );
    };

    render(<App />);

    const input = screen.getByRole('textbox') as HTMLInputElement;

    await waitFor(() => {
      expect(screen.getByText('is valid: true')).toBeInTheDocument();
    });

    expect(formState).toEqual({ isValid: true });
    expect(input.value).toBe('Mike');

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    });

    await waitFor(() => {
      expect(input.value).toBe('');
    });

    await act(async () => {
      jest.advanceTimersByTime(1000);
    });

    expect(screen.getByText('is valid: true')).toBeInTheDocument();
    expect(formState).toEqual({ isValid: true });
  });

  it('should cancel a pending delayError timer so the reset error does not come back', async () => {
    jest.useFakeTimers();

    const message = 'too long.';

    const App = () => {
      const {
        register,
        reset,
        formState: { errors },
      } = useForm<{ test: string }>({
        delayError: 500,
        mode: 'onChange',
      });

      return (
        <div>
          <input {...register('test', { maxLength: 4 })} />
          <button type="button" onClick={() => reset()}>
            reset
          </button>
          {errors.test && <p>{message}</p>}
        </div>
      );
    };

    render(<App />);

    // Schedule a delayed error, then reset the form before the delay elapses.
    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: '123456' },
      });
    });

    fireEvent.click(screen.getByRole('button'));

    await act(async () => {
      jest.advanceTimersByTime(500);
    });

    expect(screen.queryByText(message)).not.toBeInTheDocument();

    // The delay itself must still work, otherwise the assertion above would
    // pass even if no timer had been scheduled in the first place.
    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: '654321' },
      });
    });

    expect(screen.queryByText(message)).not.toBeInTheDocument();

    await act(async () => {
      jest.advanceTimersByTime(500);
    });

    expect(screen.getByText(message)).toBeVisible();

    jest.useRealTimers();
  });

  it('should clear isValidating when reset is called while a validation is pending', async () => {
    let resolveResolver: (() => void) | undefined;

    const App = () => {
      const [visible, setVisible] = React.useState(true);
      const {
        register,
        reset,
        formState: { isValid, isValidating, validatingFields },
      } = useForm<{ test: string }>({
        defaultValues: { test: '' },
        resolver: async (values) => {
          await new Promise<void>((resolve) => {
            resolveResolver = resolve;
          });
          return { values, errors: {} };
        },
      });

      return (
        <div>
          {visible && <input {...register('test')} />}
          <p>{`valid:${isValid}`}</p>
          <p>{`status:${isValidating ? 'validating' : 'idle'}`}</p>
          <p>{`tracked:${Object.keys(validatingFields).join(',')}`}</p>
          <button
            type="button"
            onClick={() => {
              reset();
              setVisible(false);
            }}
          >
            reset
          </button>
        </div>
      );
    };

    render(<App />);

    await act(async () => {
      resolveResolver && resolveResolver();
    });

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: 'a' },
      });
    });

    expect(screen.getByText(/^status:/).textContent).toEqual(
      'status:validating',
    );

    await act(async () => {
      fireEvent.click(screen.getByRole('button'));
    });

    expect(screen.getByText(/^status:/).textContent).toEqual('status:idle');
    expect(screen.getByText(/^tracked:/).textContent).toEqual('tracked:');

    // The field is gone, so the in-flight resolver has no mounted name left to
    // clear and cannot undo a stale flag on its own.
    await act(async () => {
      resolveResolver && resolveResolver();
    });

    expect(screen.getByText(/^status:/).textContent).toEqual('status:idle');
    expect(screen.getByText(/^tracked:/).textContent).toEqual('tracked:');
  });

  it('should keep isValidating when reset is called with keepIsValidating option', async () => {
    let resolveResolver: (() => void) | undefined;

    const App = () => {
      const [visible, setVisible] = React.useState(true);
      const {
        register,
        reset,
        formState: { isValid, isValidating, validatingFields },
      } = useForm<{ test: string }>({
        defaultValues: { test: '' },
        resolver: async (values) => {
          await new Promise<void>((resolve) => {
            resolveResolver = resolve;
          });
          return { values, errors: {} };
        },
      });

      return (
        <div>
          {visible && <input {...register('test')} />}
          <p>{`valid:${isValid}`}</p>
          <p>{`status:${isValidating ? 'validating' : 'idle'}`}</p>
          <p>{`tracked:${Object.keys(validatingFields).join(',')}`}</p>
          <button
            type="button"
            onClick={() => {
              reset(undefined, { keepIsValidating: true });
              setVisible(false);
            }}
          >
            reset
          </button>
        </div>
      );
    };

    render(<App />);

    await act(async () => {
      resolveResolver && resolveResolver();
    });

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: 'a' },
      });
    });

    await act(async () => {
      fireEvent.click(screen.getByRole('button'));
    });

    expect(screen.getByText(/^status:/).textContent).toEqual(
      'status:validating',
    );
    expect(screen.getByText(/^tracked:/).textContent).toEqual('tracked:test');
  });

  // #13714/#13715 clear `isValidating`/`validatingFields` on reset, but the
  // resolver call started by the earlier trigger() is never cancelled or
  // invalidated. When it finally settles after reset() has already restored
  // clean values, executeSchemaAndUpdateState() still writes its (stale)
  // result into `_formState.errors`, resurrecting an error that belongs to
  // input the user no longer has on screen.
  it('should not resurrect a resolver error that settles after reset() clears the field', async () => {
    let resolveResolver:
      | ((result: { values: unknown; errors: unknown }) => void)
      | undefined;
    const receivedValues: Array<{ test: string }> = [];

    const App = () => {
      const {
        register,
        reset,
        trigger,
        formState: { errors },
      } = useForm<{ test: string }>({
        defaultValues: { test: '' },
        resolver: (values) => {
          receivedValues.push(values);
          return new Promise((resolve) => {
            resolveResolver = resolve;
          });
        },
      });

      return (
        <div>
          <input {...register('test')} />
          <p>{`error:${errors.test ? errors.test.message : 'none'}`}</p>
          <button type="button" onClick={() => void trigger('test')}>
            trigger
          </button>
          <button type="button" onClick={() => reset({ test: '' })}>
            reset
          </button>
        </div>
      );
    };

    render(<App />);

    fireEvent.change(screen.getByRole('textbox'), {
      target: { value: 'invalid' },
    });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'trigger' }));
    });

    // Sanity check: the resolver actually ran against the invalid input and
    // is still pending.
    expect(receivedValues).toEqual([{ test: 'invalid' }]);
    expect(resolveResolver).toBeDefined();

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    });

    expect(screen.getByText(/^error:/).textContent).toEqual('error:none');
    expect(screen.getByRole('textbox')).toHaveValue('');

    // The stale trigger()/resolver call — still validating the discarded
    // 'invalid' input — settles only now, after reset() already restored a
    // clean form.
    await act(async () => {
      resolveResolver!({
        values: {},
        errors: {
          test: { type: 'manual', message: 'stale error' },
        },
      });
    });

    expect(screen.getByText(/^error:/).textContent).toEqual('error:none');
  });

  // Control for the regression above: without an intervening reset(), the
  // same delayed resolver result must still be applied as usual.
  it('should apply a delayed resolver error normally when reset() is not called', async () => {
    let resolveResolver:
      | ((result: { values: unknown; errors: unknown }) => void)
      | undefined;

    const App = () => {
      const {
        register,
        trigger,
        formState: { errors },
      } = useForm<{ test: string }>({
        defaultValues: { test: '' },
        resolver: () =>
          new Promise((resolve) => {
            resolveResolver = resolve;
          }),
      });

      return (
        <div>
          <input {...register('test')} />
          <p>{`error:${errors.test ? errors.test.message : 'none'}`}</p>
          <button type="button" onClick={() => void trigger('test')}>
            trigger
          </button>
        </div>
      );
    };

    render(<App />);

    fireEvent.change(screen.getByRole('textbox'), {
      target: { value: 'invalid' },
    });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'trigger' }));
    });

    expect(resolveResolver).toBeDefined();

    await act(async () => {
      resolveResolver!({
        values: {},
        errors: {
          test: { type: 'manual', message: 'stale error' },
        },
      });
    });

    expect(screen.getByText(/^error:/).textContent).toEqual(
      'error:stale error',
    );
  });

  // A stale resolver settling after reset() must not clear validatingFields
  // for a field that a newer, still-pending trigger() call is validating.
  it('should keep a newer trigger validation marked as validating when a stale resolver from before reset settles', async () => {
    const resolveCalls: Array<
      (result: { values: unknown; errors: unknown }) => void
    > = [];

    const { result } = renderHook(() => {
      const form = useForm<{ test: string }>({
        defaultValues: { test: 'old' },
        resolver: () =>
          new Promise((resolve) => {
            resolveCalls.push(resolve);
          }),
      });
      form.formState.isValidating;
      form.formState.validatingFields;
      return form;
    });

    let staleTrigger!: Promise<boolean>;
    let freshTrigger!: Promise<boolean>;

    await act(async () => {
      staleTrigger = result.current.trigger('test');
    });

    await act(async () => {
      result.current.reset({ test: 'new' });
    });

    await act(async () => {
      freshTrigger = result.current.trigger('test');
    });

    expect(resolveCalls).toHaveLength(2);
    expect(result.current.formState.isValidating).toBe(true);

    // The pre-reset resolver settles first; the post-reset one is still
    // pending and must keep validatingFields set.
    await act(async () => {
      resolveCalls[0]({
        values: {},
        errors: { test: { type: 'manual', message: 'stale error' } },
      });
      await staleTrigger;
    });

    expect(result.current.formState.isValidating).toBe(true);
    expect(result.current.formState.validatingFields).toEqual({
      test: true,
    });

    await act(async () => {
      resolveCalls[1]({ values: { test: 'new' }, errors: {} });
      await freshTrigger;
    });

    expect(result.current.formState.isValidating).toBe(false);
  });

  // A stale resolver settling after reset({ keepIsValid: true }) must not
  // overwrite the isValid value that keepIsValid deliberately preserved:
  // an empty `errors` object from a discarded validation pass is not the
  // same thing as the form actually being valid.
  it('should not overwrite a keepIsValid-preserved isValid when a stale resolver settles after reset', async () => {
    const invalidResult = {
      values: {},
      errors: { test: { type: 'manual', message: 'invalid' } },
    };
    let resolveStale: ((result: typeof invalidResult) => void) | undefined;
    let callCount = 0;

    const { result } = renderHook(() =>
      useForm<{ test: string }>({
        defaultValues: { test: 'invalid' },
        resolver: () => {
          callCount += 1;
          return callCount === 1
            ? Promise.resolve(invalidResult)
            : new Promise<typeof invalidResult>((resolve) => {
                resolveStale = resolve;
              });
        },
      }),
    );

    const observedIsValid: Array<boolean | undefined> = [];
    const unsubscribe = result.current.subscribe({
      formState: { isValid: true },
      callback: (formState) => observedIsValid.push(formState.isValid),
    });

    // First trigger establishes a real, current isValid: false.
    await act(async () => {
      await result.current.trigger('test');
    });
    expect(observedIsValid.at(-1)).toBe(false);

    let staleTrigger!: Promise<boolean>;
    await act(async () => {
      staleTrigger = result.current.trigger('test');
    });

    // keepIsValid explicitly preserves the current isValid across reset,
    // even though errors are cleared.
    await act(async () => {
      result.current.reset({ test: 'still invalid' }, { keepIsValid: true });
    });
    expect(observedIsValid.at(-1)).toBe(false);

    // The pre-reset resolver settles after reset — its (still-invalid)
    // result must not flip the preserved isValid back to true.
    await act(async () => {
      resolveStale!(invalidResult);
      await staleTrigger;
    });

    expect(observedIsValid.at(-1)).toBe(false);
    unsubscribe();
  });

  it('should keep isValidating true after keepIsValidating reset even once the stale resolver settles', async () => {
    // keepIsValidating intentionally skips the reset-time clear; nothing
    // re-derives isValidating from a resolver call discarded by reset(), so
    // it stays true until a fresh trigger()/validation for the field runs.
    type Result = {
      values: { test: string };
      errors: FieldErrors<{ test: string }>;
    };
    const completions: Array<(value: Result) => void> = [];
    const { result } = renderHook(() => {
      const form = useForm<{ test: string }>({
        defaultValues: { test: 'old' },
        resolver: () =>
          new Promise<Result>((resolve) => completions.push(resolve)),
      });
      form.register('test');
      form.formState.isValidating;
      form.formState.validatingFields;
      return form;
    });
    let old!: Promise<boolean>;
    await act(async () => {
      old = result.current.trigger('test');
    });
    await act(async () => {
      result.current.reset({ test: 'new' }, { keepIsValidating: true });
    });
    expect(result.current.formState.isValidating).toBe(true);
    await act(async () => {
      completions[0]({ values: { test: 'old' }, errors: {} });
      expect(await old).toBe(true);
    });
    expect(result.current.formState.isValidating).toBe(true);
    expect(result.current.formState.validatingFields).toEqual({
      test: true,
    });

    let fresh!: Promise<boolean>;
    await act(async () => {
      fresh = result.current.trigger('test');
    });
    await act(async () => {
      completions[1]({ values: { test: 'new' }, errors: {} });
      await fresh;
    });
    expect(result.current.formState.isValidating).toBe(false);
  });

  it('should return the discarded validation result without touching or focusing reset fields', async () => {
    const invalid = {
      values: {},
      errors: { test: { type: 'manual', message: 'old error' } },
    };
    let complete!: (value: typeof invalid) => void;
    const { result } = renderHook(() => {
      const form = useForm<{ test: string }>({
        defaultValues: { test: 'old' },
        resolver: () =>
          new Promise<typeof invalid>((resolve) => {
            complete = resolve;
          }),
      });
      form.formState.touchedFields;
      form.formState.errors;
      return form;
    });
    const focus = jest.fn();
    result.current.register('test').ref({ name: 'test', value: 'old', focus });
    let pending!: Promise<boolean>;
    await act(async () => {
      pending = result.current.trigger('test', {
        shouldTouch: true,
        shouldFocus: true,
      });
    });
    await act(async () => {
      result.current.reset({ test: 'new' });
    });
    await act(async () => {
      complete(invalid);
      expect(await pending).toBe(false);
    });
    expect(result.current.formState.touchedFields).toEqual({});
    expect(result.current.formState.errors).toEqual({});
    expect(focus).not.toHaveBeenCalled();
  });

  it('should not delay a current error when a pre-reset trigger settles', async () => {
    jest.useFakeTimers();

    type Result = {
      values: { test: string };
      errors: FieldErrors<{ test: string }>;
    };
    let complete!: (value: Result) => void;
    const { result } = renderHook(() => {
      const form = useForm<{ test: string }>({
        defaultValues: { test: 'old' },
        delayError: 100,
        resolver: () =>
          new Promise<Result>((resolve) => {
            complete = resolve;
          }),
      });
      form.formState.errors;
      return form;
    });
    let pending!: Promise<boolean>;
    // delayError is an internal trigger option used by validation flows.
    const options = { delayError: true, shouldFocus: false };
    await act(async () => {
      pending = result.current.trigger('test', options);
    });
    await act(async () => {
      result.current.reset({ test: 'new' });
    });
    await act(async () => {
      result.current.setError('test', {
        type: 'server',
        message: 'current error',
      });
    });
    await act(async () => {
      complete({ values: { test: 'old' }, errors: {} });
      await pending;
    });
    expect(result.current.formState.errors.test?.message).toBe('current error');
    await act(async () => {
      jest.advanceTimersByTime(100);
    });
    expect(result.current.formState.errors.test?.message).toBe('current error');
  });

  // #13722 and #13733 added a _resetCallId guard to executeSchemaAndUpdateState
  // and handleSubmit, but the resolver call started by a keystroke was left
  // unguarded, so it still writes its discarded result into a form that
  // reset() has already cleaned. _updateIsFieldValueUpdated normally masks
  // this by bailing when the in-flight value no longer matches the current
  // one, which is why a reset that keeps or restores the same value is needed
  // to see it.
  it('should not resurrect an onChange resolver error that settles after reset({ keepValues: true })', async () => {
    let resolveResolver:
      | ((result: { values: unknown; errors: unknown }) => void)
      | undefined;

    const App = () => {
      const {
        register,
        reset,
        formState: { errors },
      } = useForm<{ test: string }>({
        mode: 'onChange',
        defaultValues: { test: '' },
        resolver: () =>
          new Promise((resolve) => {
            resolveResolver = resolve;
          }),
      });

      return (
        <div>
          <input {...register('test')} />
          <p>{`error:${errors.test ? errors.test.message : 'none'}`}</p>
          <button
            type="button"
            onClick={() => reset(undefined, { keepValues: true })}
          >
            reset
          </button>
        </div>
      );
    };

    render(<App />);

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: 'invalid' },
      });
    });

    // Sanity check: the keystroke really did start a resolver call that is
    // still pending.
    expect(resolveResolver).toBeDefined();

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    });

    expect(screen.getByText(/^error:/).textContent).toEqual('error:none');

    await act(async () => {
      resolveResolver!({
        values: {},
        errors: { test: { type: 'manual', message: 'stale error' } },
      });
    });

    expect(screen.getByText(/^error:/).textContent).toEqual('error:none');
  });

  it('should not resurrect an onChange resolver error when reset() restores the same value', async () => {
    let resolveResolver:
      | ((result: { values: unknown; errors: unknown }) => void)
      | undefined;

    const App = () => {
      const {
        register,
        reset,
        formState: { errors },
      } = useForm<{ test: string }>({
        mode: 'onChange',
        defaultValues: { test: '' },
        resolver: () =>
          new Promise((resolve) => {
            resolveResolver = resolve;
          }),
      });

      return (
        <div>
          <input {...register('test')} />
          <p>{`error:${errors.test ? errors.test.message : 'none'}`}</p>
          <button type="button" onClick={() => reset({ test: 'invalid' })}>
            reset
          </button>
        </div>
      );
    };

    render(<App />);

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: 'invalid' },
      });
    });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    });

    await act(async () => {
      resolveResolver!({
        values: {},
        errors: { test: { type: 'manual', message: 'stale error' } },
      });
    });

    expect(screen.getByText(/^error:/).textContent).toEqual('error:none');
  });

  // The discarded call must not clear validatingFields either, or a newer
  // keystroke that is still waiting on the resolver reports itself as done.
  it('should keep a newer onChange validation marked as validating when a stale resolver from before reset settles', async () => {
    const resolveCalls: Array<
      (result: { values: unknown; errors: unknown }) => void
    > = [];

    const App = () => {
      const {
        register,
        reset,
        formState: { errors, isValidating, validatingFields },
      } = useForm<{ test: string }>({
        mode: 'onChange',
        defaultValues: { test: '' },
        resolver: () =>
          new Promise((resolve) => {
            resolveCalls.push(resolve);
          }),
      });

      return (
        <div>
          <input {...register('test')} />
          <p>{`error:${errors.test ? errors.test.message : 'none'}`}</p>
          <p>{`validating:${isValidating}`}</p>
          <p>{`validatingFields:${JSON.stringify(validatingFields)}`}</p>
          <button
            type="button"
            onClick={() => reset(undefined, { keepValues: true })}
          >
            reset
          </button>
        </div>
      );
    };

    render(<App />);

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: 'stale' },
      });
    });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    });

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: 'fresh' },
      });
    });

    expect(resolveCalls).toHaveLength(2);
    expect(screen.getByText(/^validating:/).textContent).toEqual(
      'validating:true',
    );

    await act(async () => {
      resolveCalls[0]({
        values: {},
        errors: { test: { type: 'manual', message: 'stale error' } },
      });
    });

    expect(screen.getByText(/^error:/).textContent).toEqual('error:none');
    expect(screen.getByText(/^validating:/).textContent).toEqual(
      'validating:true',
    );
    expect(screen.getByText(/^validatingFields:/).textContent).toEqual(
      'validatingFields:{"test":true}',
    );

    await act(async () => {
      resolveCalls[1]({ values: { test: 'fresh' }, errors: {} });
    });

    expect(screen.getByText(/^validating:/).textContent).toEqual(
      'validating:false',
    );
  });

  // Control: with no intervening reset(), a slow onChange resolver result is
  // still applied as usual.
  it('should apply a delayed onChange resolver error when reset() is not called', async () => {
    let resolveResolver:
      | ((result: { values: unknown; errors: unknown }) => void)
      | undefined;

    const App = () => {
      const {
        register,
        formState: { errors },
      } = useForm<{ test: string }>({
        mode: 'onChange',
        defaultValues: { test: '' },
        resolver: () =>
          new Promise((resolve) => {
            resolveResolver = resolve;
          }),
      });

      return (
        <div>
          <input {...register('test')} />
          <p>{`error:${errors.test ? errors.test.message : 'none'}`}</p>
        </div>
      );
    };

    render(<App />);

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: 'invalid' },
      });
    });

    await act(async () => {
      resolveResolver!({
        values: {},
        errors: { test: { type: 'manual', message: 'stale error' } },
      });
    });

    expect(screen.getByText(/^error:/).textContent).toEqual(
      'error:stale error',
    );
  });
  // #13744 guarded the resolver branch of onChange, but the built-in
  // validation branch runs the same shape of async work and was left
  // unguarded, so a `validate` promise that settles after reset() still
  // writes its result into the cleaned form state.
  it('should not resurrect an onChange validate error that settles after reset', async () => {
    let resolveValidate: ((result: string | boolean) => void) | undefined;

    const App = () => {
      const {
        register,
        reset,
        formState: { errors },
      } = useForm<{ test: string }>({
        mode: 'onChange',
        defaultValues: { test: '' },
      });

      return (
        <div>
          <input
            {...register('test', {
              validate: () =>
                new Promise<string | boolean>((resolve) => {
                  resolveValidate = resolve;
                }),
            })}
          />
          <p>{`error:${errors.test ? errors.test.message : 'none'}`}</p>
          <button
            type="button"
            onClick={() => reset(undefined, { keepValues: true })}
          >
            reset
          </button>
        </div>
      );
    };

    render(<App />);

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: 'invalid' },
      });
    });

    // Sanity check: the keystroke really did start a validate call that is
    // still pending.
    expect(resolveValidate).toBeDefined();

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    });

    expect(screen.getByText(/^error:/).textContent).toEqual('error:none');

    await act(async () => {
      resolveValidate!('stale error');
    });

    expect(screen.getByText(/^error:/).textContent).toEqual('error:none');
  });

  // The isValid pass that follows an error-free field validation is a second
  // suspension point, so a reset() landing there must discard its result too.
  it('should not apply a stale isValid computed by an onChange validation that spans reset', async () => {
    const resolvers: Array<(result: string | boolean) => void> = [];

    const App = () => {
      const {
        register,
        reset,
        formState: { isValid },
      } = useForm<{ test: string }>({
        mode: 'onChange',
        defaultValues: { test: 'ok' },
      });

      return (
        <div>
          <input
            {...register('test', {
              validate: () =>
                new Promise<string | boolean>((resolve) => {
                  resolvers.push(resolve);
                }),
            })}
          />
          <p>{`valid:${isValid}`}</p>
          <button
            type="button"
            onClick={() => reset(undefined, { keepValues: true })}
          >
            reset
          </button>
        </div>
      );
    };

    render(<App />);

    await act(async () => {
      resolvers.splice(0).forEach((resolve) => resolve(true));
    });

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: 'changed' },
      });
    });

    // The keystroke's own field validation passes, which is what starts the
    // separate isValid pass this test is about.
    expect(resolvers).toHaveLength(1);

    await act(async () => {
      resolvers.splice(0, 1)[0](true);
    });

    expect(resolvers).toHaveLength(1);
    expect(screen.getByText(/^valid:/).textContent).toEqual('valid:true');

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    });

    await act(async () => {
      resolvers.splice(0, 1)[0]('stale error');
    });

    expect(screen.getByText(/^valid:/).textContent).toEqual('valid:true');
  });

  // Control: with no intervening reset(), a slow built-in validate result is
  // still applied as usual.
  it('should apply a delayed onChange validate error when reset() is not called', async () => {
    let resolveValidate: ((result: string | boolean) => void) | undefined;

    const App = () => {
      const {
        register,
        formState: { errors },
      } = useForm<{ test: string }>({
        mode: 'onChange',
        defaultValues: { test: '' },
      });

      return (
        <div>
          <input
            {...register('test', {
              validate: () =>
                new Promise<string | boolean>((resolve) => {
                  resolveValidate = resolve;
                }),
            })}
          />
          <p>{`error:${errors.test ? errors.test.message : 'none'}`}</p>
        </div>
      );
    };

    render(<App />);

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: 'invalid' },
      });
    });

    await act(async () => {
      resolveValidate!('stale error');
    });

    expect(screen.getByText(/^error:/).textContent).toEqual(
      'error:stale error',
    );
  });

  // #13744 and #13745 guarded the resolver and per-field validation branches,
  // but the form level `validate` option runs its own await inside
  // validateForm() and still writes errors.form after reset() has cleaned up.
  it('should not resurrect a form level validate error that settles after reset', async () => {
    let resolveValidate: ((result: string | boolean) => void) | undefined;

    const App = () => {
      const {
        register,
        reset,
        formState: { errors },
      } = useForm<{ test: string }>({
        mode: 'onChange',
        defaultValues: { test: '' },
        validate: () =>
          new Promise<string | boolean>((resolve) => {
            resolveValidate = resolve;
          }),
      });

      return (
        <div>
          <input {...register('test')} />
          <p>{`error:${errors.form ? errors.form.message : 'none'}`}</p>
          <button
            type="button"
            onClick={() => reset(undefined, { keepValues: true })}
          >
            reset
          </button>
        </div>
      );
    };

    render(<App />);

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: 'invalid' },
      });
    });

    // Sanity check: the keystroke really did start a form level validate call
    // that is still pending.
    expect(resolveValidate).toBeDefined();

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    });

    expect(screen.getByText(/^error:/).textContent).toEqual('error:none');

    await act(async () => {
      resolveValidate!('stale error');
    });

    expect(screen.getByText(/^error:/).textContent).toEqual('error:none');
  });

  it('should not resurrect a form level validate error from trigger() that settles after reset', async () => {
    const resolvers: Array<(result: string | boolean) => void> = [];

    const App = () => {
      const {
        register,
        reset,
        trigger,
        formState: { errors, isValid },
      } = useForm<{ test: string }>({
        defaultValues: { test: '' },
        validate: () =>
          new Promise<string | boolean>((resolve) => {
            resolvers.push(resolve);
          }),
      });

      return (
        <div>
          <input {...register('test')} />
          <p>{`error:${errors.form ? errors.form.message : 'none'}`}</p>
          <p>{`valid:${isValid}`}</p>
          <button type="button" onClick={() => trigger()}>
            trigger
          </button>
          <button
            type="button"
            onClick={() => reset(undefined, { keepValues: true })}
          >
            reset
          </button>
        </div>
      );
    };

    render(<App />);

    // Drain the isValid pass the mount kicks off so the only pending validate
    // left is the one trigger() starts below.
    await act(async () => {
      resolvers.splice(0).forEach((resolve) => resolve(true));
    });

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'trigger' }));
    });

    expect(resolvers).toHaveLength(1);
    expect(screen.getByText(/^valid:/).textContent).toEqual('valid:true');

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    });

    await act(async () => {
      resolvers.splice(0, 1)[0]('stale error');
    });

    expect(screen.getByText(/^error:/).textContent).toEqual('error:none');
    expect(screen.getByText(/^valid:/).textContent).toEqual('valid:true');
  });

  // A stale form level validate that passes must not wipe an error the form
  // picked up after reset() either.
  it('should not clear a current form level error when a stale validate settles after reset', async () => {
    const resolvers: Array<(result: string | boolean) => void> = [];

    const App = () => {
      const {
        register,
        reset,
        setError,
        trigger,
        formState: { errors },
      } = useForm<{ test: string }>({
        defaultValues: { test: '' },
        validate: () =>
          new Promise<string | boolean>((resolve) => {
            resolvers.push(resolve);
          }),
      });

      return (
        <div>
          <input {...register('test')} />
          <p>{`error:${errors.form ? errors.form.message : 'none'}`}</p>
          <button type="button" onClick={() => trigger()}>
            trigger
          </button>
          <button
            type="button"
            onClick={() => {
              reset(undefined, { keepValues: true });
              setError('form', { message: 'current error' });
            }}
          >
            reset
          </button>
        </div>
      );
    };

    render(<App />);

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'trigger' }));
    });

    expect(resolvers).toHaveLength(1);

    await act(async () => {
      fireEvent.click(screen.getByRole('button', { name: 'reset' }));
    });

    expect(screen.getByText(/^error:/).textContent).toEqual(
      'error:current error',
    );

    await act(async () => {
      resolvers.splice(0, 1)[0](true);
    });

    expect(screen.getByText(/^error:/).textContent).toEqual(
      'error:current error',
    );
  });

  // Control: with no intervening reset(), a slow form level validate result is
  // still applied as usual.
  it('should apply a delayed form level validate error when reset() is not called', async () => {
    let resolveValidate: ((result: string | boolean) => void) | undefined;

    const App = () => {
      const {
        register,
        formState: { errors },
      } = useForm<{ test: string }>({
        mode: 'onChange',
        defaultValues: { test: '' },
        validate: () =>
          new Promise<string | boolean>((resolve) => {
            resolveValidate = resolve;
          }),
      });

      return (
        <div>
          <input {...register('test')} />
          <p>{`error:${errors.form ? errors.form.message : 'none'}`}</p>
        </div>
      );
    };

    render(<App />);

    await act(async () => {
      fireEvent.change(screen.getByRole('textbox'), {
        target: { value: 'invalid' },
      });
    });

    await act(async () => {
      resolveValidate!('stale error');
    });

    expect(screen.getByText(/^error:/).textContent).toEqual(
      'error:stale error',
    );
  });
});
