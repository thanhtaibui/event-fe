import type React from 'react';

import type { VALIDATION_MODE } from '../constants';
import type { Subject, Subscription } from '../utils/createSubject';

import type {
  ErrorOption,
  FieldErrors,
  FieldPathError,
  GlobalError,
} from './errors';
import type { EventType } from './events';
import type { FieldArray } from './fieldArray';
import type {
  FieldName,
  FieldRefs,
  FieldValue,
  FieldValues,
  InternalFieldName,
} from './fields';
import type {
  FieldArrayPath,
  FieldPath,
  FieldPathValue,
  FieldPathValues,
} from './path';
import type { Resolver } from './resolvers';
import type {
  DeepMap,
  DeepPartial,
  DeepPartialSkipArrayKey,
  Noop,
} from './utils';
import type { RegisterOptions, ValidateForm } from './validator';

declare const $NestedValue: unique symbol;

/**
 * @deprecated to be removed in the next major version
 */
export type NestedValue<TValue extends object = object> = {
  [$NestedValue]: never;
} & TValue;

export type DefaultValues<TFieldValues> =
  TFieldValues extends AsyncDefaultValues<TFieldValues>
    ? DeepPartial<Awaited<TFieldValues>>
    : DeepPartial<TFieldValues>;

export type InternalNameSet = Set<InternalFieldName>;

export type ValidationMode = typeof VALIDATION_MODE;

export type Mode = keyof ValidationMode;

export type ValidationModeFlags = {
  isOnSubmit: boolean;
  isOnBlur: boolean;
  isOnChange: boolean;
  isOnAll: boolean;
  isOnTouch: boolean;
};

export type CriteriaMode = 'firstError' | 'all';

export type SubmitHandler<T, TResult = unknown> = (
  data: T,
  event?: React.BaseSyntheticEvent,
) => TResult;

export type FormSubmitHandler<TTransformedValues> = (payload: {
  data: TTransformedValues;
  event?: React.BaseSyntheticEvent;
  formData: FormData;
  formDataJson: string;
  method?: 'post' | 'put' | 'delete';
}) => unknown | Promise<unknown>;

export type SubmitErrorHandler<TFieldValues extends FieldValues> = (
  errors: FieldErrors<TFieldValues>,
  event?: React.BaseSyntheticEvent,
) => unknown | Promise<unknown>;

export type SetValueConfig = Partial<{
  shouldValidate: boolean;
  shouldDirty: boolean;
  shouldTouch: boolean;
  delayError: boolean;
}>;

export type TriggerConfig = Partial<{
  shouldFocus: boolean;
  shouldTouch: boolean;
}>;

export type ResetFieldConfig<
  TFieldValues extends FieldValues,
  TFieldName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>,
> = Partial<{
  keepDirty: boolean;
  keepTouched: boolean;
  keepError: boolean;
  defaultValue: FieldPathValue<TFieldValues, TFieldName>;
}>;

export type ChangeHandler = (event: {
  target: any;
  type?: any;
}) => Promise<void | boolean>;

export type DelayCallback = (wait: number) => void;

type AsyncDefaultValues<TFieldValues> = (
  payload?: unknown,
) => Promise<TFieldValues>;

export type UseFormProps<
  TFieldValues extends FieldValues = FieldValues,
  TContext = any,
  TTransformedValues = TFieldValues,
> = Partial<{
  mode: Mode;
  disabled: boolean;
  reValidateMode: Exclude<Mode, 'onTouched' | 'all'>;
  defaultValues: DefaultValues<TFieldValues> | AsyncDefaultValues<TFieldValues>;
  values: TFieldValues;
  errors: FieldErrors<TFieldValues>;
  resetOptions: Parameters<UseFormReset<TFieldValues>>[1];
  resolver: Resolver<TFieldValues, TContext, TTransformedValues>;
  context: TContext;
  shouldFocusError: boolean;
  shouldUnregister: boolean;
  shouldUseNativeValidation: boolean;
  progressive: boolean;
  criteriaMode: CriteriaMode;
  delayError: number;
  formControl?: Omit<
    UseFormReturn<TFieldValues, TContext, TTransformedValues>,
    'formState'
  >;
  validate: ValidateForm<TFieldValues>;
}>;

export type FieldNamesMarkedBoolean<TFieldValues extends FieldValues> = DeepMap<
  DeepPartial<TFieldValues>,
  boolean
>;

export type FormStateProxy<TFieldValues extends FieldValues = FieldValues> = {
  isDirty: boolean;
  isValidating: boolean;
  dirtyFields: FieldNamesMarkedBoolean<TFieldValues>;
  touchedFields: FieldNamesMarkedBoolean<TFieldValues>;
  validatingFields: FieldNamesMarkedBoolean<TFieldValues>;
  errors: boolean;
  isValid: boolean;
};

export type ReadFormState = { [K in keyof FormStateProxy]: boolean | 'all' } & {
  values?: boolean;
  defaultValues?: boolean | 'all';
  isSubmitted?: boolean | 'all';
  submitCount?: boolean | 'all';
};

export type FormState<TFieldValues extends FieldValues> = {
  isDirty: boolean;
  isLoading: boolean;
  isSubmitted: boolean;
  isSubmitSuccessful: boolean;
  isSubmitting: boolean;
  isValidating: boolean;
  isValid: boolean;
  disabled: boolean;
  submitCount: number;
  defaultValues?: undefined | Readonly<DeepPartial<TFieldValues>>;
  dirtyFields: Partial<Readonly<FieldNamesMarkedBoolean<TFieldValues>>>;
  touchedFields: Partial<Readonly<FieldNamesMarkedBoolean<TFieldValues>>>;
  validatingFields: Partial<Readonly<FieldNamesMarkedBoolean<TFieldValues>>>;
  errors: FieldErrors<TFieldValues>;
  isReady: boolean;
};

export type KeepStateOptions = Partial<{
  keepDirtyValues: boolean;
  keepErrors: boolean;
  keepDirty: boolean;
  keepValues: boolean;
  keepDefaultValues: boolean;
  keepIsSubmitted: boolean;
  keepIsSubmitSuccessful: boolean;
  keepTouched: boolean;
  keepIsValidating: boolean;
  keepIsValid: boolean;
  keepSubmitCount: boolean;
  keepFieldsRef: boolean;
}>;

export type SetFieldValue<TFieldValues extends FieldValues> =
  FieldValue<TFieldValues>;

export type RefCallBack = (instance: any) => void;

export type UseFormRegisterReturn<
  TFieldName extends InternalFieldName = InternalFieldName,
> = {
  onChange: ChangeHandler;
  onBlur: ChangeHandler;
  ref: RefCallBack;
  name: TFieldName;
  min?: string | number;
  max?: string | number;
  maxLength?: number;
  minLength?: number;
  pattern?: string;
  required?: boolean;
  disabled?: boolean;
};

/**
 * Registers a field into hook form with or without the actual DOM ref. You can invoke register anywhere in the component including in `useEffect`.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/register) • [Demo](https://codesandbox.io/s/react-hook-form-register-ts-ip2j3) • [Video](https://www.youtube.com/watch?v=JFIpCoajYkA)
 *
 * @param name - The path name to the form field value; name is required and unique.
 * @param options - Register options including validation, disabled, unregister, value as, and dependent validation.
 *
 * @returns onChange, onBlur, name, ref, and native HTML validation attributes if browser validation is enabled.
 *
 * @example
 * ```tsx
 * // Register HTML native input
 * <input {...register("input")} />
 * <select {...register("select")} />
 *
 * // Register options
 * <textarea {...register("textarea", { required: "This is required.", maxLength: 20 })} />
 * <input type="number" {...register("name2", { valueAsNumber: true })} />
 * <input {...register("name3", { deps: ["name2"] })} />
 *
 * // Register custom field at useEffect
 * useEffect(() => {
 *   register("name4");
 *   register("name5", { value: "hiddenValue" });
 * }, [register])
 *
 * // Register without ref
 * const { onChange, onBlur, name } = register("name6")
 * <input onChange={onChange} onBlur={onBlur} name={name} />
 * ```
 */
export type UseFormRegister<TFieldValues extends FieldValues> = <
  TFieldName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>,
>(
  name: TFieldName,
  options?: RegisterOptions<TFieldValues, TFieldName>,
) => UseFormRegisterReturn<TFieldName>;

export type SetFocusOptions = Partial<{
  shouldSelect: boolean;
}>;

/**
 * Sets focus on a registered field. You can start to invoke this method after all fields are mounted to the DOM.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/setfocus) • [Demo](https://codesandbox.io/s/setfocus-rolus)
 *
 * @param name - The path name to the form field value.
 * @param options - Input focus behavior options.
 *
 * @example
 * ```tsx
 * useEffect(() => {
 *   setFocus("name");
 * }, [setFocus])
 * // shouldSelect allows to select input's content on focus
 * <button onClick={() => setFocus("name", { shouldSelect: true })}>Focus</button>
 * ```
 */
export type UseFormSetFocus<TFieldValues extends FieldValues> = <
  TFieldName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>,
>(
  name: TFieldName,
  options?: SetFocusOptions,
) => void;

type EitherOption<T> = {
  [K in keyof T]: {
    [P in K]: T[P];
  } & Partial<Record<Exclude<keyof T, K>, never>>;
}[keyof T];

export type GetValuesConfig = EitherOption<{
  dirtyFields: boolean;
  touchedFields: boolean;
}>;

export type UseFormGetValues<TFieldValues extends FieldValues> = {
  /**
   * Get the entire form values when no argument is supplied to this function.
   *
   * @remarks
   * [API](https://react-hook-form.com/docs/useform/getvalues) • [Demo](https://codesandbox.io/s/react-hook-form-v7-ts-getvalues-txsfg)
   *
   * @returns Form values.
   *
   * @example
   * ```tsx
   * <button onClick={() => getValues()}>getValues</button>
   *
   * <input {...register("name", {
   *   validate: (value, formValues) => formValues.otherField === value;
   * })} />
   * ```
   */
  (name?: undefined, config?: GetValuesConfig): TFieldValues;
  /**
   * Get a single field value.
   *
   * @remarks
   * [API](https://react-hook-form.com/docs/useform/getvalues) • [Demo](https://codesandbox.io/s/react-hook-form-v7-ts-getvalues-txsfg)
   *
   * @param name - The path name to the form field value.
   * @param config - Return touched or dirty fields.
   *
   * @returns the single field value
   *
   * @example
   * ```tsx
   * <button onClick={() => getValues("name")}>getValues</button>
   *
   * <input {...register("name", {
   *   validate: () => getValues('otherField') === "test";
   * })} />
   * ```
   */
  <TFieldName extends FieldPath<TFieldValues>>(
    name: TFieldName,
    config?: GetValuesConfig,
  ): FieldPathValue<TFieldValues, TFieldName>;
  /**
   * Get an array of field values.
   *
   * @remarks
   * [API](https://react-hook-form.com/docs/useform/getvalues) • [Demo](https://codesandbox.io/s/react-hook-form-v7-ts-getvalues-txsfg)
   *
   * @param names - an array of field names
   * @param config - return touched or dirty fields
   *
   * @returns An array of field values
   *
   * @example
   * ```tsx
   * <button onClick={() => getValues(["name", "name1"])}>getValues</button>
   *
   * <input {...register("name", {
   *   validate: () => getValues(["fieldA", "fieldB"]).includes("test");
   * })} />
   * ```
   */
  <TFieldNames extends FieldPath<TFieldValues>[]>(
    names: readonly [...TFieldNames],
    config?: GetValuesConfig,
  ): [...FieldPathValues<TFieldValues, TFieldNames>];
};

export type ErrorNamespacePath =
  | 'root'
  | `root.${string}`
  | 'form'
  | `form.${string}`;

/** Resolves the error type returned for a single `getErrors` path. */
export type GetErrorsResult<
  TFieldValues extends FieldValues,
  TName extends FieldPath<TFieldValues> | ErrorNamespacePath,
> = TName extends 'root'
  ? (Record<string, GlobalError> & GlobalError) | undefined
  : TName extends ErrorNamespacePath
    ? GlobalError | undefined
    : TName extends FieldPath<TFieldValues>
      ? FieldPathError<TFieldValues, TName> | undefined
      : never;

/** Gets currently stored form errors without subscribing or running validation. */
export type UseFormGetErrors<TFieldValues extends FieldValues> = {
  /**
   * Get all currently stored form errors without subscribing or running validation.
   *
   * @returns Form errors.
   *
   * @example
   * ```tsx
   * const errors = getErrors();
   * ```
   */
  (name?: undefined): FieldErrors<TFieldValues>;

  /**
   * Get a currently stored field or global error without subscribing or running validation.
   *
   * @param name - The path to the error.
   *
   * @returns The error at the given path.
   *
   * @example
   * ```tsx
   * const emailError = getErrors("email");
   * ```
   */
  <TName extends FieldPath<TFieldValues> | ErrorNamespacePath>(
    name: TName,
  ): GetErrorsResult<TFieldValues, TName>;

  /**
   * Get currently stored errors for multiple paths without subscribing or running validation.
   *
   * @param names - An array of error paths.
   *
   * @returns Errors for the given paths in the same order.
   *
   * @example
   * ```tsx
   * const [emailError, nameError] = getErrors(["email", "name"]);
   * ```
   */
  <TNames extends (FieldPath<TFieldValues> | ErrorNamespacePath)[]>(
    names: readonly [...TNames],
  ): {
    [K in keyof TNames]: GetErrorsResult<TFieldValues, TNames[K]>;
  };
};

/**
 * This method will return individual field states. It will be useful when you are trying to retrieve the nested value field state in a type-safe approach.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/getfieldstate) • [Demo](https://codesandbox.io/s/getfieldstate-jvekk)
 *
 * @param name - The path name to the form field value.
 *
 * @returns invalid, isDirty, isTouched, isValidating, and error object.
 *
 * @example
 * ```tsx
 * // those formState has to be subscribed
 * const { formState: { dirtyFields, errors, touchedFields } } = formState();
 * getFieldState('name')
 * // Get field state when form state is not subscribed yet
 * getFieldState('name', formState)
 *
 * // It's ok to combine with useFormState
 * const formState = useFormState();
 * getFieldState('name')
 * getFieldState('name', formState)
 * ```
 */
export type UseFormGetFieldState<TFieldValues extends FieldValues> = <
  TFieldName extends FieldPath<TFieldValues>,
>(
  name: TFieldName,
  formState?: FormState<TFieldValues>,
) => {
  invalid: boolean;
  isDirty: boolean;
  isTouched: boolean;
  isValidating: boolean;
  error?: FieldPathError<TFieldValues, TFieldName>;
};

/**
 * This method will allow you to subscribe to formState without a component re-rendering.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/subscribe) • [Demo](https://codesandbox.io/s/subscribe)
 *
 * @param options - Subscription options to which formState subscribes.
 *
 * @example
 * ```tsx
const { subscribe } = useForm()

useEffect(() => {
 subscribe({
   formState: { isDirty: true },
   callback: () => {}
 })
})
 * ```
 */
export type UseFormSubscribe<TFieldValues extends FieldValues> = <
  TFieldNames extends readonly FieldPath<TFieldValues>[],
>(payload: {
  name?: readonly [...TFieldNames] | TFieldNames[number];
  formState?: Partial<ReadFormState>;
  callback: (
    data: Partial<FormState<TFieldValues>> & {
      values: TFieldValues;
      name?: InternalFieldName;
      type?: EventType;
    },
  ) => void;
  exact?: boolean;
}) => () => void;

export type UseFormWatch<TFieldValues extends FieldValues> = {
  /**
   * Watch and subscribe to all form updates and changes based on onChange, and trigger re-renders at the useForm level.
   *
   * @remarks
   * [API](https://react-hook-form.com/docs/useform/watch) • [Demo](https://codesandbox.io/s/react-hook-form-watch-v7-ts-8et1d) • [Video](https://www.youtube.com/watch?v=3qLd69WMqKk)
   *
   * @returns The entire form values.
   *
   * @example
   * ```tsx
   * const formValues = watch();
   * ```
   */
  (): TFieldValues;
  /**
   * Watch and subscribe to an array of fields used outside of render.
   *
   * @remarks
   * [API](https://react-hook-form.com/docs/useform/watch) • [Demo](https://codesandbox.io/s/react-hook-form-watch-v7-ts-8et1d) • [Video](https://www.youtube.com/watch?v=3qLd69WMqKk)
   *
   * @param names - An array of field names.
   * @param defaultValue - DefaultValues for the entire form.
   *
   * @returns An array of field values.
   *
   * @example
   * ```tsx
   * const [name, name1] = watch(["name", "name1"]);
   * ```
   */
  <TFieldNames extends readonly FieldPath<TFieldValues>[]>(
    names: readonly [...TFieldNames],
    defaultValue?: DeepPartial<TFieldValues>,
  ): FieldPathValues<TFieldValues, TFieldNames>;
  /**
   * Watch and subscribe to a single field used outside of render.
   *
   * @remarks
   * [API](https://react-hook-form.com/docs/useform/watch) • [Demo](https://codesandbox.io/s/react-hook-form-watch-v7-ts-8et1d) • [Video](https://www.youtube.com/watch?v=3qLd69WMqKk)
   *
   * @param name - the path name to the form field value.
   * @param defaultValue - defaultValues for the entire form
   *
   * @returns the single field value
   *
   * @example
   * ```tsx
   * const name = watch("name");
   * ```
   */
  <TFieldName extends FieldPath<TFieldValues>>(
    name: TFieldName,
    defaultValue?: FieldPathValue<TFieldValues, TFieldName>,
  ): FieldPathValue<TFieldValues, TFieldName>;
  /**
   * Subscribe to field updates and changes without triggering a re-render.
   *
   * @remarks
   * [API](https://react-hook-form.com/docs/useform/watch) • [Demo](https://codesandbox.io/s/react-hook-form-watch-v7-ts-8et1d) • [Video](https://www.youtube.com/watch?v=3qLd69WMqKk)
   *
   * @param callback - Callback function to subscribe to all field changes and return an unsubscribe function.
   * @param defaultValues - DefaultValues for the entire form.
   *
   * @returns Unsubscribe function.
   *
   * @example
   * ```tsx
   * useEffect(() => {
   *   const { unsubscribe } = watch((value) => {
   *     console.log(value);
   *   });
   *   return () => unsubscribe();
   * }, [watch])
   * ```
   */
  (
    callback: WatchObserver<TFieldValues>,
    defaultValues?: DeepPartial<TFieldValues>,
  ): Subscription;
};

/**
 * Triggers field or form validation.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/trigger) • [Demo](https://codesandbox.io/s/react-hook-form-v7-ts-triggervalidation-forked-xs7hl) • [Video](https://www.youtube.com/watch?v=-bcyJCDjksE)
 *
 * @param name - Providing no argument will trigger the entire form validation; an array of field names will validate those fields, and a single field name will only trigger that field's validation.
 * @param options - Should focus on the error field, and/or mark the triggered field(s) as touched.
 *
 * @returns Validation result.
 *
 * @example
 * ```tsx
 * useEffect(() => {
 *   trigger();
 * }, [trigger])
 *
 * <button onClick={async () => {
 *   const result = await trigger(); // result will be a boolean value
 * }}>
 *  trigger
 *  </button>
 * ```
 */
export type UseFormTrigger<TFieldValues extends FieldValues> = (
  name?:
    | FieldPath<TFieldValues>
    | FieldPath<TFieldValues>[]
    | readonly FieldPath<TFieldValues>[],
  options?: TriggerConfig,
) => Promise<boolean>;

/**
 * Clears all form errors.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/clearerrors) • [Demo](https://codesandbox.io/s/react-hook-form-v7-ts-clearerrors-w3ymx)
 *
 * @param name - The path name to the form field value.
 *
 * @example
 * Clear all errors
 * ```tsx
 * clearErrors(); // clear the entire form error
 * clearErrors(["name", "name1"]) // clear an array of fields' error
 * clearErrors("name2"); // clear a single field error
 * ```
 */
export type UseFormClearErrors<TFieldValues extends FieldValues> = (
  name?:
    | FieldPath<TFieldValues>
    | FieldPath<TFieldValues>[]
    | readonly FieldPath<TFieldValues>[]
    | ErrorNamespacePath,
) => void;

/**
 * Sets a single field value, or a group of field values.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/setvalue) • [Demo](https://codesandbox.io/s/react-hook-form-v7-ts-setvalue-8z9hx) • [Video](https://www.youtube.com/watch?v=qpv51sCH3fI)
 *
 * @param name - The path name to the form field value.
 * @param value - Field value.
 * @param options - Should validate or update form state.
 *
 * @example
 * ```tsx
 * // Update a single field
 * setValue('name', 'value', {
 *   shouldValidate: true, // trigger validation
 *   shouldTouch: true, // update touched fields form state
 *   shouldDirty: true, // update dirty and dirty fields form state
 * });
 *
 * // Update a group of fields
 * setValue('root', {
 *   a: 'test', // setValue('root.a', 'data')
 *   b: 'test1', // setValue('root.b', 'data')
 * });
 *
 * // Update a nested object field
 * setValue('select', { label: 'test', value: 'Test' });
 * ```
 */
export type UseFormSetValue<TFieldValues extends FieldValues> = <
  TFieldName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>,
>(
  name: TFieldName,
  value: FieldPathValue<TFieldValues, TFieldName>,
  options?: SetValueConfig,
) => void;

export type UseFormSetValues<TFieldValues extends FieldValues> = (
  value: Partial<TFieldValues> | ResetAction<TFieldValues>,
  options?: SetValueConfig,
) => void;

/**
 * Sets an error for a field. When setting an error that is not associated with a field, a manual `clearErrors` call is required.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/seterror) • [Demo](https://codesandbox.io/s/react-hook-form-v7-ts-seterror-nfxxu) • [Video](https://www.youtube.com/watch?v=raMqvE0YyIY)
 *
 * @param name - The path name to the form field value.
 * @param error - An error object containing the type and an optional message.
 * @param options - Whether or not to focus on the field.
 *
 * @example
 * ```tsx
 * // When the error is not associated with any fields, `clearErrors` will need to be invoked to clear the error.
 * const onSubmit = () => setError("serverError", { type: "server", message: "Error occurred"})
 *
 * <button onClick={() => setError("name", { type: "min" })} />
 *
 * // focus on the input after setting the error
 * <button onClick={() => setError("name", { type: "max" }, { shouldFocus: true })} />
 * ```
 */
export type UseFormSetError<TFieldValues extends FieldValues> = (
  name: FieldPath<TFieldValues> | ErrorNamespacePath,
  error: ErrorOption,
  options?: {
    shouldFocus: boolean;
  },
) => void;

/**
 * Unregisters a field reference and removes its value.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/unregister) • [Demo](https://codesandbox.io/s/react-hook-form-unregister-4k2ey) • [Video](https://www.youtube.com/watch?v=TM99g_NW5Gk&feature=emb_imp_woyt)
 *
 * @param name - The path name to the form field value.
 * @param options - Keep form state options.
 *
 * @example
 * ```tsx
 * register("name", { required: true })
 *
 * <button onClick={() => unregister("name")} />
 * // there are various keep options to retain formState
 * <button onClick={() => unregister("name", { keepErrors: true })} />
 * ```
 */
export type UseFormUnregister<TFieldValues extends FieldValues> = (
  name?:
    | FieldPath<TFieldValues>
    | FieldPath<TFieldValues>[]
    | readonly FieldPath<TFieldValues>[],
  options?: Omit<
    KeepStateOptions,
    | 'keepIsSubmitted'
    | 'keepSubmitCount'
    | 'keepValues'
    | 'keepDefaultValues'
    | 'keepErrors'
  > & { keepValue?: boolean; keepDefaultValue?: boolean; keepError?: boolean },
) => void;

/**
 * Validates the entire form. Handles the submit and error callbacks.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/handlesubmit) • [Demo](https://codesandbox.io/s/react-hook-form-handlesubmit-ts-v7-lcrtu) • [Video](https://www.youtube.com/watch?v=KzcPKB9SOEk)
 *
 * @param onValid - Callback function invoked after the form passes validation.
 * @param onInvalid - Callback function invoked when the form fails validation.
 *
 * @returns Callback function.
 *
 * @example
 * ```tsx
 * const onSubmit = (data) => console.log(data);
 * const onError = (error) => console.log(error);
 *
 * <form onSubmit={handleSubmit(onSubmit, onError)} />
 * ```
 */
export type UseFormHandleSubmit<
  TFieldValues extends FieldValues,
  TTransformedValues = TFieldValues,
> = <TResult>(
  onValid: SubmitHandler<TTransformedValues, TResult>,
  onInvalid?: SubmitErrorHandler<TFieldValues>,
) => (e?: React.BaseSyntheticEvent) => Promise<Awaited<TResult> | undefined>;

/**
 * Resets a field's state and reference.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/resetfield) • [Demo](https://codesandbox.io/s/priceless-firefly-d0kuv) • [Video](https://www.youtube.com/watch?v=IdLFcNaEFEo)
 *
 * @param name - The path name to the form field value.
 * @param options - Keep form state options.
 *
 * @example
 * ```tsx
 * <input {...register("firstName", { required: true })} />
 * <button type="button" onClick={() => resetField("firstName"))}>Reset</button>
 * ```
 */
export type UseFormResetField<TFieldValues extends FieldValues> = <
  TFieldName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>,
>(
  name: TFieldName,
  options?: ResetFieldConfig<TFieldValues, TFieldName>,
) => void;

type ResetAction<TFieldValues> = (formValues: TFieldValues) => TFieldValues;

/**
 * Resets the entire form state.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/reset) • [Demo](https://codesandbox.io/s/react-hook-form-reset-v7-ts-pu901) • [Video](https://www.youtube.com/watch?v=qmCLBjyPwVk)
 *
 * @param values - The entire form values to be reset.
 * @param keepStateOptions - Keep form state options.
 *
 * @example
 * ```tsx
 * useEffect(() => {
 *   // reset the entire form after component mount or form defaultValues are ready
 *   reset({
 *     fieldA: "test"
 *     fieldB: "test"
 *   });
 * }, [reset])
 *
 * // Reset by combining with existing form values
 * reset({
 *   ...getValues(),
 *  fieldB: "test"
 *});
 *
 * // reset and keep form state
 * reset({
 *   ...getValues(),
 *}, {
 *   keepErrors: true,
 *   keepDirty: true
 *});
 * ```
 */
export type UseFormReset<TFieldValues extends FieldValues> = (
  values?:
    | DefaultValues<TFieldValues>
    | TFieldValues
    | ResetAction<TFieldValues>,
  keepStateOptions?: KeepStateOptions,
) => void;

/**
 * Resets the default values of the form and recomputes `dirtyFields`/`isDirty` without changing user values.
 *
 * @remarks
 * [API](https://react-hook-form.com/docs/useform/resetdefaultvalues)
 *
 * @param values - The new default values.
 * @param options - Options to keep dirty or isValid state.
 *
 * @example
 * ```tsx
 * // After a successful submission, update defaults to the submitted values
 * // so that dirtyFields/isDirty reflect changes made after that point.
 * const onSuccess = () => {
 *   resetDefaultValues(submittedValues);
 * };
 * ```
 */
export type UseFormResetDefaultValues<TFieldValues extends FieldValues> = (
  values: DefaultValues<TFieldValues> | TFieldValues,
  options?: Partial<Pick<KeepStateOptions, 'keepDirty' | 'keepIsValid'>>,
) => void;

export type WatchInternal<TFieldValues> = (
  fieldNames?: InternalFieldName | InternalFieldName[],
  defaultValue?: DeepPartial<TFieldValues>,
  isMounted?: boolean,
  isGlobal?: boolean,
) =>
  | FieldPathValue<FieldValues, InternalFieldName>
  | FieldPathValues<FieldValues, InternalFieldName[]>;

export type GetIsDirty = <TName extends InternalFieldName, TData>(
  name?: TName,
  data?: TData,
) => boolean;

export type FormStateSubjectRef<TFieldValues extends FieldValues> = Subject<
  Partial<FormState<TFieldValues>> & {
    name?: InternalFieldName;
    values?: TFieldValues;
    type?: EventType;
  }
>;

export type Subjects<TFieldValues extends FieldValues = FieldValues> = {
  array: Subject<{
    name?: InternalFieldName;
    values?: FieldValues;
  }>;
  state: FormStateSubjectRef<TFieldValues>;
};

export type Names = {
  mount: InternalNameSet;
  unMount: InternalNameSet;
  disabled: InternalNameSet;
  array: InternalNameSet;
  watch: InternalNameSet;
  registerName: InternalNameSet;
  focus?: InternalFieldName;
  watchAll?: boolean;
};

export type BatchFieldArrayUpdate = <
  T extends Function,
  TFieldValues extends FieldValues,
  TFieldArrayName extends FieldArrayPath<TFieldValues> =
    FieldArrayPath<TFieldValues>,
>(
  name: InternalFieldName,
  updatedFieldArrayValues?: Partial<
    FieldArray<TFieldValues, TFieldArrayName>
  >[],
  method?: T,
  args?: Partial<{
    argA: unknown;
    argB: unknown;
  }>,
  shouldSetValue?: boolean,
  shouldUpdateFieldsAndErrors?: boolean,
) => void;

export type FromSubscribe<TFieldValues extends FieldValues> = <
  TFieldNames extends readonly FieldPath<TFieldValues>[],
>(payload: {
  name?: readonly [...TFieldNames] | TFieldNames[number];
  formState?: Partial<ReadFormState>;
  callback: (
    data: Partial<FormState<TFieldValues>> & {
      values: TFieldValues;
      name?: InternalFieldName;
    },
  ) => void;
  exact?: boolean;
  reRenderRoot?: boolean;
}) => () => void;

export type Control<
  TFieldValues extends FieldValues = FieldValues,
  TContext = any,
  TTransformedValues = TFieldValues,
> = {
  _subjects: Subjects<TFieldValues>;
  _removeUnmounted: Noop;
  _names: Names;
  _state: {
    mount: boolean;
    action: boolean;
    actionArrayLengths: Map<InternalFieldName, number>;
    watch: boolean;
  };
  _reset: UseFormReset<TFieldValues>;
  _options: UseFormProps<TFieldValues, TContext, TTransformedValues>;
  _getDirty: GetIsDirty;
  _resetDefaultValues: Noop;
  _formState: FormState<TFieldValues>;
  _setValid: (shouldUpdateValid?: boolean) => void;
  _fields: FieldRefs;
  _formValues: FieldValues;
  _proxyFormState: ReadFormState;
  _defaultValues: Partial<DefaultValues<TFieldValues>>;
  _getWatch: WatchInternal<TFieldValues>;
  _setFieldArray: BatchFieldArrayUpdate;
  _getFieldArray: <TFieldArrayValues>(
    name: InternalFieldName,
  ) => Partial<TFieldArrayValues>[];
  _setErrors: (errors: FieldErrors<TFieldValues>) => void;
  _setDisabledField: (props: {
    disabled?: boolean;
    name: FieldName<any>;
  }) => void;
  _runSchema: (names: InternalFieldName[]) => Promise<{ errors: FieldErrors }>;
  _updateIsValidating: (
    names?: InternalFieldName[],
    isValidating?: boolean,
  ) => void;
  _focusError: () => boolean | undefined;
  _disableForm: (disabled?: boolean) => void;
  _subscribe: FromSubscribe<TFieldValues>;
  register: UseFormRegister<TFieldValues>;
  handleSubmit: UseFormHandleSubmit<TFieldValues, TTransformedValues>;
  unregister: UseFormUnregister<TFieldValues>;
  getFieldState: UseFormGetFieldState<TFieldValues>;
  setError: UseFormSetError<TFieldValues>;
};

export type WatchObserver<TFieldValues extends FieldValues> = (
  value: DeepPartialSkipArrayKey<TFieldValues>,
  info: {
    name?: FieldPath<TFieldValues>;
    type?: EventType;
    values?: unknown;
  },
) => void;

export type UseFormReturn<
  TFieldValues extends FieldValues = FieldValues,
  TContext = any,
  TTransformedValues = TFieldValues,
> = {
  watch: UseFormWatch<TFieldValues>;
  getValues: UseFormGetValues<TFieldValues>;
  getErrors: UseFormGetErrors<TFieldValues>;
  getFieldState: UseFormGetFieldState<TFieldValues>;
  setError: UseFormSetError<TFieldValues>;
  clearErrors: UseFormClearErrors<TFieldValues>;
  setValue: UseFormSetValue<TFieldValues>;
  setValues: UseFormSetValues<TFieldValues>;
  trigger: UseFormTrigger<TFieldValues>;
  formState: FormState<TFieldValues>;
  resetField: UseFormResetField<TFieldValues>;
  reset: UseFormReset<TFieldValues>;
  resetDefaultValues: UseFormResetDefaultValues<TFieldValues>;
  handleSubmit: UseFormHandleSubmit<TFieldValues, TTransformedValues>;
  unregister: UseFormUnregister<TFieldValues>;
  control: Control<TFieldValues, TContext, TTransformedValues>;
  register: UseFormRegister<TFieldValues>;
  setFocus: UseFormSetFocus<TFieldValues>;
  subscribe: UseFormSubscribe<TFieldValues>;
};

export type UseFormStateProps<
  TFieldValues extends FieldValues,
  TTransformedValues = TFieldValues,
> = Partial<{
  control?: Control<TFieldValues, any, TTransformedValues>;
  disabled?: boolean;
  name?:
    | FieldPath<TFieldValues>
    | FieldPath<TFieldValues>[]
    | readonly FieldPath<TFieldValues>[];
  exact?: boolean;
}>;

export type UseFormStateReturn<TFieldValues extends FieldValues> =
  FormState<TFieldValues>;

export type FormProviderProps<
  TFieldValues extends FieldValues = FieldValues,
  TContext = any,
  TTransformedValues = TFieldValues,
> = {
  children: React.ReactNode | React.ReactNode[];
} & UseFormReturn<TFieldValues, TContext, TTransformedValues>;

export type FormProps<
  TFieldValues extends FieldValues,
  TTransformedValues = TFieldValues,
> = Omit<React.FormHTMLAttributes<HTMLFormElement>, 'onError' | 'onSubmit'> &
  Partial<{
    control: Control<TFieldValues, any, TTransformedValues>;
    headers: Record<string, string>;
    validateStatus: (status: number) => boolean;
    onError: ({
      response,
      error,
    }:
      | {
          response: Response;
          error?: undefined;
        }
      | {
          response?: undefined;
          error: unknown;
        }) => void;
    onSuccess: ({ response }: { response: Response }) => void;
    onSubmit: FormSubmitHandler<TTransformedValues>;
    method: 'post' | 'put' | 'delete';
    children: React.ReactNode | React.ReactNode[];
    render: (props: {
      submit: (e?: React.FormEvent) => void;
    }) => React.ReactNode | React.ReactNode[];
    encType:
      | 'application/x-www-form-urlencoded'
      | 'multipart/form-data'
      | 'text/plain'
      | 'application/json';
  }>;
